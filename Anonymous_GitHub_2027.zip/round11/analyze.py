"""Audit the paired long-stream logs and export the manuscript's measurements."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parent
ROUTES = ('affected_rows','partial','view','CINM')
LABEL = dict(zip(ROUTES,('Affected-row Full Sort','Affected-row Partial Top-K','Bounded View','CINM')))
PAIRS = (('affected_rows','partial'),('affected_rows','view'),('partial','view'),
         ('affected_rows','CINM'),('partial','CINM'))
FIELDS = ('count_ms','selection_ms','state_ms','normalization_ms')


def read(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]


def csv_out(path,rows):
    with path.open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tex_rows(path,rows):
    path.write_text('\n'.join([' & '.join(map(str,row))+r' \\' for row in rows]+[r'\bottomrule'])+'\n',encoding='utf-8')


def summary(values):
    return dict(mean=mean(values),median=median(values),low=min(values),high=max(values))


def crossing(values):
    first=next((i for i,value in enumerate(values) if value>0),None)
    last=next((i for i in range(len(values)) if min(values[i:])>0),None)
    return first,last


def stats(logs,output):
    protocol=json.loads((logs/'protocol.json').read_text(encoding='utf-8'))
    orders=protocol['orders']
    assert len(orders)==4 and all(set(order)==set(ROUTES) for order in orders)
    assert all({order[i] for order in orders}==set(ROUTES) for i in range(4))
    assert len({(a,b) for order in orders for a,b in zip(order,order[1:])})==12
    controls=read(logs/'environment.jsonl')
    assert len(controls)==32
    scope={(r['power_scheme'],r['plugged_in']) for r in controls}
    ac_blocks=[j for j in range(1,5) if all(r['plugged_in'] is True for r in controls if r['repeat']==j)]
    windows,sample,metas=[],[],[]
    for j in range(1,5):
        for route in ROUTES:
            meta,*rows,last=read(logs/f'r{j}_{route}.jsonl')
            assert meta['kind']=='metadata' and last['kind']=='complete' and meta['route']==route
            assert (meta['start'],meta['stop'],meta['items'])==(915002,939002,26512)
            assert meta['threads']==4 and meta['cores']==protocol['affinity']
            assert [r['window'] for r in rows]==list(range(1,25))
            assert [r['end'] for r in rows]==list(range(916002,939003,1000))
            assert all(abs(r['graph_ms']-r['count_ms']-r['maintain_ms'])<1e-9 for r in rows)
            init=meta['initialization_ms']/1000
            assert abs(init-(meta['prefix_ms']+meta['index_ms'])/1000)<1e-12
            updates=sum(r['graph_ms'] for r in rows)/1000
            record=dict(repeat=j,route=route,prefix_s=meta['prefix_ms']/1000,index_s=meta['index_ms']/1000,
                        init_s=init,update_s=updates,total_s=init+updates,peak_mib=last['peak_mib'],
                        **{f.replace('_ms','_s'):sum(r[f] for r in rows)/1000 for f in FIELDS})
            record['unallocated_update_s']=updates-sum(record[f.replace('_ms','_s')] for f in FIELDS)
            sample.append(record)
            metas.append(meta)
            cumulative=init
            for r in rows:
                cumulative+=r['graph_ms']/1000
                windows.append(dict(repeat=j,route=route,cumulative_s=cumulative,**r))
    csv_out(output/'repeat_costs.csv',sample)
    csv_out(output/'window_costs.csv',windows)

    groups={route:[r for r in sample if r['route']==route] for route in ROUTES}
    metrics=('prefix_s','index_s','init_s','update_s','total_s','count_s','selection_s','state_s',
             'normalization_s','unallocated_update_s','peak_mib')
    routes={route:{k:summary([r[k] for r in groups[route]]) for k in metrics} for route in ROUTES}
    state={name:{k:next(m[k] for m in metas if m['route']==name)
                for k in ('full_neighbor_entries','ranked_keys','winner_memberships')} for name in ROUTES}
    assert all(all(m[k]==state[m['route']][k] for k in state[m['route']]) for m in metas)

    audit=read(logs/'verification.jsonl')
    header,*check_windows,finish=audit
    assert finish['kind']=='complete' and finish['route_windows']==96 and len(check_windows)==24
    users=header['users']
    checks={(r['window'],name):row for r in check_windows for name,row in r['checks'].items()}
    assert all(r['users']==users and r['counts_exact'] and r['histories_exact'] for r in check_windows)
    assert len(checks)==96 and all(c['graph_state_exact'] and c['normalized_support_exact']
            and c['features_bitwise_equal'] and c['top20_matches']==users for c in checks.values())
    assert all(c['independent_scoring']==(j==24) for (j,_),c in checks.items())
    assert all(c['top20_sha256']==check_windows[j-1]['reference_top20_sha256'] for (j,_),c in checks.items())
    assert all(r[k]==checks[r['window'],r['route']][k] for r in windows for k in ('operator_nnz','candidate_keys'))
    assert all(checks[j,'partial']['candidate_keys']==checks[j,'affected_rows']['candidate_keys'] for j in range(1,25))
    candidates={name:sum(checks[j,name]['candidate_keys'] for j in range(1,25)) for name in ROUTES}

    by_window={(r['repeat'],r['route'],r['window']):r for r in windows}
    paired,paired_rows={},[]
    for baseline,route in PAIRS:
        key=baseline+'-'+route
        vals=list(zip(groups[baseline],groups[route],strict=True))
        net=[a['total_s']-b['total_s'] for a,b in vals]
        update=[a['update_s']-b['update_s'] for a,b in vals]
        setup=[a['init_s']-b['init_s'] for a,b in vals]
        work=[a['selection_s']-b['selection_s'] for a,b in vals]
        by_repeat=[]
        for j in range(1,5):
            windows_diff=[by_window[j,baseline,i]['cumulative_s']-by_window[j,route,i]['cumulative_s'] for i in range(1,25)]
            assert abs(windows_diff[-1]-net[j-1])<1e-9
            first,persistent=crossing([setup[j-1],*windows_diff])
            by_repeat.append(dict(repeat=j,contrast=key,setup_s=setup[j-1],update_s=update[j-1],net_s=net[j-1],
                                  first_win=first,persistent_win=persistent))
        paired_rows.extend(by_repeat)
        wins=sum(by_window[j,baseline,i]['graph_ms']>by_window[j,route,i]['graph_ms']
                 for j in range(1,5) for i in range(1,25))
        paired[key]=dict(net=summary(net),update=summary(update),setup=summary(setup),selection=summary(work),
                         percent=100*mean(net)/routes[baseline]['total_s']['mean'],
                         faster_windows=wins,by_repeat=by_repeat,
                         ac_boundary_net_s=mean(net[j-1] for j in ac_blocks) if ac_blocks else None)
    csv_out(output/'paired_costs.csv',paired_rows)
    return dict(routes=routes,paired=paired,index_entries=state,candidates=candidates,users=users,
                query_windows=users*24,independent_route_query_lists=users*4,
                operator_max_abs_error=max(c['normalized_max_abs_error'] for c in checks.values()),
                power_states=sorted(scope,key=str),ac_boundary_blocks=ac_blocks)


def export(data,latex):
    def range_text(item,precision=2):
        return f'{item["mean"]:.{precision}f} [{item["low"]:.{precision}f}, {item["high"]:.{precision}f}]'

    route=data['routes']
    tex_rows(latex/'round11_cost_rows.tex',[(LABEL[k],f'{route[k]["init_s"]["mean"]:.2f}',
             f'{route[k]["update_s"]["mean"]:.2f}',range_text(route[k]['total_s']),range_text(route[k]['peak_mib'],1)) for k in ROUTES])
    tags=dict(affected_rows='Full Sort',partial='Partial',view='View',CINM='CINM')
    pairs=data['paired']
    def signed(value): return f'{value:+.2f}' if abs(value)>=.005 else '0.00'
    tex_rows(latex/'round11_pair_rows.tex',[(rf'{tags[a]} $\to$ {tags[b]}',signed(p['setup']['mean']),
        signed(p['update']['mean']),range_text(p['net']),f'{p["faster_windows"]}/96')
        for a,b in PAIRS for p in [pairs[a+'-'+b]]])
    tex_rows(latex/'round11_phase_rows.tex',[(LABEL[k],*(f'{route[k][phase]["mean"]:.2f}' for phase in
             ('count_s','selection_s','state_s','normalization_s','unallocated_update_s'))) for k in ROUTES])
    def money(item): return f'{item:.2f}'
    labels={'affected_rows-partial':'Heap','affected_rows-view':'ViewFull','partial-view':'ViewHeap',
            'affected_rows-CINM':'CINMFull','partial-CINM':'CINMHeap'}
    values={}
    for k,name in labels.items():
        p=pairs[k]
        values[name+'Net']=money(p['net']['mean'])
        values[name+'Pct']=f'{p["percent"]:.1f}'
        if name=='Heap':
            values['HeapUpdate']=money(p['update']['mean'])
        if k.startswith('partial-'):
            values.update({name+'Update':money(p['update']['mean']),
                           name+'Wins':p['faster_windows'],name+'Cross':', '.join(
                               str(r['persistent_win']) if r['persistent_win'] is not None else 'none'
                               for r in p['by_repeat']),
                           name+'AC':money(p['ac_boundary_net_s']) if p['ac_boundary_net_s'] is not None else '--'})
    mantissa,power=f'{data["operator_max_abs_error"]:.2e}'.split('e')
    values.update(HeapUsers=f'{data["users"]:,}',HeapQueries=f'{data["query_windows"]:,}',
        HeapFinalLists=f'{data["independent_route_query_lists"]:,}',HeapError=(r'\('+mantissa+r'\times10^{'+str(int(power))+r'}\)'
        if data['operator_max_abs_error'] else 'zero'),FullObserved=f'{data["index_entries"]["partial"]["full_neighbor_entries"]:,}',
        BoundedKeys=f'{data["index_entries"]["view"]["ranked_keys"]:,}',FullScans=f'{data["candidates"]["partial"]:,}',
        CINMCandidates=f'{data["candidates"]["CINM"]:,}',ViewChangedKeys=f'{data["candidates"]["view"]:,}',
        HeapSelectS=money(route['partial']['selection_s']['mean']),FullSelectS=money(route['affected_rows']['selection_s']['mean']))
    (latex/'round11_values.tex').write_text(''.join(rf'\newcommand{{\{k}}}{{{v}}}'+'\n' for k,v in values.items()),encoding='utf-8')


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--logs',type=Path,default=ROOT/'evidence/long_replay')
    args=parser.parse_args()
    result=stats(args.logs,ROOT/'evidence')
    export(result,ROOT/'latex')
    (ROOT/'evidence/partial_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
