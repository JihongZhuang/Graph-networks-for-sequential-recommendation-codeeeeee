"""Paired replay and independent graph/ranking audit for the full-row heap baseline."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
import ctypes
from hashlib import file_digest, sha256
from heapq import nsmallest
import json
from math import comb
import os
from pathlib import Path
import pickle
import subprocess
import sys

import psutil


ROOT = Path(__file__).resolve().parent.parent
DATASET = 'Yelp2018_matched'
BATCH, WINDOWS, K = 1000, 24, 20
ROUTES = ('affected_rows', 'partial', 'view', 'CINM')
# Balanced positions and predecessor pairs within the four replay blocks.
ORDERS = ((0, 1, 3, 2), (1, 2, 0, 3), (2, 3, 1, 0), (3, 0, 2, 1))


def emit(**row):
    print(json.dumps(row),flush=True)


def run_driver(root, output):
    sys.path.insert(0,str(ROOT/'round4'))
    from round4_timing import control_snapshot, cpu_classes

    cores = sorted(psutil.Process().cpu_affinity())
    previous = json.loads((ROOT/'round4/evidence/balanced/protocol.json').read_text(encoding='utf-8'))
    affinity = previous['affinity']
    assert len(affinity)==4 and set(affinity)<=set(cores)
    output.mkdir(parents=True,exist_ok=False)
    environment = dict(os.environ, PYTHONPATH=str(root/'outputs'), PYTHONHASHSEED='0',
                       PYTHONIOENCODING='utf-8', PYTHONDONTWRITEBYTECODE='1',
                       OMP_NUM_THREADS='4', OPENBLAS_NUM_THREADS='4', MKL_NUM_THREADS='4')
    orders = [[ROUTES[i] for i in row] for row in ORDERS]
    files = ['outputs/casg_cinm.py','outputs/casg_major_revision.py','outputs/integration_casg.py',
             'outputs/saeif_casg_pilot.py','outputs/exact_polynomial.py','outputs/saeif_casg_sasrec.py',
             f'work/saeif/casg/{DATASET}/events.tsv', f'work/saeif/casg/{DATASET}/bert_cls.pkl',
             f'work/saeif/casg/{DATASET}/sasrec_validation_selected.pt']
    frozen = {}
    for path in files:
        with (root/path).open('rb') as handle:
            frozen[path] = file_digest(handle,'sha256').hexdigest()
    meta = dict(orders=orders,affinity=affinity,threads=4,efficiency_classes=cpu_classes(),
                batch=BATCH,windows=WINDOWS,k=K,scope='fresh isolated process per route and repeat',
                audit='independent of timing',frozen_sha256=frozen)
    (output/'protocol.json').write_text(json.dumps(meta,indent=2)+'\n',encoding='utf-8')

    def worker(route, stem):
        command = [sys.executable,str(Path(__file__).resolve()),'--route',route,'--cores',*map(str,affinity)]
        with (output/f'{stem}.jsonl').open('wb') as log,(output/f'{stem}.err').open('wb') as error:
            subprocess.run(command,cwd=root,env=environment,stdout=log,stderr=error,check=True)

    with (output/'environment.jsonl').open('w',encoding='utf-8') as log:
        for repeat,order in enumerate(orders,1):
            for position,route in enumerate(order,1):
                key = dict(repeat=repeat,position=position,route=route)
                print(f'Running repeat {repeat}, position {position}: {route}',flush=True)
                log.write(json.dumps(dict(**key,phase='before',**control_snapshot()))+'\n'); log.flush()
                worker(route,f'r{repeat}_{route}')
                log.write(json.dumps(dict(**key,phase='after',**control_snapshot()))+'\n'); log.flush()
        print('Timing complete. Running the independent graph and ranking audit.',flush=True)
        worker('verify','verification')


def run_worker(route, cores):
    proc = psutil.Process()
    proc.cpu_affinity(cores)
    assert sorted(proc.cpu_affinity())==cores
    if os.name=='nt':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    import numpy as np
    import torch
    from casg_cinm import FullRowIndex, edge, load_replay
    from casg_major_revision import INDEXES, maintain
    from integration_casg import append_merged
    from saeif_casg_pilot import append, timed
    from saceif_benchmark import peak_mib
    from threadpoolctl import threadpool_limits

    class PartialRows(FullRowIndex):
        def select(self, i, new_neighbors, counts):
            row = self.neighbors.setdefault(i,set())
            row.update(new_neighbors)
            if len(row)<=K:
                return row.copy(),len(row)
            return set(nsmallest(K,row,key=lambda j:(-counts[edge(i,j)],str(j)))),len(row)

    # Equal weights straddling rank K, with lexical rather than numeric ties.
    tied = Counter({(0,j):4 for j in range(1,28)})
    assert PartialRows(tied,28).select(0,{27},tied)==FullRowIndex(tied,28).select(0,{27},tied)
    indexes = {name:INDEXES[name] for name in ROUTES if name!='partial'}
    indexes['partial'] = PartialRows
    torch.set_num_threads(4)
    torch.manual_seed(30)
    folder = Path('work/saeif/casg')/DATASET
    with threadpool_limits(limits=4):
        train,test,_,weights,_,n = load_replay(folder,Path('outputs')/f'saceif_general_casg_{DATASET}.txt')
        start = len(train)-BATCH*WINDOWS
        assert (start,len(train))==(915002,939002)
        if route=='verify':
            verify(folder,train,test,weights,n,start,indexes)
            return
        counts,histories = Counter(),defaultdict(list)
        _,prefix_ms = timed(lambda:append(train[:start],counts,histories))
        state,index_ms = timed(lambda:indexes[route](counts,n))
        emit(kind='metadata',route=route,dataset=DATASET,items=n,start=start,stop=len(train),batch=BATCH,windows=WINDOWS,
             prefix_ms=prefix_ms,index_ms=index_ms,initialization_ms=prefix_ms+index_ms,initial_peak_mib=peak_mib(),
             cores=cores,threads=torch.get_num_threads(),priority=str(proc.nice()),
             full_neighbor_entries=sum(map(len,state.neighbors.values())) if hasattr(state,'neighbors') else 0,
             ranked_keys=sum(map(len,state.rows.values())) if hasattr(state,'rows') else 0,
             winner_memberships=sum(map(len,state.winners.values())))
        for window in range(1,WINDOWS+1):
            end = start+window*BATCH
            changed,count_ms = timed(lambda:append_merged(train[end-BATCH:end],counts,histories))
            (op,phases),maintain_ms = timed(lambda:maintain(state,counts,changed))
            emit(kind='window',window=window,end=end,count_ms=count_ms,maintain_ms=maintain_ms,
                 graph_ms=count_ms+maintain_ms,peak_mib=peak_mib(),operator_nnz=op.nnz,**phases)
        emit(kind='complete',windows=WINDOWS,peak_mib=peak_mib())


def verify(folder,train,test,weights,n,start,indexes):
    import numpy as np
    from numpy.polynomial import Polynomial
    import torch
    from casg_major_revision import maintain
    from exact_polynomial import full_layers, polynomial
    from integration_casg import append_merged, rank_checked
    from saeif_casg_pilot import NeighborIndex, append, matrix
    from saeif_casg_sasrec import SampledProjection, author_model

    with (folder/'bert_cls.pkl').open('rb') as handle:
        inputs = np.asarray(pickle.load(handle),np.float64)
    inputs -= inputs.mean(axis=0)
    model = author_model(torch.from_numpy(inputs).float())
    model.in_proj = SampledProjection(model.in_proj,n)
    model.load_state_dict(torch.load(folder/'sasrec_validation_selected.pt',weights_only=True))
    depth = len(weights)-1
    p,q = Polynomial([.5,.5]),Polynomial([.5,-.5])
    coeff = sum(w*comb(depth,k)*p**k*q**(depth-k) for k,w in enumerate(weights)).coef

    def filtered(operator):
        z = polynomial(full_layers(operator,inputs,depth),coeff)
        isolated = np.diff(operator.indptr)==0
        z[isolated] = inputs[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(z).float())

    counts,histories = Counter(),defaultdict(list)
    append(train[:start],counts,histories)
    users = np.asarray(sorted(u for u,h in histories.items() if h and test.loc[u] not in h))
    assert len(users)>=5000
    states = {name:indexes[name](counts,n) for name in ROUTES}
    emit(kind='metadata',scope='untimed full graph and complete-catalogue audit',users=len(users),items=n,
         windows=WINDOWS,independent_rank_windows=[WINDOWS],routes=ROUTES,start=start,stop=len(train))
    for window in range(1,WINDOWS+1):
        end = start+window*BATCH
        changed = append_merged(train[end-BATCH:end],counts,histories)
        direct_counts,direct_histories = Counter(),defaultdict(list)
        append(train[:end],direct_counts,direct_histories)
        assert direct_counts==counts and direct_histories==histories
        full = NeighborIndex(direct_counts)
        ref = matrix(full.weights,n).sorted_indices()
        links,degrees = defaultdict(set),np.zeros(n,dtype=np.int64)
        for (i,j),w in full.weights.items():
            links[i].add(j); links[j].add(i)
            degrees[i] += w; degrees[j] += w
        ref_features = filtered(ref)
        top,_,_,_ = rank_checked(model,ref_features,direct_histories,users,test)
        top_digest = sha256(top.astype('<i8').tobytes()).hexdigest()
        checks = {}
        for name,state in states.items():
            op,phases = maintain(state,counts,changed)
            op = op.sorted_indices()
            assert {i:row for i,row in state.winners.items() if row}==full.chosen
            assert state.weights==full.weights and np.array_equal(state.degree,degrees)
            assert {i:row for i,row in state.links.items() if row}==links
            if hasattr(state,'neighbors'):
                assert state.neighbors.keys()==full.adj.keys() and all(
                    len(row)==len(full.adj[i]) and all(j in full.adj[i] for j in row) for i,row in state.neighbors.items())
            assert np.array_equal(op.indptr,ref.indptr) and np.array_equal(op.indices,ref.indices)
            assert not np.any(op.data==0)
            error = float(np.max(np.abs((op-ref).data),initial=0))
            assert error<1e-14
            z = filtered(op)
            assert torch.equal(z,ref_features), (window,name)
            # Bitwise-equal scorer inputs certify the ranks on every window.
            # Also execute the same scorer independently on all four routes at the final window.
            independent = window==WINDOWS
            if independent:
                route_top,_,_,_ = rank_checked(model,z,histories,users,test)
                assert np.array_equal(route_top,top)
            checks[name] = dict(graph_state_exact=True,normalized_support_exact=True,
                normalized_max_abs_error=error,features_bitwise_equal=True,operator_nnz=op.nnz,
                candidate_keys=phases['candidate_keys'],top20_sha256=top_digest,top20_matches=len(users),
                independent_scoring=independent)
        emit(kind='window',window=window,end=end,users=len(users),counts_exact=True,histories_exact=True,
             reference_top20_sha256=top_digest,checks=checks)
        del full,direct_counts,direct_histories
    emit(kind='complete',windows=WINDOWS,users=len(users),route_windows=len(ROUTES)*WINDOWS)


if __name__=='__main__':
    parser = ArgumentParser()
    parser.add_argument('--root',type=Path)
    parser.add_argument('--output',type=Path)
    parser.add_argument('--route',choices=(*ROUTES,'verify'))
    parser.add_argument('--cores',type=int,nargs=4)
    args = parser.parse_args()
    if args.route:
        run_worker(args.route,args.cores)
    else:
        run_driver(args.root.resolve(),args.output.resolve())
