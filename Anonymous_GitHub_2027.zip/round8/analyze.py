"""Regenerate manuscript tables and audit totals from round 5 and round 8 records."""

from argparse import ArgumentParser
import csv
import json
from pathlib import Path
from statistics import mean, median


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT/'evidence'
TEX = ROOT/'latex'
ROUTES = {'recount':'Recount + full graph','counts_rebuild':'Incremental counts + full graph',
          'affected_rows':'Affected rows','view':'Bounded View','CINM':'CINM'}
PAIRS = [('affected_rows','view'),('affected_rows','CINM'),('CINM','view')]


def read(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]


def write_csv(name, rows):
    with (EVIDENCE/name).open('w',encoding='utf-8',newline='') as handle:
        writer = csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def write_rows(name, rows):
    body = ''.join(' & '.join(map(str,row))+r'\\'+'\n' for row in rows)
    (TEX/name).write_text(body+r'\bottomrule'+'\n',encoding='utf-8')


def stats(values):
    return dict(mean=mean(values),median=median(values),low=min(values),high=max(values))


def counted_replay(path):
    records = read(path)
    setups = {r['repeat']:r for r in records if r['kind'] == 'setup'}
    windows = [r for r in records if r['kind'] == 'window']
    assert len(setups) == 3 and len(windows) == 18 and records[-1]['kind'] == 'complete'
    rows, pairs = [], []
    for repeat, setup in sorted(setups.items()):
        run = [r for r in windows if r['repeat'] == repeat]
        assert [r['window'] for r in run] == list(range(1,7))
        routes = {}
        for name in ROUTES:
            phases = [r['routes'][name] for r in run]
            assert all(x['operator_max_error'] < 1e-14 for x in phases)
            counts = sum(x['count_ms'] for x in phases)/1000
            graph = sum(x['graph_ms'] for x in phases)/1000
            init = setup['setup_ms'][name]/1000
            prefix = setup['common_counts_ms']/1000 if name != 'recount' else 0.
            route = dict(repeat=repeat,route=name,prefix_s=prefix,index_s=init-prefix,init_s=init,
                         count_update_s=counts,graph_update_s=graph,update_s=counts+graph,total_s=init+counts+graph)
            routes[name] = route
            rows.append(route)
        for left, right in PAIRS:
            pairs.append(dict(repeat=repeat,comparison=f'{left}-{right}',
                              **{k:routes[left][k]-routes[right][k] for k in ('init_s','update_s','total_s')}))
    write_csv('count_reuse_repeats.csv',rows)
    write_csv('count_reuse_pairs.csv',pairs)
    write_rows('round8_repeat_rows.tex',
               [(r['repeat'],ROUTES[r['route']],*(f"{r[k]:.2f}" for k in
                 ('prefix_s','index_s','init_s','update_s','total_s'))) for r in rows if r['route'] in ('affected_rows','view','CINM')])
    route_summary = {k:{f:stats([r[f] for r in rows if r['route'] == k]) for f in ('init_s','update_s','total_s')}
                     for k in ROUTES}
    write_rows('round8_summary_rows.tex',[
        (ROUTES[route] if k=='init_s' else '', label, f'{result[k]["mean"]:.2f}', f'{result[k]["median"]:.2f}',
         f'[{result[k]["low"]:.2f}, {result[k]["high"]:.2f}]')
        for route,result in route_summary.items() if route in ('affected_rows','view','CINM')
        for k,label in [('init_s','Setup'),('update_s','Updates'),('total_s','Total')]])
    pair_summary = {k:{f:stats([r[f] for r in pairs if r['comparison'] == k]) for f in ('init_s','update_s','total_s')}
                    for k in dict.fromkeys(r['comparison'] for r in pairs)}
    labels = {'affected_rows-view':'Rows $-$ View','affected_rows-CINM':'Rows $-$ CINM','CINM-view':'CINM $-$ View'}
    write_rows('round8_pair_rows.tex',[
        (labels[key],*(f'{r["total_s"]:+.2f}' for r in pairs if r['comparison']==key),
         f'{value["total_s"]["mean"]:+.2f}',f'{value["total_s"]["median"]:+.2f}',
         f'[{value["total_s"]["low"]:+.2f}, {value["total_s"]["high"]:+.2f}]')
        for key,value in pair_summary.items()])
    return dict(routes=route_summary,pairs=pair_summary)


def recorded_setup(short, long):
    rows = []
    for p in sorted(short.glob('*.jsonl')):
        if 'sensitivity' in p.stem:
            continue
        for r in read(p):
            if r['kind']=='initialization' and r['route'] in ('affected_rows','view'):
                rows.append(dict(protocol='recommendation',dataset=p.stem,repeat=r['repeat'],route=r['route'],
                                 prefix_s=r['prefix_ms']/1000,index_s=r['index_ms']/1000,
                                 init_s=(r['prefix_ms']+r['index_ms'])/1000))
    for repeat in range(1,4):
        for route in ('affected_rows','view'):
            r=read(long/f'r{repeat}_{route}.jsonl')[0]
            rows.append(dict(protocol='long',dataset=r['dataset'],repeat=repeat,route=route,
                             prefix_s='',index_s='',init_s=r['initialization_ms']/1000))
    assert len(rows) == 24
    write_csv('recorded_initialization.csv',rows)
    return rows


def setup_diagnostic():
    rows = []
    paths = sorted(EVIDENCE.glob('setup_*.jsonl'))
    assert len(paths)==12
    for p in paths:
        records = read(p)
        assert records[-1]['kind'] == 'complete' and records[-1]['exact']
        for r in records[1:-1]:
            assert r['kind']=='index'
            r['ranking_state_ms'] = r['ranking_common_ms']+r['route_state_and_residual_ms']
            r['init_ms'] = r['fused_ms']+r['index_ms']
            for key in ('history_only_ms','count_from_histories_ms'):
                r[key] = records[-1][key]
            rows.append({k:v for k,v in r.items() if k!='kind'})
    write_csv('setup_diagnostic.csv',rows)
    fields = ('history_only_ms','count_from_histories_ms','fused_ms','ranking_state_ms',
              'retained_graph_ms','normalization_ms','init_ms')
    summary = {}
    table = []
    protocols = {'recommendation':'Short recommendation','long':'24,000-event stream','count_reuse':'Short count reuse'}
    for key, title in protocols.items():
        summary[key] = {}
        for route in ('affected_rows','view'):
            sample = [r for r in rows if r['protocol']==key and r['route']==route]
            assert len(sample)==3
            summary[key][route] = {k:stats([r[k]/1000 for r in sample]) for k in fields}
            table.append((title,ROUTES[route],*(f'{summary[key][route][k]["mean"]:.2f}' for k in fields)))
    write_rows('round8_setup_rows.tex',table)
    return summary


def first_future():
    records=read(EVIDENCE/'first_future.jsonl')
    target=records[0]
    windows=[r for r in records if r['kind']=='window']
    assert target['first']+target['skipped_users']==target['cohort']
    assert len(windows)==6 and records[-1]['query_windows']==target['first']*6
    assert all(r['full_cohort_replay_matches'] for r in windows)
    rows=[]
    for r in windows:
        n=r['users']
        row=dict(window=r['window'],batch=r['batch'],users=n,list_pct=100*r['changed_lists']/n,
                 set_pct=100*r['changed_sets']/n,jaccard=r['jaccard_sum']/n,
                 shift=r['absolute_shared_rank_shift']/r['shared_items'])
        for k in ('recall_10','ndcg_10','recall_20','ndcg_20'):
            row[f'{k}_stale_pct']=100*r['stale'][k]
            row[f'{k}_fresh_pct']=100*r['fresh'][k]
            row[f'{k}_delta_pp']=100*(r['fresh'][k]-r['stale'][k])
        rows.append(row)
    write_csv('first_future_windows.csv',rows)
    write_rows('round8_first_rows.tex',[(r['window'],r['batch'],f"{r['list_pct']:.2f}",f"{r['set_pct']:.2f}",
               f"{r['jaccard']:.4f}",f"{r['shift']:.4f}",f"{r['recall_10_delta_pp']:+.4f}",
               f"{r['ndcg_10_delta_pp']:+.4f}") for r in rows])
    pooled={b:{k:mean([r[k] for r in rows if r['batch']==b]) for k in ('list_pct','set_pct','jaccard')}
            for b in (10,100,1000)}
    return dict(target=target, windows=rows, pooled=pooled)


if __name__=='__main__':
    parser=ArgumentParser()
    parser.add_argument('--round5',type=Path,required=True)
    parser.add_argument('--short',type=Path,required=True)
    parser.add_argument('--long',type=Path,required=True)
    args=parser.parse_args()
    counted=counted_replay(args.round5/'counts_baseline.jsonl')
    original=recorded_setup(args.short,args.long)
    diagnostic=setup_diagnostic()
    future=first_future()
    checks=read(EVIDENCE/'csr_patch.jsonl')
    assert len(checks)==8 and all(x['operator_max_error']<1e-14 for x in checks)
    (EVIDENCE/'round8_audit.json').write_text(json.dumps(dict(count_reuse=counted,
        recorded_initialization=original,setup_diagnostic=diagnostic,first_future=future,csr_patch=checks),indent=2)+'\n',encoding='utf-8')
