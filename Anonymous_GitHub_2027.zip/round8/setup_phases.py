"""Measure setup subphases in the frozen constructors on matched Yelp prefixes."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
import ctypes
from inspect import getsource
from pathlib import Path
import platform
from time import perf_counter
from textwrap import dedent

import numpy as np
from threadpoolctl import threadpool_limits

from casg_cinm import WinnerIndex, load_replay
from casg_major_revision import INDEXES, add_history, emit
from saeif_casg_pilot import NeighborIndex, append, normalized, timed


def instrument(method, statements, phases):
    source = dedent(getsource(method))
    for before, probe in statements:
        assert source.count(before) == 1, before
        source = source.replace(before, probe + before)
    scope = dict(method.__globals__, clock=perf_counter, phases=phases)
    exec(compile(source, method.__code__.co_filename, 'exec'), scope)
    return scope[method.__name__]


def recount_histories(histories):
    counts = Counter()
    for sequence in histories.values():
        for j, item in enumerate(sequence):
            for previous in sequence[max(0,j-2):j]:
                if previous != item:
                    counts[tuple(sorted((item,previous)))] += 2
    return counts


def run(protocol, repeat, route):
    dataset = 'Yelp2018_matched'
    train, _, sizes, _, _, items = load_replay(Path('work/saeif/casg')/dataset,
                                              Path('outputs')/f'saceif_general_casg_{dataset}.txt')
    prefix = train[:len(train)-(24000 if protocol == 'long' else sum(sizes))]
    if protocol == 'recommendation':
        # Warm the common graph path before the original short-stream setup.
        warm_counts = Counter()
        append(prefix,warm_counts,defaultdict(list))
        normalized(warm_counts,items)
        del warm_counts

    counts,histories = Counter(),defaultdict(list)
    _, fused_ms = timed(lambda:append(prefix,counts,histories))
    phases = {}
    NeighborIndex.update = instrument(NeighborIndex.update,[
        ('    nodes=set()', '    start = clock()\n'),
        ('    for u,i in check:', '    phases["ranking_ms"] = (clock()-start)*1000\n    start = clock()\n'),
        ('    return len(nodes)', '    phases["union_ms"] = (clock()-start)*1000\n'),
    ],phases)
    WinnerIndex.__init__ = instrument(WinnerIndex.__init__,[
        ('    self.links =', '    start = clock()\n'),
        ('        self.operator =', '        phases["incidence_degree_ms"] = (clock()-start)*1000\n'),
    ],phases)
    # Reuse the original matrix function with a clock at the actual call boundary.
    globals_for_init = WinnerIndex.__init__.__globals__
    matrix = globals_for_init['matrix']

    def matrix_clock(weights,n):
        op, phases['normalization_ms'] = timed(lambda:matrix(weights,n))
        return op

    globals_for_init['matrix'] = matrix_clock
    rng = np.random.default_rng((974 if protocol == 'recommendation' else 3541)+repeat)
    if protocol == 'recommendation':
        rng.permutation(['full_rebuild','maintained'])
    route_list = list(INDEXES) if protocol == 'recommendation' else ['affected_rows','view','CINM']
    order = [route] if route else rng.permutation(route_list).tolist()
    emit(kind='setup', protocol=protocol, repeat=repeat, prefix=len(prefix), order=order, fused_ms=fused_ms,
         scope='resident prefix, instrumented setup diagnostic; filtering/scoring warmup excluded')
    states = {}
    for route in order:
        phases.clear()
        states[route], index_ms = timed(lambda:INDEXES[route](counts,items))
        residual = index_ms-sum(phases.values())
        assert residual >= 0
        emit(kind='index', protocol=protocol, repeat=repeat, route=route, index_ms=index_ms,
             fused_ms=fused_ms, ranking_common_ms=phases['ranking_ms'],
             route_state_and_residual_ms=residual, retained_graph_ms=phases['union_ms']+phases['incidence_degree_ms'],
             normalization_ms=phases['normalization_ms'])
    reference = normalized(counts,items)
    assert all((state.operator-reference).nnz == 0 for state in states.values())
    del states, reference
    history_only = defaultdict(list)
    _, history_ms = timed(lambda:add_history(prefix,history_only))
    standalone_counts, count_ms = timed(lambda:recount_histories(history_only))
    assert standalone_counts == counts and history_only == histories
    emit(kind='complete', protocol=protocol, repeat=repeat, routes=order,
         history_only_ms=history_ms, count_from_histories_ms=count_ms, exact=True)


if __name__ == '__main__':
    parser = ArgumentParser()
    parser.add_argument('protocol',choices=['recommendation','long','count_reuse'])
    parser.add_argument('repeat',type=int)
    parser.add_argument('--route',choices=['affected_rows','view'])
    args = parser.parse_args()
    assert (args.protocol == 'long') == bool(args.route)
    if platform.system() == 'Windows':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    with threadpool_limits(limits=4):
        run(args.protocol,args.repeat,args.route)
