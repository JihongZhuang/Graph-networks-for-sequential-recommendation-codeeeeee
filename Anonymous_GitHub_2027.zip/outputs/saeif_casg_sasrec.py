"""Run the author SASRec class with a local sequence loader on CPU."""
import ast
from pathlib import Path
from types import SimpleNamespace
from time import perf_counter
from typing import Dict, Tuple, Union

import numpy as np
import torch
from torch import nn
from torch.nn import functional as F


class SampledProjection(nn.Module):
    """Project only item rows read by the author's sampled BCE objective."""
    def __init__(self, projection, catalog_size):
        super().__init__()
        self.projection=projection
        self.catalog_size=catalog_size
        self.selected=None
        self.catalog=None

    def forward(self, features):
        if features.ndim!=2 or len(features)!=self.catalog_size:
            return self.projection(features)
        if self.catalog is not None:
            return self.catalog
        if self.selected is None:
            return self.projection(features)
        values=self.projection(features[self.selected])
        return values.new_zeros((len(features),values.shape[1])).index_copy(0,self.selected,values)


def author_model(features):
    # FreeRec provides fields and the training driver. The model class and its
    # encode, BCE objective and full-catalog score run directly from the release.
    class SeqRecArch(nn.Module):
        NUM_PADS = 1
        PADDING_VALUE = 0
        ISeq, IPos, INeg = "sequence", "positive", "negative"

        def __init__(self, dataset):
            super().__init__()
            self.Item = SimpleNamespace(count=len(features))

    free = SimpleNamespace(models=SimpleNamespace(SeqRecArch=SeqRecArch),
                           criterions=SimpleNamespace(BCELoss4Logits=nn.BCEWithLogitsLoss))
    source=Path("work/saeif/CASG-main/sasrec/main.py")
    wanted={"_build_input_projection","PointWiseFeedForward","SASRec"}
    tree=ast.parse(source.read_text(encoding="utf-8"))
    nodes=[node for node in tree.body if getattr(node,"name",None) in wanted]
    mod=ast.Module(body=[ast.ImportFrom(module="__future__",names=[ast.alias(name="annotations")],
                                        level=0,lineno=1,col_offset=0),*nodes],type_ignores=[])
    scope=dict(nn=nn,torch=torch,np=np,Dict=Dict,Tuple=Tuple,Union=Union,freerec=free,
               cfg=SimpleNamespace(loss="BCE"),os=SimpleNamespace(path=__import__("os").path),
               _load_item_features=lambda path:features,infoLogger=lambda s:None)
    exec(compile(ast.fix_missing_locations(mod),str(source),"exec"),scope)
    return scope["SASRec"](SimpleNamespace(path="."),maxlen=50,embedding_dim=64,
                           dropout_rate=.5,num_blocks=2,num_heads=1,tfile="features",
                           text_proj_mode="linear")


def pad(histories, users):
    data=np.zeros((len(users),50),dtype=np.int64)
    for j,u in enumerate(users):
        last=histories[u][-50:]
        if len(last):
            data[j,-len(last):]=np.asarray(last)+1
    return torch.from_numpy(data)


@torch.no_grad()
def rank(model, features, histories, users, keep=None, k=20):
    model.text_item_feats.copy_(features)
    model.eval()
    model.in_proj.catalog=model.in_proj.projection(model.text_item_feats)
    orders=[]
    for start in range(0,len(users),128):
        sub=users[start:start+128]
        data={"sequence":pad(histories,sub)}
        score=model.recommend_from_full(data)
        for j,u in enumerate(sub):
            seen=histories[u]
            if keep is not None:
                seen=[i for i in seen if i!=keep[u]]
            score[j,seen]=-torch.inf
        orders.append(torch.topk(score,k,dim=1).indices.numpy())
    model.in_proj.catalog=None
    return np.vstack(orders)


def train(features, histories, validation, folder, epochs=8):
    rng=np.random.default_rng(30)
    model=author_model(features)
    model.in_proj=SampledProjection(model.in_proj,len(features))
    optimizer=torch.optim.Adam(model.parameters(),lr=.0005,weight_decay=.00001)
    users=np.asarray([u for u,history in histories.items() if len(history)>1 and u in validation])
    val=rng.choice(users,min(2500,len(users)),replace=False)
    best=-1
    for epoch in range(1,epochs+1):
        start=perf_counter()
        model.train()
        losses=[]
        for batch in np.array_split(rng.permutation(users),max(1,int(np.ceil(len(users)/128)))):
            seq=pad({u:histories[u][:-1] for u in batch},batch)
            pos=pad({u:histories[u][1:] for u in batch},batch).clamp_min(1)-1
            neg=rng.integers(0,len(features),size=pos.shape)
            for j,u in enumerate(batch):
                invalid=np.isin(neg[j],histories[u])
                while invalid.any():
                    neg[j,invalid]=rng.integers(0,len(features),size=invalid.sum())
                    invalid=np.isin(neg[j],histories[u])
            optimizer.zero_grad(set_to_none=True)
            neg=torch.from_numpy(neg)
            mask=seq!=0
            model.in_proj.selected=torch.unique(torch.cat((pos[mask],neg[mask])))
            loss=model.fit({"sequence":seq,"positive":pos,"negative":neg})
            loss.backward()
            optimizer.step()
            losses.append(loss.item())
        model.in_proj.selected=None
        order=rank(model,features,histories,val,validation,k=5)
        hit=order==np.asarray([validation[u] for u in val])[:,None]
        ndcg=float((hit/np.log2(np.arange(2,7))).sum(axis=1).mean())
        if ndcg>best:
            best=ndcg
            torch.save(model.state_dict(),Path(folder)/"sasrec_validation_selected.pt")
        print(f"SASRec epoch={epoch},loss={np.mean(losses):.6f},valid_ndcg5={ndcg:.6f},seconds={perf_counter()-start:.1f}",flush=True)
    model.load_state_dict(torch.load(Path(folder)/"sasrec_validation_selected.pt",weights_only=True))
    return model
