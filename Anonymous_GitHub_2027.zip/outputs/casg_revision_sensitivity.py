"""Graph-only Yelp diagnostics for normalization, candidate selection and K."""
from collections import Counter, defaultdict
from types import SimpleNamespace
from pathlib import Path
import heapq

import numpy as np
from threadpoolctl import threadpool_limits

from casg_major_revision import append_merged, emit, maintain
from casg_cinm import FullRowIndex, WinnerIndex, edge, load_replay
from saeif_casg_pilot import append, matrix, timed


def ranked_state(counts, k):
    incident = defaultdict(list)
    for i, j in counts:
        incident[i].append(j)
        incident[j].append(i)
    winners = defaultdict(set, {i:set(heapq.nsmallest(k, row, key=lambda j:(-counts[edge(i,j)],str(j))))
                               for i,row in incident.items()})
    weights = {edge(i,j):counts[edge(i,j)] for i,row in winners.items() for j in row}
    return SimpleNamespace(chosen=winners, weights=weights)


class ConfigurableCertificate(WinnerIndex):
    def __init__(self, counts, n, k):
        self.k = k
        super().__init__(counts, n, ranked_state(counts, k))

    def select(self, i, new_neighbors, counts):
        candidates = self.winners[i] | new_neighbors
        return set(heapq.nsmallest(self.k, candidates, key=lambda j:(-counts[edge(i,j)],str(j)))), len(candidates)


def run():
    folder = Path('work/saeif/casg/Yelp2018_matched')
    train, _, sizes, _, _, n = load_replay(folder, Path('outputs/saceif_general_casg_Yelp2018_matched.txt'))
    begin = len(train) - sum(sizes)
    counts = Counter()
    histories = defaultdict(list)
    append(train[:begin], counts, histories)
    factorial = {}
    for label, cls in [('row', FullRowIndex), ('certificate', WinnerIndex)]:
        for local in (True, False):
            state = cls(counts, n)
            state.local_normalization = local
            factorial[f"{label}_{'local' if local else 'full'}"] = state
    cutoffs = {k: ConfigurableCertificate(counts, n, k) for k in (10, 20, 40)}
    rng = np.random.default_rng(1796)
    emit(kind='metadata', prefix=begin, items=n, windows=sizes, seed=1796, threads=4,
         scope='one matched graph-only replay per method; all timings exclude prefix and downstream scoring')
    for window, size in enumerate(sizes, 1):
        changed, count_ms = timed(lambda: append_merged(train[begin:begin+size], counts, histories))
        begin += size
        stages, ops = {}, {}
        for label in rng.permutation(list(factorial)):
            (op, examined, patch), update_ms = timed(lambda: factorial[label].update(counts, changed))
            ops[label] = op
            stages[label] = dict(update_ms=update_ms, candidate_keys=examined, patch_candidates=patch)
        reference = ops['row_full']
        for op in ops.values():
            assert np.max(np.abs((op-reference).data),initial=0)<1e-14
        cutoff_rows={}
        for k in rng.permutation(list(cutoffs)):
            state=cutoffs[k]
            previous_degree=state.degree.copy()
            (op, metrics), update_ms=timed(lambda: maintain(state, counts, changed))
            degrees=[len(state.links[i]) for i in np.flatnonzero(previous_degree!=state.degree)]
            if k==20:
                assert np.max(np.abs((op-reference).data),initial=0)<1e-14
            if window==len(sizes):
                rebuilt=ranked_state(counts,k)
                assert rebuilt.weights==state.weights
                assert np.max(np.abs((op-matrix(rebuilt.weights,n)).data),initial=0)<1e-14
            cutoff_rows[int(k)]=dict(update_ms=update_ms, kept_edges=len(state.weights),
                                    max_changed_node_degree=max(degrees,default=0),
                                    changed_node_incidence=sum(degrees), **metrics)
        emit(kind='window',window=window,batch=size,changed_pairs=len(changed),count_ms=count_ms,
             factorial=stages,cutoffs=cutoff_rows)


if __name__=='__main__':
    with threadpool_limits(limits=4):
        run()
