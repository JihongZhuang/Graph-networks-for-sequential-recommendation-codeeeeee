"""Separate integration version: joint CASG state, shared by CINM and full order."""
import argparse
from collections import Counter,defaultdict
from math import comb
import json
from pathlib import Path
import pickle

import numpy as np
from numpy.polynomial import Polynomial
from scipy.sparse import csr_matrix
import torch

from casg_cinm import WinnerIndex,OrderedIndex,FullRowIndex,MaterializedTopK,edge,load_replay
from d_author_kernel_benchmark import quality
from exact_polynomial import full_layers,polynomial
from integration_factored_core import ScaledCore
from saeif_casg_pilot import append,full_graph,matrix,timed
from saeif_casg_sasrec import SampledProjection,author_model,pad
from saceif_benchmark import peak_mib


def append_merged(events,counts,histories):
    increments=Counter()
    for u,i,_ in events:
        history=histories[u]
        for j in history[-2:]:
            if i!=j:increments[edge(i,j)]+=2
        history.append(i)
    counts.update(increments)
    return set(increments)


def configure(index,refs=True,selection_only=True,event_degree=True,local=True,lazy=False):
    index.refcounts=Counter(edge(i,j) for i,row in index.winners.items() for j in row) if refs else None
    index.selection_only=selection_only;index.event_degree=event_degree
    index.local=local;index.lazy=lazy
    if lazy:
        pairs=list(index.weights);u,v=np.asarray(pairs).T;w=np.array([index.weights[p] for p in pairs],float)
        index.raw=csr_matrix((np.tile(w,2),(np.r_[u,v],np.r_[v,u])),shape=index.operator.shape)
    return index


def joint_update(index,counts,changed):
    candidates=defaultdict(set)
    for i,j in changed:candidates[i].add(j);candidates[j].add(i)
    affected=set(changed);examined=0;selection_changes=0
    for i,neighbors in candidates.items():
        before=index.winners[i];after,compared=index.select(i,neighbors,counts);examined+=compared
        if before!=after or not index.selection_only:
            selection_changes+=before!=after
            lost,gained=(before-after,after-before) if index.selection_only else (before,after)
            if index.refcounts is not None:
                for j in lost:
                    pair=edge(i,j);index.refcounts[pair]-=1
                    if index.refcounts[pair]==0:del index.refcounts[pair]
                for j in gained:index.refcounts[edge(i,j)]+=1
            affected.update(edge(i,j) for j in before^after)
            index.winners[i]=after
    degree_change=Counter();raw_changes={}
    for pair in affected:
        i,j=pair;old=index.weights.get(pair,0)
        retained=index.refcounts[pair]>0 if index.refcounts is not None else (j in index.winners[i] or i in index.winners[j])
        new=counts[pair] if retained else 0
        if new==old:continue
        raw_changes[pair]=new-old;degree_change[i]+=new-old;degree_change[j]+=new-old
        if new:
            index.weights[pair]=new;index.links[i].add(j);index.links[j].add(i)
        else:
            del index.weights[pair];index.links[i].remove(j);index.links[j].remove(i)
    if index.event_degree:
        for i,d in degree_change.items():index.degree[i]+=d
    else:
        index.degree[:]=0
        for (i,j),weight in index.weights.items():index.degree[[i,j]]+=weight
    dirty=set(raw_changes)
    if index.lazy:
        if raw_changes:
            pairs=list(raw_changes);u,v=np.asarray(pairs).T;w=np.asarray([raw_changes[p] for p in pairs])
            index.raw=index.raw+csr_matrix((np.tile(w,2),(np.r_[u,v],np.r_[v,u])),shape=index.raw.shape)
        inv=np.divide(1.,np.sqrt(index.degree),out=np.zeros(len(index.degree)),where=index.degree>0)
        index.operator=ScaledCore(index.raw,inv)
    elif not index.local:
        index.operator=matrix(index.weights,len(index.degree))
    else:
        for i,d in degree_change.items():
            if d:dirty.update(edge(i,j) for j in index.links[i])
        if dirty:
            pairs=list(dirty);u,v=np.asarray(pairs).T
            w=np.array([index.weights.get(p,0) for p in pairs],float);present=w>0
            w[present]/=np.sqrt(index.degree[u[present]]*index.degree[v[present]])
            old=np.asarray(index.operator[u,v]).ravel();change=w-old
            index.operator=index.operator+csr_matrix((np.tile(change,2),(np.r_[u,v],np.r_[v,u])),shape=index.operator.shape)
    if hasattr(index,'old_counts'):
        for pair in changed:index.old_counts[pair]=counts[pair]
    return index.operator,dict(examined=examined,selection_changes=int(selection_changes),raw_changes=len(raw_changes),normalization_pairs=len(dirty))


@torch.no_grad()
def rank_checked(model,features,histories,users,test,reference=None,store=False):
    def prepare():
        model.text_item_feats.copy_(features);model.eval()
        model.in_proj.catalog=model.in_proj.projection(model.text_item_feats)
    _,measured_ms=timed(prepare)
    orders=[];max_error=0.
    scores_out=np.empty((len(users),len(features)),np.float32) if store else None
    for start in range(0,len(users),128):
        sub=users[start:start+128]
        def score_batch():return model.recommend_from_full({'sequence':pad(histories,sub)})
        score,ms=timed(score_batch);measured_ms+=ms
        raw=score.numpy()
        if reference is not None:max_error=max(max_error,float(np.max(np.abs(raw-reference[start:start+len(sub)]))))
        if store:scores_out[start:start+len(sub)]=raw
        def masked_top():
            for j,u in enumerate(sub):score[j,[i for i in histories[u] if i!=test[u]]]=-torch.inf
            return torch.topk(score,20,dim=1).indices.numpy()
        top,ms=timed(masked_top);measured_ms+=ms;orders.append(top)
    model.in_proj.catalog=None
    return np.vstack(orders),scores_out,max_error,measured_ms


def memory_run(folder,log,route):
    train,_,sizes,_,_,n=load_replay(folder,log);begin=len(train)-sum(sizes)
    counts=Counter();histories=defaultdict(list);append(train[:begin],counts,histories)
    prefix=peak_mib()
    constructors={'CINM':lambda:WinnerIndex(counts,n),'ordered':lambda:OrderedIndex(counts,n),
                  'affected_rows':lambda:FullRowIndex(counts,n),
                  'view':lambda:MaterializedTopK(counts,n),'joint_view':lambda:configure(MaterializedTopK(counts,n)),
                  'joint_CINM':lambda:configure(WinnerIndex(counts,n)),
                  'joint_ordered':lambda:configure(OrderedIndex(counts,n))}
    state,init_ms=timed(constructors[route]);maintenance_ms=0.
    for size in sizes:
        changed,append_ms=timed(lambda:append_merged(train[begin:begin+size],counts,histories))
        _,update_ms=timed(lambda:joint_update(state,counts,changed) if route.startswith('joint') else state.update(counts,changed))
        maintenance_ms+=append_ms+update_ms;begin+=size
    print(json.dumps(dict(dataset=folder.name,route=route,scope='isolated graph-state process; includes full counts and input',
                          prefix_peak_mib=prefix,peak_mib=peak_mib(),init_ms=init_ms,maintenance_ms=maintenance_ms)),flush=True)


def run(folder,log,repeats,graph_only=False,routes=None,publication=False):
    train,test,sizes,weights,total,n=load_replay(folder,log);begin0=len(train)-sum(sizes)
    if graph_only and publication:begin0-=sum(sizes)
    p,q=Polynomial([.5,.5]),Polynomial([.5,-.5]);depth=len(weights)-1
    coeff=sum(w*comb(depth,k)*p**k*q**(depth-k) for k,w in enumerate(weights)).coef
    with (folder/'bert_cls.pkl').open('rb') as f:inputs=np.asarray(pickle.load(f),np.float64)
    inputs-=inputs.mean(axis=0)
    model=None
    if not graph_only:
        model=author_model(torch.from_numpy(inputs).float());model.in_proj=SampledProjection(model.in_proj,n)
        model.load_state_dict(torch.load(folder/'sasrec_validation_selected.pt',weights_only=True));model.eval()
    print(json.dumps(dict(kind='metadata',dataset=folder.name,phase='development' if graph_only and publication else 'main',
                          prefix=begin0,stop=begin0+sum(sizes),graph_only=graph_only,publication=publication,
                          numeric_score_audit='repeat 1 last window, all users/catalog; extra audit if feature identity fails' if publication else 'every window',
                          unscored_ablation='graph/operator/representation equality; not additional user score executions')),
          flush=True)
    for repeat in range(1,repeats+1):
        counts=Counter();histories=defaultdict(list);append(train[:begin0],counts,histories)
        query=np.array(sorted(u for u,h in histories.items() if h and test.loc[u] not in h));assert len(query)>=5000
        targets=[{test.loc[u]} for u in query]
        constructors={'affected_rows':lambda:FullRowIndex(counts,n),'ordered':lambda:OrderedIndex(counts,n),
                      'CINM':lambda:WinnerIndex(counts,n),
                      'view':lambda:MaterializedTopK(counts,n),
                      'joint_view':lambda:configure(MaterializedTopK(counts,n)),
                      'joint_CINM':lambda:configure(WinnerIndex(counts,n)),
                      'joint_ordered':lambda:configure(OrderedIndex(counts,n))}
        if graph_only:
            extras={f'ablate_{key}':lambda kw=kw:configure(WinnerIndex(counts,n),**kw) for key,kw in
                          [('no_refs',{'refs':False}),('all_selections',{'selection_only':False}),
                           ('global_degrees',{'event_degree':False}),('global_norm',{'local':False}),('lazy_norm',{'lazy':True})]}
            if publication:constructors.update(extras)
            else:constructors={**extras,'joint_CINM':lambda:configure(WinnerIndex(counts,n))}
        elif routes:
            requested=set(routes)-{'full_rebuild'}
            assert requested<=constructors.keys() and 'full_rebuild' in routes
            constructors={k:v for k,v in constructors.items() if k in requested}
        states={}
        for name,constructor in constructors.items():
            states[name],ms=timed(constructor)
            print(json.dumps(dict(kind='initialization',dataset=folder.name,repeat=repeat,route=name,init_ms=ms,
                                  users=len(query),items=n,peak_mib=peak_mib(),count_keys=len(counts))),flush=True)
        begin=begin0;rng=np.random.default_rng(974+repeat)
        for window,size in enumerate(sizes,1):
            end=begin+size
            # Both append implementations are checked on fresh copies; timed main routes all
            # receive the same merged-count optimization, including the full-order baseline.
            if graph_only:
                copy_c=counts.copy();copy_h=defaultdict(list,{u:list(h) for u,h in histories.items()})
                changed_old,old_append_ms=timed(lambda:append(train[begin:end],copy_c,copy_h))
            changed,append_ms=timed(lambda:append_merged(train[begin:end],counts,histories))
            if graph_only:assert counts==copy_c and changed==changed_old and histories==copy_h
            reference,oracle_graph_ms=timed(lambda:full_graph(train[:end],n))
            oracle=polynomial(full_layers(reference,inputs,depth),coeff)
            oracle[np.diff(reference.indptr)==0]=inputs[np.diff(reference.indptr)==0]
            oracle_z=torch.nn.functional.normalize(torch.from_numpy(oracle).float())
            numeric_audit=not graph_only and (not publication or (repeat==1 and window==len(sizes)))
            reference_scores=None
            if numeric_audit:
                oracle_top,reference_scores,_,_=rank_checked(model,oracle_z,histories,query,test,store=True)
            results={};operations={};tops={};audit_features={}
            if not graph_only:operations['full_rebuild']=lambda:(full_graph(train[:end],n),{})
            for name,state in states.items():
                if name.startswith('joint') or name.startswith('ablate'):
                    operations[name]=lambda state=state:joint_update(state,counts,changed)
                else:
                    operations[name]=lambda state=state:(state.update(counts,changed)[0],{})
            for name in rng.permutation(list(operations)):
                (op,details),graph_ms=timed(operations[name]);graph_ms+=0 if name=='full_rebuild' else append_ms
                material=op.materialize() if isinstance(op,ScaledCore) else op
                error=float(np.max(np.abs((material-reference).data),initial=0))
                assert error<1e-14,(name,error)
                def filtering():
                    features=polynomial(full_layers(op,inputs,depth),coeff)
                    features[np.diff(material.indptr)==0]=inputs[np.diff(material.indptr)==0]
                    return torch.nn.functional.normalize(torch.from_numpy(features).float())
                z,filter_ms=timed(filtering)
                identical=torch.equal(z,oracle_z)
                m=dict(graph_ms=graph_ms,filter_ms=filter_ms,operator_error=error,feature_error=float((z-oracle_z).abs().max()),
                       identical_scorer_input=identical,**details)
                if not graph_only:
                    top,_,score_error,ranking_ms=rank_checked(model,z,histories,query,test,reference=reference_scores)
                    tops[name]=top
                    if not identical and not numeric_audit:audit_features[name]=z
                    m.update(rank_ms=ranking_ms,max_score_error=score_error if numeric_audit else None,
                             score_validation='exhaustive numeric audit' if numeric_audit else 'bitwise-equal scorer inputs plus directly evaluated lists' if identical else 'numeric audit required',
                             quality=[*quality(top[:,:10],targets),*quality(top,targets)],total_ms=graph_ms+filter_ms+ranking_ms)
                else:m.update(total_ms=graph_ms+filter_ms,scope='graph and filter only; no new full-user score claim')
                results[name]=m
            if not graph_only:
                if audit_features:
                    _,reference_scores,_,_=rank_checked(model,oracle_z,histories,query,test,store=True)
                    for name,z in audit_features.items():
                        _,_,error,_=rank_checked(model,z,histories,query,test,reference=reference_scores)
                        results[name].update(max_score_error=error,score_validation='exhaustive fallback audit for changed floating-point inputs')
                for name,m in results.items():
                    m['top20_matches']=int(np.all(tops[name]==tops['full_rebuild'],axis=1).sum())
                    m['correct']=m['top20_matches']==len(query) and (m['identical_scorer_input'] or
                        (m['max_score_error'] is not None and m['max_score_error']<1e-5))
                    assert m['correct'],(name,m)
            print(json.dumps(dict(kind='window',dataset=folder.name,repeat=repeat,window=window,batch=size,users=len(query),items=n,
                                  graph_only=graph_only,numeric_score_audit=numeric_audit,phase='development' if graph_only and publication else 'main',
                                  append_merged_ms=append_ms,append_original_ms=old_append_ms if graph_only else None,
                                  peak_mib=peak_mib(),routes=results)),flush=True)
            if not graph_only:del reference_scores
            begin=end


def check():
    rng=np.random.default_rng(893);events=np.array([(int(rng.integers(6)),int(rng.integers(35)),t) for t in range(200)])
    counts=Counter();histories=defaultdict(list);append(events[:100],counts,histories)
    states=[configure(WinnerIndex(counts,35)),configure(OrderedIndex(counts,35)),
            configure(MaterializedTopK(counts,35)),
            configure(WinnerIndex(counts,35),lazy=True),configure(WinnerIndex(counts,35),refs=False)]
    for a,b in [(100,110),(110,150),(150,200)]:
        changed=append_merged(events[a:b],counts,histories);reference=full_graph(events[:b],35)
        for state in states:
            op,_=joint_update(state,counts,changed);actual=op.materialize() if isinstance(op,ScaledCore) else op
            assert np.max(np.abs((actual-reference).data),initial=0)<1e-14
    print('Joint CASG count/selection/reference/degree/normalization checks passed.')


if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('dataset',nargs='?',choices=['Luxury_Beauty','Musical_Instruments','Yelp2018_matched']);p.add_argument('--repeats',type=int,default=3);p.add_argument('--graph-only',action='store_true');p.add_argument('--check',action='store_true');p.add_argument('--publication',action='store_true');p.add_argument('--routes');p.add_argument('--memory-route',choices=['CINM','ordered','joint_CINM','joint_ordered','view','joint_view','affected_rows']);a=p.parse_args()
    torch.set_num_threads(4)
    if a.check:check()
    elif a.memory_route:memory_run(Path('work/saeif/casg')/a.dataset,Path('outputs')/f'saceif_general_casg_{a.dataset}.txt',a.memory_route)
    else:run(Path('work/saeif/casg')/a.dataset,Path('outputs')/f'saceif_general_casg_{a.dataset}.txt',a.repeats,a.graph_only,a.routes.split(',') if a.routes else None,a.publication)
