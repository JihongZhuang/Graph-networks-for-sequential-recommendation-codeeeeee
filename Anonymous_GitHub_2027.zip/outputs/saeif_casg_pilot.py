"""CASG Bernstein refresh pilot, separate from downstream SASRec training."""
import csv
import importlib.util
import json
from math import comb
from pathlib import Path
import pickle
from time import perf_counter
import sys
from collections import Counter, defaultdict

import numpy as np
import pandas as pd
from scipy.sparse import csr_matrix, diags
import torch

from d_author_kernel_benchmark import quality


def timed(fn):
    t=perf_counter()
    value=fn()
    return value, (perf_counter()-t)*1000


def append(events, counts, histories):
    touched=set()
    for u,i,_ in events:
        history=histories[u]
        for j in history[-2:]:
            if i!=j:
                key=tuple(sorted((i,j)))
                counts[key]+=2
                touched.add(key)
        history.append(i)
    return touched


def normalized(counts, n):
    incident=defaultdict(list)
    for (i,j),c in counts.items():
        incident[i].append((j,c))
        incident[j].append((i,c))
    kept={tuple(sorted((i,j))) for i, neighbors in incident.items()
          for j,_ in sorted(neighbors,key=lambda pair:(-pair[1],str(pair[0])))[:20]}
    return matrix({key:counts[key] for key in kept},n)


def matrix(weights,n):
    u,i,w=zip(*[(u,i,weights[u,i]) for u,i in sorted(weights)])
    u,i,w=np.asarray(u),np.asarray(i),np.asarray(w,dtype=float)
    degree=np.bincount(u,w,minlength=n)+np.bincount(i,w,minlength=n)
    w/=np.sqrt(degree[u]*degree[i])
    return csr_matrix((np.tile(w,2),(np.r_[u,i],np.r_[i,u])),shape=(n,n))


class NeighborIndex:
    def __init__(self, counts):
        self.adj=defaultdict(dict)
        self.chosen=defaultdict(set)
        self.weights={}
        self.update(counts,counts)

    def update(self,counts,changed):
        nodes=set()
        for u,i in changed:
            self.adj[u][i]=self.adj[i][u]=counts[u,i]
            nodes.update((u,i))
        check=set(changed)
        for node in nodes:
            old=self.chosen[node]
            now=set(sorted(self.adj[node],key=lambda j:(-self.adj[node][j],str(j)))[:20])
            check.update(tuple(sorted((node,j))) for j in old^now)
            self.chosen[node]=now
        for u,i in check:
            if i in self.chosen[u] or u in self.chosen[i]:
                self.weights[u,i]=counts[u,i]
            else:
                self.weights.pop((u,i),None)
        return len(nodes)


def full_graph(events,n):
    c=Counter()
    append(events,c,defaultdict(list))
    return normalized(c,n)


def run(folder, use_sasrec=False, transfer=False, users=2500):
    torch.set_num_threads(4)
    torch.manual_seed(30)
    raw=pd.read_csv(folder/"events.tsv",sep="\t")
    index=raw.groupby("user",sort=False).cumcount()
    count=raw.groupby("user",sort=False).user.transform("size")
    train=raw[index<count-2].sort_values("time",kind="stable").to_numpy()
    test=raw[index==count-1].set_index("user").item
    validation=raw[index==count-2].set_index("user").item.to_dict()
    with (folder/"bert_cls.pkl").open("rb") as source:
        x=np.asarray(pickle.load(source),dtype=np.float64)
    x-=x.mean(axis=0)
    n=len(x)
    stop=len(train)
    sizes=(10,100,1000)*(2 if transfer else 1)
    start=stop-sum(sizes)
    c,histories=Counter(),defaultdict(list)
    append(train[:start],c,histories)
    eligible=np.array([u for u,items in histories.items() if items and test.loc[u] not in items])
    query=np.random.default_rng(30).choice(eligible,users,replace=False)
    targets=[{test.loc[u]} for u in query]
    old=normalized(c,n)
    neighbors,index_ms=timed(lambda:NeighborIndex(c))
    assert (matrix(neighbors.weights,n)!=old).nnz==0

    sys.path.insert(0,str(Path("work/saeif/casg_lib").resolve()))
    path=Path("work/saeif/CASG-main/filter/train_bernstein.py")
    spec=importlib.util.spec_from_file_location("casg_bernstein",path)
    author=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(author)
    from numpy.polynomial import Polynomial
    active=np.flatnonzero(np.diff(old.indptr))
    adj=old[active][:,active]
    identity=diags(np.ones(len(active)),format="csr")
    t_x=torch.from_numpy(x[active]).float()
    lap=author.scipy_csr_to_torch_sparse(identity-adj,torch.device("cpu"))
    degree=2 if use_sasrec else 4
    basis=author.precompute_bernstein_basis(lap,t_x,degree)
    fitted,info=author.train_bernstein_filter(basis,t_x,author.build_neighbor_lists(adj),alpha=.001,
                                              temperature=.2,epochs=6,batch_size=512,lr=.01,
                                              weight_decay=0.,seed=30)
    p,q=Polynomial([.5,.5]),Polynomial([.5,-.5])
    poly=sum(coef*comb(degree,k)*p**k*q**(degree-k) for k,coef in enumerate(info["coeffs"]))

    def layers(op):
        result=[x]
        for _ in range(degree):
            result.append(op@result[-1])
        return result

    cache,cache_ms=timed(lambda:layers(old))
    direct=sum(coef*v[active] for coef,v in zip(poly.coef,cache))
    np.testing.assert_allclose(direct,fitted.detach().numpy(),atol=2e-6,rtol=1e-5)
    def filtered(h,op):
        output=sum(coef*v for coef,v in zip(poly.coef,h))
        inactive=np.diff(op.indptr)==0
        output[inactive]=x[inactive]
        return torch.nn.functional.normalize(torch.from_numpy(output).float())

    if use_sasrec:
        from saeif_casg_sasrec import train as train_sasrec, rank as sasrec_rank
        sasrec=train_sasrec(filtered(cache,old),histories,validation,folder)

    def ranking(h,op):
        z=filtered(h,op)
        if use_sasrec:
            return sasrec_rank(sasrec,z,histories,query,test)
        order=[]
        for users in np.array_split(query,20):
            item=[histories[u][-1] for u in users]
            score=z[item]@z.T
            for j,u in enumerate(users): score[j,histories[u]]=-torch.inf
            order.append(torch.topk(score,20,dim=1).indices.numpy())
        return np.vstack(order)

    print(json.dumps(dict(dataset=folder.name,train=len(train),eligible=len(eligible),users=users,
                          offline_cache_ms=cache_ms,cache_mib=sum(v.nbytes for v in cache)/2**20,
                          fit_epochs=6,bernstein=info["coeffs"],neighbor_index_ms=index_ms,
                          sasrec=use_sasrec,transfer=transfer)),flush=True)

    def sparse_refresh(updated,previous,cached):
        delta=updated-previous
        direct=np.flatnonzero(np.diff(delta.indptr))
        support=np.empty(0,dtype=np.int64)
        value=np.empty((0,x.shape[1]))
        footprints=[]
        result=[x]
        for left,prior in zip(cached,cached[1:]):
            diffusion=updated[:,support].tocsr()
            reached=np.flatnonzero(np.diff(diffusion.indptr))
            support=np.union1d(direct,reached)
            value=delta[support]@left+diffusion[support]@value
            layer=prior.copy()
            layer[support]+=value
            result.append(layer)
            footprints.append(len(support))
        return result,footprints

    if transfer:
        calibration=[]
        begin=start
        for index,size in enumerate(sizes):
            end=begin+size
            def update_graph():
                changed=append(train[begin:end],c,histories)
                nodes=neighbors.update(c,changed)
                return matrix(neighbors.weights,n),nodes,len(changed)
            (updated,nodes,pairs),index_ms=timed(update_graph)
            def choose():
                feature=np.log1p([size,nodes,pairs])
                if len(calibration)<3:
                    return feature,"sparse"
                near=min(calibration,key=lambda row:np.linalg.norm(feature-row[0]))
                return feature,("sparse" if near[1]<.90*near[2] else "full")
            (feature,path),selection_ms=timed(choose)
            def exact_full():
                graph=full_graph(train[:end],n)
                return graph,layers(graph)
            def route():
                if path=="sparse":
                    return sparse_refresh(updated,old,cache)
                return layers(updated),[n]*degree
            if index%2==0:
                (full,ref),base_ms=timed(exact_full)
                ref_order,rank_full_ms=timed(lambda:ranking(ref,full))
                (new,footprint),filter_ms=timed(route)
                new_order,rank_new_ms=timed(lambda:ranking(new,updated))
            else:
                (new,footprint),filter_ms=timed(route)
                new_order,rank_new_ms=timed(lambda:ranking(new,updated))
                (full,ref),base_ms=timed(exact_full)
                ref_order,rank_full_ms=timed(lambda:ranking(ref,full))
            assert (updated!=full).nnz==0
            err=max(np.max(np.abs(a-b)) for a,b in zip(ref,new))
            assert err<1e-10
            if index<3:
                _,indexed_full_filter_ms=timed(lambda:layers(updated))
                calibration.append((feature,filter_ms,indexed_full_filter_ms))
            print(json.dumps(dict(batch=size,users=users,calibration=index<3,path=path,
                                  neighbor_rows=nodes,pair_updates=pairs,row_footprints=footprint,
                                  index_ms=index_ms,selection_ms=selection_ms,
                                  graph_and_full_refresh_ms=base_ms,b3_refresh_ms=filter_ms,
                                  rank_full_ms=rank_full_ms,rank_b3_ms=rank_new_ms,
                                  total_full_ms=base_ms+rank_full_ms,
                                  total_b3_ms=index_ms+selection_ms+filter_ms+rank_new_ms,
                                  max_error=float(err),top20_equal=int(np.all(ref_order==new_order,axis=1).sum()),
                                  quality=[*quality(ref_order[:,:10],targets),*quality(ref_order,targets)],
                                  b3_quality=[*quality(new_order[:,:10],targets),*quality(new_order,targets)])),flush=True)
            old,cache,begin=updated,new,end
        return
    begin=start
    for size in sizes:
        end=begin+size
        full,graph_full=timed(lambda:full_graph(train[:end],n))
        changed,append_ms=timed(lambda:append(train[begin:end],c,histories))
        updated,graph_local=timed(lambda:normalized(c,n))
        def maintain_graph():
            nodes=neighbors.update(c,changed)
            return nodes,matrix(neighbors.weights,n)
        (nodes,indexed),graph_indexed=timed(maintain_graph)
        assert (full!=updated).nnz==0
        assert (full!=indexed).nnz==0
        ref,full_ms=timed(lambda:layers(full))
        def delta_refresh():
            diff=updated-old
            d=np.zeros_like(x)
            result=[x]
            for left,right in zip(cache,cache[1:]):
                d=diff@left+updated@d
                result.append(right+d)
            return result
        inc,inc_ms=timed(delta_refresh)
        maxerr=max(np.max(np.abs(a-b)) for a,b in zip(ref,inc))
        assert maxerr<1e-10
        local=[x]+[v.copy() for v in cache[1:]]
        def row_refresh():
            delta=updated-old
            direct=np.flatnonzero(np.diff(delta.indptr))
            support=np.empty(0,dtype=np.int64)
            value=np.empty((0,x.shape[1]))
            footprints=[]
            for left,dst in zip(cache,local[1:]):
                diffusion=updated[:,support].tocsr()
                reached=np.flatnonzero(np.diff(diffusion.indptr))
                support=np.union1d(direct,reached)
                value=delta[support]@left+diffusion[support]@value
                dst[support]+=value
                footprints.append(len(support))
            return footprints
        footprints,local_ms=timed(row_refresh)
        local_err=max(np.max(np.abs(a-b)) for a,b in zip(ref,local))
        assert local_err<1e-10
        a,rank_full_ms=timed(lambda:ranking(ref,full))
        b,rank_inc_ms=timed(lambda:ranking(inc,updated))
        d,rank_local_ms=timed(lambda:ranking(local,updated))
        print(json.dumps(dict(batch=size,users=users,graph_full_ms=graph_full,graph_counts_ms=append_ms+graph_local,
                              graph_indexed_ms=append_ms+graph_indexed,neighbor_rows=nodes,
                              full_refresh_ms=full_ms,difference_refresh_ms=inc_ms,nnz=updated.nnz,
                              changed_nnz=(updated-old).nnz,max_error=float(maxerr),
                              rank_full_ms=rank_full_ms,rank_inc_ms=rank_inc_ms,
                              top20_equal=int(np.all(a==b,axis=1).sum()),
                              row_refresh_ms=local_ms,row_footprints=footprints,
                              row_max_error=float(local_err),rank_row_ms=rank_local_ms,
                              row_top20_equal=int(np.all(a==d,axis=1).sum()),
                              proxy_quality=[*quality(a[:,:10],targets),*quality(a,targets)])),flush=True)
        old,cache,begin=updated,ref,end


if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("folder",type=Path)
    parser.add_argument("--sasrec",action="store_true")
    parser.add_argument("--transfer",action="store_true")
    parser.add_argument("--users",type=int,default=2500)
    args=parser.parse_args()
    run(args.folder,args.sasrec,args.transfer,args.users)
