"""Prepare CASG Amazon input from the 2018 raw category archive."""
import csv
import gzip
import json
from pathlib import Path
import sys
import pandas as pd

root = Path("work/saeif/casg")
for category in sys.argv[1:]:
    folder = root/category
    folder.mkdir(exist_ok=True)
    with gzip.open(root/f"{category}.json.gz","rt",encoding="utf-8") as data:
        table = pd.DataFrame([(r["reviewerID"],r["asin"],r["unixReviewTime"])
                              for line in data if (r:=json.loads(line))],
                             columns=["user","item","time"])
    # These support thresholds reproduce the paper's category cardinalities.
    core = {"Luxury_Beauty":4,"Musical_Instruments":5}[category]
    while True:
        n = len(table)
        table = table[table.user.map(table.user.value_counts())>=core]
        table = table[table.item.map(table.item.value_counts())>=core]
        if len(table)==n:
            break
    table=table.sort_values(["user","time"],kind="stable")
    u=sorted(table.user.unique())
    i=sorted(table.item.unique())
    table.user=table.user.map(dict(zip(u,range(len(u)))))
    table.item=table.item.map(dict(zip(i,range(len(i)))))
    table.to_csv(folder/"events.tsv",sep="\t",index=False)
    item_set=set(i)
    metadata={}
    with gzip.open(root/f"meta_{category}.json.gz","rt",encoding="utf-8") as data:
        for line in data:
            r=json.loads(line)
            if r["asin"] in item_set:
                fields=[r.get("title",""),r.get("category",[]),r.get("description",[])]
                metadata[r["asin"]]=" ".join(" ".join(map(str,f)) if isinstance(f,list) else str(f) for f in fields)
    with (folder/"item_text.tsv").open("w",encoding="utf-8",newline="") as data:
        writer=csv.writer(data,delimiter="\t")
        writer.writerow(("ITEM","TEXT"))
        for idx,asin in enumerate(i):
            writer.writerow((idx,metadata.get(asin) or asin))
    print(category,len(u),len(i),len(table),"text",len(metadata),flush=True)
