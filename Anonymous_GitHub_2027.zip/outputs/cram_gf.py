"""CPU-only synthetic Top-K certificate benchmark. Requires NumPy."""
from time import perf_counter
import platform
import numpy as np

L, K = 24, 10
WEIGHTS = np.array([0.65, 0.23, 0.12])


def operators(rng, n):
    # Sparse edge lists with weighted reductions, including two B/B.T products.
    groups = n // 50
    users = np.repeat(np.arange(n), 16)
    items = (users % groups) * 50 + rng.integers(50, size=users.size)
    distract = rng.random(users.size) < 0.15
    items[distract] = rng.integers(n, size=distract.sum())
    values = 1 / np.sqrt(16 * np.bincount(items, minlength=n)[items])

    def collaborative(x):
        inner = np.bincount(users, values * x[items], minlength=n)
        return np.bincount(items, values * inner[users], minlength=n)

    ops = [collaborative]
    for degree in (8, 16):
        left = np.repeat(np.arange(n), degree)
        right = left // 50 * 50 + rng.integers(50, size=left.size)
        src, dst = np.r_[left, right], np.r_[right, left]
        counts = np.bincount(src, minlength=n)
        edge_weight = 1 / np.sqrt(counts[src] * counts[dst])

        def modality(x, src=src, dst=dst, weight=edge_weight):
            return np.bincount(src, weight * x[dst], minlength=n)

        ops.append(modality)
    return ops


def bounds(coeff):
    j = np.arange(L + 1)
    tails = np.zeros_like(coeff)
    radii = np.zeros_like(coeff)
    for m, theta_max in enumerate([np.pi / 2, np.pi, np.pi]):
        theta = np.linspace(0, theta_max, 4097)
        cosines = np.cos(theta[:, None] * j)
        for k in range(L):
            tail = coeff[m, k + 1:]
            values = np.sum(cosines[:, k + 1:] * tail, axis=1)
            lipschitz = j[k + 1:] @ np.abs(tail)
            tails[m, k] = np.abs(tail).sum()
            radii[m, k] = min(tails[m, k], np.ptp(values) / 2
                              + lipschitz * theta_max / (2 * (len(theta) - 1)))
    return tails, radii


def ranking(scores, candidates):
    # Use argpartition for the boundary, then deterministic item-ID tie breaking.
    values = scores[candidates]
    boundary = np.partition(values, [-K - 1, -K])
    cutoff = boundary[-K]
    above = np.flatnonzero(values > cutoff)
    tied = np.flatnonzero(values == cutoff)[:K - len(above)]
    selected = np.r_[above, tied]
    order = np.lexsort((candidates[selected], -values[selected]))
    return candidates[selected[order]], cutoff - boundary[-K - 1]


def predict(signal, candidates, ops, coeff, tail, schedule, pair_factor, reference=None):
    score = coeff[:, 0].sum() * signal
    current = [signal] * len(ops)
    previous = [None] * len(ops)
    depth = np.zeros(len(ops), dtype=int)
    norm = np.linalg.norm(signal)
    checks, check_time, certified = 0, 0.0, False
    result = None
    for m in schedule:
        step = depth[m] + 1
        nxt = ops[m](current[m])
        if step > 1:
            nxt = 2 * nxt - previous[m]
        previous[m], current[m] = current[m], nxt
        depth[m] = step
        score += coeff[m, step] * nxt
        # Check after each three products. Full and fixed baselines rank once.
        if tail is None or depth.sum() % 3 or depth.sum() == L * len(ops):
            continue
        start = perf_counter()
        checks += 1
        radius = norm * tail[np.arange(len(ops)), depth].sum()
        order, gap = ranking(score, candidates)
        check_time += perf_counter() - start
        if reference is not None:
            error = np.max(np.abs(score[candidates] - reference[candidates]))
            assert error <= radius + 1e-10, (error, radius)
        if gap > pair_factor * radius + 1e-10:
            result, certified = order, True
            break
    if result is None:
        result, _ = ranking(score, candidates)
    return score, result, depth.sum(), checks, check_time, certified


def benchmark(n, decay, seed):
    rng = np.random.default_rng(seed)
    ops = operators(rng, n)
    coeff = WEIGHTS[:, None] * np.asarray(decay)[:, None] ** np.arange(L + 1)
    coeff[:, 2::3] *= -1
    tails, radii = bounds(coeff)
    queries = []
    for _ in range(36):
        group = rng.integers(n // 50)
        seen = group * 50 + rng.choice(50, rng.integers(3, 13), replace=False)
        signal = np.zeros(n)
        signal[seen] = 1
        queries.append((signal, np.flatnonzero(signal == 0)))
    uniform = [0, 1, 2] * L
    # ponytail: static sparse work proxies, measure kernel costs for real data.
    cost = np.array([32, 16, 32])
    adaptive = []
    depth = np.zeros(3, dtype=int)
    for _ in uniform:
        gains = np.full(3, -np.inf)
        for m in np.flatnonzero(depth < L):
            k = depth[m]
            gains[m] = (radii[m, k] - radii[m, k + 1]) / cost[m]
        m = int(np.argmax(gains))
        adaptive.append(m)
        depth[m] += 1
    variants = [
        ("full", None, uniform, 2),
        ("fixed-8", None, uniform[:24], 2),
        ("uniform-l1", tails, uniform, 2),
        ("uniform-centered", radii, uniform, np.sqrt(2)),
        ("adaptive-centered", radii, adaptive, np.sqrt(2)),
    ]
    references = [predict(*q, ops, coeff, None, uniform, 2) for q in queries]
    for name, tail, schedule, factor in variants:
        times = []
        for _ in range(3):
            start = perf_counter()
            rows = [predict(*q, ops, coeff, tail, schedule, factor) for q in queries]
            times.append(perf_counter() - start)
        if tail is not None:
            for q, ref, row in zip(queries, references, rows):
                predict(*q, ops, coeff, tail, schedule, factor, reference=ref[0])
                assert set(row[1]) == set(ref[1]), (name, seed)
        same_set = np.mean([set(row[1]) == set(ref[1]) for row, ref in zip(rows, references)])
        same_order = np.mean([np.array_equal(row[1], ref[1]) for row, ref in zip(rows, references)])
        fields = np.mean([row[2:] for row in rows], axis=0)
        print(f"{n},{decay[0]},{seed},{name},{same_set:.6f},{same_order:.6f},"
              f"{fields[0]:.3f},{fields[1]:.3f},{1e6*fields[2]:.3f},"
              f"{fields[3]:.6f},{1e3*np.median(times)/len(queries):.6f}", flush=True)


if __name__ == "__main__":
    print(f"# {platform.platform()}, Python {platform.python_version()}, NumPy {np.__version__}")
    print("items,decay0,seed,method,set_match,order_match,matvecs,checks,check_us,certified,ms_per_query")
    for n in (500, 3000):
        for decay in ((0.40, 0.32, 0.49), (0.85, 0.77, 0.90)):
            for seed in (11, 23, 37):
                benchmark(n, decay, seed)
