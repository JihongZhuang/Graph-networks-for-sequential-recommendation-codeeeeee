"""CASG append-only top-k candidate certificate and normalized graph maintenance."""
import argparse
from bisect import bisect_left, insort
from collections import Counter, defaultdict
import heapq
import json
from math import comb
from pathlib import Path
import pickle

import numpy as np
from numpy.polynomial import Polynomial
import pandas as pd
from scipy.sparse import csr_matrix
import torch

from d_author_kernel_benchmark import quality
from exact_polynomial import full_layers, polynomial
from saeif_casg_pilot import NeighborIndex, append, full_graph, matrix, timed
from saeif_casg_sasrec import SampledProjection, author_model, rank
from saceif_benchmark import peak_mib


def edge(a, b):
    return (a, b) if a < b else (b, a)


class WinnerIndex:
    """Append-only counts; exact tie order identical to the reference."""

    def __init__(self, counts, n, initial=None, local_normalization=True):
        if initial is None:
            initial = NeighborIndex(counts)
        self.winners = initial.chosen
        self.weights = initial.weights
        self.local_normalization = local_normalization
        self.links = defaultdict(set)
        self.degree = np.zeros(n, dtype=np.int64)
        if self.local_normalization:
            for (i, j), weight in self.weights.items():
                self.links[i].add(j)
                self.links[j].add(i)
                self.degree[[i, j]] += weight
            self.operator = matrix(self.weights, n)

    def select(self, i, new_neighbors, counts):
        pool = self.winners[i] | new_neighbors
        return set(heapq.nsmallest(20, pool, key=lambda j:(-counts[edge(i, j)], str(j)))), len(pool)

    def update(self, counts, changed):
        candidates = defaultdict(set)
        for i, j in changed:
            candidates[i].add(j)
            candidates[j].add(i)
        affected = set(changed)
        examined = 0
        for i, new_neighbors in candidates.items():
            old = self.winners[i]
            new, compared = self.select(i, new_neighbors, counts)
            examined += compared
            self.winners[i] = new
            affected.update(edge(i, j) for j in old ^ new)

        degree_change = Counter()
        dirty = set()
        for i, j in affected:
            old = self.weights.get((i, j), 0)
            new = counts[i, j] if j in self.winners[i] or i in self.winners[j] else 0
            if new == old:
                continue
            if not self.local_normalization:
                if new:
                    self.weights[i, j] = new
                else:
                    del self.weights[i, j]
                continue
            dirty.add((i, j))
            degree_change[i] += new-old
            degree_change[j] += new-old
            if new:
                self.weights[i, j] = new
                self.links[i].add(j)
                self.links[j].add(i)
            else:
                del self.weights[i, j]
                self.links[i].remove(j)
                self.links[j].remove(i)

        if not self.local_normalization:
            return matrix(self.weights, len(self.degree)), examined, 0
        for i, change in degree_change.items():
            if change:
                self.degree[i] += change
                dirty.update(edge(i, j) for j in self.links[i])
        if dirty:
            pairs = list(dirty)
            row, col = np.asarray(pairs).T
            new = np.asarray([self.weights.get(pair, 0) for pair in pairs], dtype=float)
            present = new > 0
            new[present] /= np.sqrt(self.degree[row[present]]*self.degree[col[present]])
            old = np.asarray(self.operator[row, col]).ravel()
            delta = new-old
            patch = csr_matrix((np.tile(delta, 2), (np.r_[row, col], np.r_[col, row])),
                               shape=self.operator.shape)
            self.operator = self.operator + patch
        return self.operator, examined, len(dirty)


class FullRowIndex(WinnerIndex):
    def __init__(self, counts, n):
        initial = NeighborIndex(counts)
        super().__init__(counts, n, initial)
        self.neighbors = {i:set(row) for i, row in initial.adj.items()}

    def select(self, i, new_neighbors, counts):
        row = self.neighbors.setdefault(i, set())
        row.update(new_neighbors)
        ordered = sorted(row, key=lambda j:(-counts[edge(i,j)], str(j)))
        return set(ordered[:20]), len(row)


class OrderedIndex(WinnerIndex):
    """Maintain all neighbour ranks and apply the same normalization rule."""
    def __init__(self, counts, n):
        initial = NeighborIndex(counts)
        super().__init__(counts, n, initial)
        self.old_counts = counts.copy()
        self.ties = [0]*n
        for index, item in enumerate(sorted(range(n), key=str)):
            self.ties[item] = index
        self.rows = {i:sorted((-w, self.ties[j], j) for j,w in row.items())
                     for i,row in initial.adj.items()}

    def select(self, i, new_neighbors, counts):
        row = self.rows.setdefault(i, [])
        for j in new_neighbors:
            pair = edge(i,j)
            tie = self.ties[j]
            old = self.old_counts.get(pair,0)
            if old:
                key = (-old,tie,j)
                pos = bisect_left(row,key)
                assert row[pos] == key
                row.pop(pos)
            insort(row,(-counts[pair],tie,j))
        return {j for _,_,j in row[:20]}, len(new_neighbors)

    def update(self, counts, changed):
        result = super().update(counts, changed)
        for pair in changed:
            self.old_counts[pair] = counts[pair]
        return result


class MaterializedTopK(WinnerIndex):
    """Bounded materialized view with per-key updates for nondecreasing counts."""

    def __init__(self, counts, n):
        super().__init__(counts, n)
        self.rows = {i:sorted((-counts[edge(i,j)], str(j), j) for j in winners)
                     for i,winners in self.winners.items()}

    def select(self, i, new_neighbors, counts):
        row = self.rows.setdefault(i, [])
        keys = {key[2]:key for key in row}
        for j in new_neighbors:
            previous = keys.pop(j, None)
            if previous is not None:
                row.pop(bisect_left(row,previous))
            key = (-counts[edge(i,j)], str(j), j)
            if len(row)<20 or key<row[-1]:
                insort(row,key)
                keys[j] = key
                if len(row)>20:
                    del keys[row.pop()[2]]
        return set(keys), len(new_neighbors)


def load_replay(folder, log):
    rows = [json.loads(line) for line in log.read_text(encoding="utf-8-sig").splitlines()
            if line.startswith("{")]
    sizes = [row["batch"] for row in rows[1:]]
    raw = pd.read_csv(folder/"events.tsv", sep="\t")
    index = raw.groupby("user", sort=False).cumcount()
    count = raw.groupby("user", sort=False).user.transform("size")
    train = raw[index<count-2].sort_values("time", kind="stable").to_numpy()
    test = raw[index==count-1].set_index("user").item
    return train, test, sizes, rows[0]["bernstein"], len(raw), int(raw.item.max())+1


def memory_run(folder, log, route):
    train, _, sizes, _, _, n = load_replay(folder, log)
    begin = len(train)-sum(sizes)
    counts, histories = Counter(), defaultdict(list)
    append(train[:begin], counts, histories)
    before = peak_mib()
    constructor = {"CINM":WinnerIndex, "ordered":OrderedIndex, "view":MaterializedTopK}[route]
    index, setup_ms = timed(lambda:constructor(counts,n))
    after_setup = peak_mib()
    graph_ms = 0.
    for size in sizes:
        end = begin+size
        changed, append_ms = timed(lambda:append(train[begin:end],counts,histories))
        _, update_ms = timed(lambda:index.update(counts,changed))
        graph_ms += append_ms+update_ms
        begin = end
    print(json.dumps(dict(dataset=folder.name,route=route,windows=len(sizes),setup_ms=setup_ms,
                          graph_ms=graph_ms,shared_prefix_peak_mib=before,
                          after_setup_peak_mib=after_setup,process_peak_mib=peak_mib())),flush=True)


def run(folder, log, users=2500, repeat=1, review=False, ordered_control=False,
        view_control=False, only_window=None):
    torch.set_num_threads(4)
    train, test, sizes, weights, total_events, n = load_replay(folder, log)
    if only_window is not None and not 1<=only_window<=len(sizes):
        raise ValueError(f"only-window must be between 1 and {len(sizes)}")
    depth = len(weights)-1
    p, q = Polynomial([.5, .5]), Polynomial([.5, -.5])
    coeff = sum(weight*comb(depth,k)*p**k*q**(depth-k) for k, weight in enumerate(weights)).coef
    with (folder/"bert_cls.pkl").open("rb") as stream:
        inputs = np.asarray(pickle.load(stream), dtype=np.float64)
    inputs -= inputs.mean(axis=0)
    assert n == len(inputs)
    begin = len(train)-sum(sizes)
    c, h = Counter(), defaultdict(list)
    append(train[:begin], c, h)
    (certified, cert_init_ms) = timed(lambda:WinnerIndex(c, n))
    (prior, prior_init_ms) = timed(lambda:NeighborIndex(c))
    if review:
        winner_full, winner_full_init = timed(lambda:WinnerIndex(c,n,local_normalization=False))
        row_local, row_local_init = timed(lambda:FullRowIndex(c,n))
    if review or ordered_control:
        ordered, ordered_init = timed(lambda:OrderedIndex(c,n))
    control_init = {}
    if review:
        control_init.update(winner_full=winner_full_init,row_local=row_local_init)
    if review or ordered_control:
        control_init["ordered"] = ordered_init
    if view_control:
        view, control_init["view"] = timed(lambda:MaterializedTopK(c,n))
    eligible = [u for u, history in h.items() if history and test.loc[u] not in history]
    query = np.asarray(sorted(eligible)) if users==0 else np.random.default_rng(30).choice(
        eligible, users, replace=False)
    users = len(query)
    targets = [{test.loc[u]} for u in query]
    model = author_model(torch.from_numpy(inputs).float())
    model.in_proj = SampledProjection(model.in_proj, n)
    model.load_state_dict(torch.load(folder/"sasrec_validation_selected.pt", weights_only=True))
    print(json.dumps(dict(dataset=folder.name, repeat=repeat, users=users, depth=depth, coef=coeff.tolist(),
                          eligible=len(eligible), dataset_users=len(test), items=n, events=total_events,
                          train_events=len(train), initial_events=begin,
                          cert_init_ms=cert_init_ms, prior_init_ms=prior_init_ms,
                          count_keys=len(c), retained_edges=len(certified.weights),
                          winner_keys=sum(len(row) for row in certified.winners.values()),
                          control_init_ms=control_init)), flush=True)
    rng = np.random.default_rng(210+repeat)
    for window, size in enumerate(sizes):
        end = begin+size
        changed, append_ms = timed(lambda:append(train[begin:end], c, h))
        def rebuild_index():
            prior.update(c, changed)
            return matrix(prior.weights, n)

        methods = {"full":lambda:full_graph(train[:end], n),
                   "indexed":rebuild_index,
                   "CINM":lambda:certified.update(c, changed)}
        if review:
            methods.update(winner_full=lambda:winner_full.update(c, changed),
                           row_local=lambda:row_local.update(c,changed))
        if review or ordered_control:
            methods["ordered"] = lambda:ordered.update(c,changed)
        if view_control:
            methods["view"] = lambda:view.update(c,changed)
        order = rng.permutation(list(methods))
        if only_window is not None and window+1 < only_window:
            for method in order:
                if method != "full":
                    methods[method]()
            begin = end
            continue
        output = {}
        candidate_count = changed_weights = None
        for method in order:
            result, graph_ms = timed(methods[method])
            if method == "CINM":
                result, candidate_count, changed_weights = result
            elif method not in ("full","indexed"):
                result, _, _ = result
            features, filter_ms = timed(lambda:polynomial(full_layers(result, inputs, depth), coeff))
            inactive = np.diff(result.indptr)==0
            def downstream():
                features[inactive] = inputs[inactive]
                z = torch.nn.functional.normalize(torch.from_numpy(features).float())
                return z, rank(model, z, h, query, test)
            (z, top), rank_ms = timed(downstream)
            if method != "full":
                graph_ms += append_ms
            output[method] = (result, z, top, dict(graph_ms=graph_ms, filter_ms=filter_ms,
                                                    sasrec_and_normalize_ms=rank_ms,
                                                    total_ms=graph_ms+filter_ms+rank_ms))
        assert certified.weights == prior.weights and certified.winners == prior.chosen
        if review:
            for state in (winner_full,row_local):
                assert state.weights == prior.weights and state.winners == prior.chosen
        if review or ordered_control:
            assert ordered.weights == prior.weights and ordered.winners == prior.chosen
        if view_control:
            assert view.weights == prior.weights and view.winners == prior.chosen
        base_graph, base_z, base_top, _ = output["full"]
        for op, z, top, metrics in output.values():
            error = float(np.max(np.abs((op-base_graph).data), initial=0))
            assert error < 1e-14
            metrics.update(op_error=error, feature_error=float((z-base_z).abs().max()),
                           top20=int(np.all(top==base_top, axis=1).sum()),
                           quality=[*quality(top[:, :10], targets), *quality(top, targets)])
        print(json.dumps(dict(batch=size, window=window+1, repeat=repeat, users=users, changed_pairs=len(changed),
                              candidate_count=candidate_count, normalized_patch_pairs=changed_weights,
                              process_peak_mib=peak_mib(),
                              previous_index_candidates=sum(len(prior.adj[i])
                                                            for i in {i for pair in changed for i in pair}),
                              routes={name:result[-1] for name, result in output.items()})), flush=True)
        begin = end
        if only_window is not None:
            break


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    parser.add_argument("log", type=Path)
    parser.add_argument("--users", type=int, default=2500, help="0 uses all eligible users")
    parser.add_argument("--repeat", type=int, default=1)
    parser.add_argument("--review", action="store_true")
    parser.add_argument("--ordered-control", action="store_true")
    parser.add_argument("--view-control", action="store_true")
    parser.add_argument("--memory-route", choices=("CINM","ordered","view"))
    parser.add_argument("--only-window", type=int, help="advance earlier graph states without scoring")
    args = parser.parse_args()
    if args.memory_route:
        memory_run(args.folder,args.log,args.memory_route)
    else:
        run(args.folder,args.log,args.users,args.repeat,args.review,args.ordered_control,
            args.view_control,args.only_window)
