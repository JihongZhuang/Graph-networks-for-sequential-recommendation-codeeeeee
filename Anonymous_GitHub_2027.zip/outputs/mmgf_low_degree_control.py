"""MM-GF degree and coefficient control on synthetic graphs. Requires NumPy."""
from time import perf_counter
import numpy as np
from numpy.polynomial.chebyshev import poly2cheb
from cram_gf import bounds, operators, ranking, L

CONFIGS = {
    "Baby": (-.1, 1.1, -.7, .1, 0),
    "Sports": (1.5, 1.8, .7, 1.9, .5),
    "Clothing": (-.1, .7, 1.9, .5, .2),
}


def score(query, ops, coeff, schedule, radius):
    r, candidates = query
    partial = coeff[:, 0].sum() * r
    current, previous = [r] * 3, [None] * 3
    depth = [0] * 3
    for count, m in enumerate(schedule, 1):
        new = ops[m](current[m])
        if depth[m]:
            new = 2 * new - previous[m]
        previous[m], current[m] = current[m], new
        depth[m] += 1
        partial += coeff[m, depth[m]] * new
        if radius is not None and len(schedule) - 2 <= count < len(schedule):
            order, gap = ranking(partial, candidates)
            if gap > np.sqrt(2) * np.linalg.norm(r) * radius[range(3), depth].sum() + 1e-10:
                return partial, order, count
    return partial, ranking(partial, candidates)[0], len(schedule)


def trial(n, seed, config):
    rng = np.random.default_rng(seed)
    ops = operators(rng, n)
    a, b, c, beta, gamma = config
    coeff = np.zeros((3, L + 1))
    coeff[0, :4] = poly2cheb([0, a, b, c])
    coeff[1, :2] = beta
    coeff[2, :2] = gamma
    _, radius = bounds(coeff)
    schedule = [0] + [m for m in (1, 2) if coeff[m, 1]] + [0, 0]
    queries = []
    for _ in range(36):
        group = rng.integers(n // 50)
        seen = group * 50 + rng.choice(50, rng.integers(3, 13), replace=False)
        r = np.zeros(n)
        r[seen] = 1
        queries.append((r, np.flatnonzero(r == 0)))
    outputs = []
    for mode in (None, radius):
        elapsed = []
        for _ in range(5):
            start = perf_counter()
            rows = [score(q, ops, coeff, schedule, mode) for q in queries]
            elapsed.append(perf_counter() - start)
        outputs.append((rows, np.median(elapsed) * 1e3 / len(queries)))
    (full, full_ms), (early, early_ms) = outputs
    for (r, _), reference, result in zip(queries, full, early):
        v = ops[0](r)
        w = ops[0](v)
        expected = a*v + b*w + c*ops[0](w) + beta*(r+ops[1](r)) + gamma*(r+ops[2](r))
        np.testing.assert_allclose(reference[0], expected, atol=1e-12)
        assert set(reference[1]) == set(result[1])
    counts = np.array([row[2] for row in early])
    return len(schedule), counts.mean(), (counts < len(schedule)).sum(), full_ms, early_ms


if __name__ == "__main__":
    print("items,seed,coefficient_profile,full_products,mean_certified_products,early_queries,total_queries,full_ms,certified_ms")
    for n in (500, 3000):
        for name, config in CONFIGS.items():
            for seed in (11, 23, 37):
                full, used, early, full_ms, early_ms = trial(n, seed, config)
                print(f"{n},{seed},{name},{full},{used:.6f},{early},36,{full_ms:.6f},{early_ms:.6f}", flush=True)
