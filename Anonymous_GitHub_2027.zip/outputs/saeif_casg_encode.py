"""Compute BERT CLS with the CASG tokenizer and 64-token truncation."""
import pickle
from pathlib import Path
import sys
from time import perf_counter

import numpy as np
import pandas as pd
import torch

sys.path.insert(0,str(Path("work/saeif/casg_lib").resolve()))
from transformers import AutoModel, AutoTokenizer

root=Path("work/saeif/casg")
torch.set_num_threads(8)
torch.set_num_interop_threads(1)
tokenizer=AutoTokenizer.from_pretrained(root/"bert",local_files_only=True)
model=AutoModel.from_pretrained(root/"bert",local_files_only=True,attn_implementation="sdpa").eval()

@torch.inference_mode()
def encode(folder):
    raw=pd.read_csv(folder/"item_text.tsv",sep="\t").fillna("")
    assert np.array_equal(np.sort(raw.ITEM),np.arange(len(raw)))
    values=tokenizer(raw.TEXT.astype(str).tolist(),max_length=64,truncation=True)
    order=sorted(range(len(raw)),key=lambda j:len(values["input_ids"][j]))
    result=np.empty((len(raw),model.config.hidden_size),dtype=np.float32)
    start=perf_counter()
    for offset in range(0,len(order),48):
        js=order[offset:offset+48]
        batch=tokenizer.pad([{k:v[j] for k,v in values.items()} for j in js],
                            padding=True,return_tensors="pt")
        features=model(**batch).last_hidden_state[:,0]
        result[raw.ITEM.to_numpy()[js]]=features.numpy()
        if offset==0 or offset%960==0:
            print(folder.name,offset+len(js),len(order),round(perf_counter()-start,1),flush=True)
    assert np.isfinite(result).all()
    path=folder/"bert_cls.pkl"
    tmp=path.with_suffix(".part")
    with tmp.open("wb") as f:
        pickle.dump(result,f)
    tmp.replace(path)
    print(folder.name,"saved",result.shape,round(perf_counter()-start,1),flush=True)

for name in sys.argv[1:]:
    encode(root/name)
