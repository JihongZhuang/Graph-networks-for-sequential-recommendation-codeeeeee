"""Frozen-weight DIGEST propagation/refinement control from paper equations 6–8."""
import json
from pathlib import Path
from time import perf_counter

import numpy as np
from scipy.sparse import csr_matrix
from scipy.special import expit
import torch

from d_author_kernel_benchmark import quality

def timed(fn):
    t = perf_counter()
    value = fn()
    return value, (perf_counter()-t)*1000

def csr(u,i,v,n):
    return csr_matrix((np.r_[v,v],(np.r_[u,i],np.r_[i,u])),shape=(n,n))

def gates(x,u,i):
    return expit(np.einsum("ij,ij->i",x[u],np.tanh(x[i])))

def normalized(u,i,w,n):
    degree = np.bincount(u,w,minlength=n)+np.bincount(i,w,minlength=n)
    return csr(u,i,w/np.sqrt(degree[u]*degree[i]),n)

def cosine_neighbors(folder,kind,n):
    f=folder/f"{kind}_cosine20.npy"
    if f.exists():
        return np.load(f)[:,:6]
    x=torch.nn.functional.normalize(torch.from_numpy(np.load(folder/f"{kind}_feat.npy")).float())
    return np.vstack([(part@x.T).topk(6,dim=1).indices.numpy() for part in x.split(256)])

def run(folder,checkpoint,transfer=False,users=2500):
    torch.set_num_threads(4)
    rows=np.loadtxt(folder/f"{folder.name}.inter",delimiter="\t",skiprows=1,usecols=(0,1,3),dtype=np.int64)
    rows=rows[np.argsort(rows[:,2],kind="stable")]
    u,i=rows[:,:2].T.copy()
    m,n=u.max()+1,i.max()+1
    i+=m
    count=m+n
    state=torch.load(checkpoint,map_location="cpu",weights_only=False)
    trained="fusion_weight" in state
    if trained:
        x=state["ids"].detach().numpy().astype(np.float64)
        item=x[m:]
    else:
        state=state["weights"]
        # External embeddings only exercise the DIGEST equations.
        user=state["id_spectralfilter.preference"].detach().numpy().astype(np.float64)
        item=state["item_id_embedding.weight"].detach().numpy().astype(np.float64)
        x=np.vstack((user,item))
    assert x.shape[0]==count
    start=int(.75*len(rows))+7310
    sizes=(10,100,1000)*(3 if transfer else 1)
    stop=start+sum(sizes)
    targets=[set() for _ in range(m)]
    seen=[set() for _ in range(m)]
    active=np.bincount(i[:start]-m,minlength=n)>0
    for a,b,_ in rows[stop:]:
        if active[b]:
            targets[a].add(b)
    for a,b in zip(u[:start],i[:start]):
        seen[a].add(b-m)
    eligible=[a for a in np.unique(u[:start]) if targets[a]]
    query=np.random.default_rng(30).choice(eligible,users,replace=False)
    target_rows=[targets[a] for a in query]

    def semantic():
        adjacency=csr_matrix((n,n),dtype=np.float64)
        for weight,kind in ((.9,"text"),(.1,"image")):
            neighbors=cosine_neighbors(folder,kind,n)
            a=csr_matrix((np.full(n*6,weight),(np.repeat(np.arange(n),6),neighbors.ravel())),shape=(n,n))
            adjacency+=a
        row,col=adjacency.nonzero()
        y=item
        values=[y]
        for _ in range(2):
            w=gates(y,row,col)*np.asarray(adjacency[row,col]).ravel()
            d=np.maximum(np.bincount(row,w,minlength=n),1e-12)
            op=csr_matrix((w/np.sqrt(d[row]*d[col]),(row,col)),shape=(n,n))
            y=op@y
            values.append(y)
        return sum(values)/len(values)

    sem,sem_ms=timed(semantic)
    def full(end):
        a,b=u[:end],i[:end]
        w0=gates(x,a,b)
        s0=normalized(a,b,w0,count)
        h1=s0@x
        w1=gates(h1,a,b)
        s1=normalized(a,b,w1,count)
        return w0,s0,h1,w1,s1,s1@h1

    def rank(h1,h2,sem):
        combined=(x+h1+h2)/3
        collaborative=combined[m:]
        if trained:
            gate=expit(np.hstack((collaborative,sem))@state["fusion_weight"].numpy().T+
                       state["fusion_bias"].numpy())
        else:
            gate=expit(collaborative.mean(axis=1))[:,None]
        products=(gate*collaborative+(1-gate)*sem).astype(np.float32)
        output=[]
        for sub in np.array_split(query,20):
            scores=torch.from_numpy(combined[sub].astype(np.float32))@torch.from_numpy(products).T
            if transfer:
                scores[:,~catalog]=-torch.inf
            for j,a in enumerate(sub):
                scores[j,list(seen[a])]=-torch.inf
            output.append(torch.topk(scores,20,dim=1).indices.numpy())
        return np.vstack(output)

    old=full(start)
    print(json.dumps(dict(dataset=folder.name,users=users,semantic_init_ms=sem_ms,transfer=transfer,
                          trained_checkpoint=trained,
                          validation_recall20=state.get("recall20") if trained else None)),flush=True)
    begin=start
    calibration=[]
    for index,size in enumerate(sizes):
        end=begin+size
        a,b=u[:end],i[:end]
        def prepare():
            for user_id,item_id in zip(u[begin:end],i[begin:end]):
                seen[user_id].add(item_id-m)
            return np.bincount(b-m,minlength=n)>0
        catalog,setup_ms=timed(prepare)

        def estimate():
            touched=np.zeros(count,dtype=bool)
            touched[a[begin:]]=True
            touched[b[begin:]]=True
            layer_one=touched[a]|touched[b]
            touched[a[layer_one]]=True
            touched[b[layer_one]]=True
            layer_two=touched[a]|touched[b]
            f=np.log1p([size,int(layer_one.sum()),int(layer_two.sum())])
            if len(calibration)<3:
                return f,"sparse",int(layer_two.sum())
            previous=min(calibration,key=lambda r:np.linalg.norm(f-r[0]))
            return f,("sparse" if previous[1]<.90*previous[2] else "full"),int(layer_two.sum())

        if transfer:
            (feature,choice,upper),selection_ms=timed(estimate)
        else:
            choice,upper,selection_ms="sparse",None,0.

        def selective():
            w0,s0,h1,w1,s1,h2=old
            raw0=np.r_[w0,gates(x,a[begin:],b[begin:])]
            op0=normalized(a,b,raw0,count)
            d1=(op0-s0)@x
            new_h1=h1+d1
            changed=np.any(d1!=0,axis=1)
            touched=np.flatnonzero(changed[a]|changed[b]|(np.arange(end)>=begin))
            raw1=np.r_[w1,np.zeros(size)]
            raw1[touched]=gates(new_h1,a[touched],b[touched])
            op1=normalized(a,b,raw1,count)
            return (raw0,op0,new_h1,raw1,op1,h2+(op1-s1)@h1+op1@d1),len(touched)

        def selected():
            if choice=="full":
                return full(end),end
            return selective()
        if index%2==0:
            new,base_ms=timed(lambda:full(end))
            ref,rank_full_ms=timed(lambda:rank(new[2],new[5],sem))
            (prediction,touched),select_ms=timed(selected)
            inc,rank_inc_ms=timed(lambda:rank(prediction[2],prediction[5],sem))
        else:
            (prediction,touched),select_ms=timed(selected)
            inc,rank_inc_ms=timed(lambda:rank(prediction[2],prediction[5],sem))
            new,base_ms=timed(lambda:full(end))
            ref,rank_full_ms=timed(lambda:rank(new[2],new[5],sem))
        err=max(np.max(np.abs(prediction[k]-new[k])) for k in (0,2,3,5))
        assert err<1e-10
        if transfer and index<3:
            calibration.append((feature,select_ms,base_ms))
        print(json.dumps(dict(batch=size,edges=end,users=users,full_ms=base_ms,selective_ms=select_ms,
                              calibration=transfer and index<3,path=choice,upper_gate_edges=upper,
                              setup_ms=setup_ms,selection_ms=selection_ms,
                              total_full_ms=setup_ms+base_ms+rank_full_ms,
                              total_b3_ms=setup_ms+select_ms+selection_ms+rank_inc_ms,
                              refined_edges=touched,rank_full_ms=rank_full_ms,rank_inc_ms=rank_inc_ms,
                              max_error=float(err),top20_equal=int(np.all(ref==inc,axis=1).sum()),
                              quality=[*quality(ref[:,:10],target_rows),*quality(ref,target_rows)],
                              b3_quality=[*quality(inc[:,:10],target_rows),*quality(inc,target_rows)])),flush=True)
        old,begin=(prediction if transfer else new),end

if __name__=="__main__":
    import argparse
    parser=argparse.ArgumentParser()
    parser.add_argument("folder",type=Path)
    parser.add_argument("checkpoint",type=Path)
    parser.add_argument("--transfer",action="store_true")
    parser.add_argument("--users",type=int,default=2500)
    args=parser.parse_args()
    run(args.folder,args.checkpoint,args.transfer,args.users)
