"""TimeMM paired cost-selection experiment on chronological development and test windows."""
import ctypes
import json
from time import perf_counter

import numpy as np
import torch

from d_author_kernel_benchmark import quality
from timemm_inplace import normalize_inplace, propagate_inplace
from timemm_structure_study import clock, factorize, factor_propagate, materialize


def peak_mib():
    class Counters(ctypes.Structure):
        _fields_=[("cb",ctypes.c_ulong),("faults",ctypes.c_ulong)]+[
            (name,ctypes.c_size_t) for name in ("peak","current","quota_peak","quota_current",
                                               "pool_peak","pool","pagefile","pagefile_peak")]
    if not hasattr(ctypes,"windll"):
        return None
    values=Counters()
    values.cb=ctypes.sizeof(values)
    k=ctypes.windll.kernel32
    k.GetCurrentProcess.restype=ctypes.c_void_p
    ok=ctypes.windll.psapi.GetProcessMemoryInfo(
        ctypes.c_void_p(k.GetCurrentProcess()),ctypes.byref(values),values.cb)
    return values.peak/2**20 if ok else None


def preflight(g,begin,end):
    users=np.unique(g.u[begin:end])
    raw=g.gather(users,g.by_u)
    items=np.unique(np.r_[g.i[raw],g.i[begin:end]])
    item_edges=sum(len(g.by_i[i]) for i in items)+end-begin
    raw_bound=len(raw)+end-begin
    candidate_bound=raw_bound+item_edges
    feature=np.log1p([end-begin,len(users),raw_bound,len(items),item_edges])
    return users,feature,raw_bound,candidate_bound


def frontier_bound(g,ids):
    users=np.unique(g.u[ids])
    items=np.unique(g.i[ids])
    return sum(len(g.by_u[u]) for u in users)+sum(len(g.by_i[i]) for i in items)


def build_cache(graphs,full,start,stop):
    cache=[]
    for graph in graphs:
        state=graph.snapshot(start)
        padded=list(state)
        for j in (1,4):
            padded[j]=np.pad(padded[j],(0,stop-start))
        cache.append((padded,full(graph,state)))
    return cache


def update(graphs,cache,x,full,begin,end,choice,users=None,budget=None,threshold=None):
    counters=[]
    output=[]
    for k,(g,(state,h)) in enumerate(zip(graphs,cache)):
        route=choice
        t0=perf_counter()
        norm_ms=front_ms=prop_ms=factor_ms=materialize_ms=0.
        candidate=changed=front_count=None
        if choice=="full":
            rebuilt,norm_ms=clock(lambda:g.snapshot(end))
            for target,value in zip(state,rebuilt):
                target[:len(value)]=value
            h,prop_ms=clock(lambda:full(g,rebuilt))
        else:
            (ids,dw,_,candidate),norm_ms=clock(lambda:normalize_inplace(g,state,begin,end))
            changed=len(ids)
            t1=perf_counter()
            reject=budget is not None and 2*changed+frontier_bound(g,ids)>budget
            if not reject:
                front=g.frontier(ids)
                front_count=len(front)
                reject=threshold is not None and 2*changed+front_count>threshold
            front_ms=1000*(perf_counter()-t1)
            if reject:
                route="late_full"
                h,prop_ms=clock(lambda:full(g,(state[-1][:end],)))
            elif choice=="factor":
                factors,factor_ms=clock(lambda:factorize(g,ids,dw,users,state))
                delta,prop_ms=clock(lambda:factor_propagate(g,factors,state,x,h,front))
                _,materialize_ms=clock(lambda:materialize(h,delta))
            else:
                _,prop_ms=clock(lambda:propagate_inplace(g,h,x,state[-1],ids,dw,front))
        cache[k]=(state,h)
        output.append(h)
        counters.append(dict(path=route,norm_ms=norm_ms,front_ms=front_ms,prop_ms=prop_ms,
                             factor_ms=factor_ms,materialize_ms=materialize_ms,
                             candidate=candidate,changed=changed,front=front_count,
                             scale_ms=1000*(perf_counter()-t0)))
    return output,counters


def calibrate(graphs,x,full,dev_start,start):
    dev_sizes=(10,50,100,250,1000,5800)
    events=np.column_stack((graphs[0].u,graphs[0].i,graphs[0].t))
    dev=[type(g)(events,g.m,g.n,dev_start) for g in graphs]
    for a,b in zip(dev,graphs):
        a.tau=b.tau
    cache=build_cache(dev,full,dev_start,start)
    begin=dev_start
    records=[]
    for size in dev_sizes:
        end=begin+size
        _,feature,raw,upper=preflight(dev[0],begin,end)
        for g in dev:
            g.append(begin,end)
        _,csr_ms=clock(lambda:[full(g,g.snapshot(end)) for g in dev])
        _,local_ms=clock(lambda:update(dev,cache,x,full,begin,end,"sparse"))
        records.append((feature,csr_ms,local_ms))
        print(json.dumps(dict(dev_batch=size,raw_bound=raw,norm_bound=upper,
                              full_ms=csr_ms,sparse_ms=local_ms)),flush=True)
        begin=end
    return records


def evaluate(graphs,x,full,context,replay,query,seen,targets,dev_start,start,sizes,trial):
    stop=start+sum(sizes)
    records=calibrate(graphs,x,full,dev_start,start)
    names=("B0","B1","B2","B3","B4","B5") if len(query)==5000 else ("B0","B1","B2","B3","B4")
    caches={}
    for name in names[1:]:
        cache,ms=clock(lambda:build_cache(graphs,full,start,stop))
        caches[name]=cache
        print(json.dumps(dict(init=name,ms=ms,cache_mib=sum(a.nbytes for s,h in cache
                                   for a in (*s,*h))/2**20)),flush=True)
    baseline_old=[g.snapshot(start) for g in graphs]
    rng=np.random.default_rng(1000+trial)

    def rank(emb,active,vector_mask=False):
        u,i=emb
        order=[]
        score_ms=sort_ms=0.
        unavailable=torch.from_numpy(~active) if vector_mask else None
        for begin in range(0,len(query),128):
            rows=query[begin:begin+128]
            scores,ms=clock(lambda:u[rows]@i.T)
            score_ms+=ms
            def masked_top():
                if vector_mask:
                    scores.masked_fill_(unavailable[None,:],-torch.inf)
                    observed=[seen[user] for user in rows]
                    row=np.repeat(np.arange(len(rows)),[len(items) for items in observed])
                    col=np.fromiter((i for items in observed for i in items),dtype=np.int64)
                    scores[row,col]=-torch.inf
                else:
                    scores[:,~active]=-torch.inf
                    for j,user in enumerate(rows):
                        scores[j,seen[user]]=-torch.inf
                return torch.topk(scores,20,dim=1).indices.numpy()
            top,ms=clock(masked_top)
            sort_ms+=ms
            order.append(top)
        return np.vstack(order),score_ms,sort_ms

    begin=start
    for window,size in enumerate(sizes):
        end=begin+size
        def seen_and_catalog():
            for a,b in zip(graphs[0].u[begin:end],graphs[0].i[begin:end]):
                seen[a].append(b)
            return np.bincount(graphs[0].i[:end],minlength=graphs[0].n)>0
        active,other_ms=clock(seen_and_catalog)
        _,context_ms=clock(lambda:context(end))
        def estimate():
            users,f,raw,bound=preflight(graphs[0],begin,end)
            neighbor=min(records,key=lambda r:np.linalg.norm(f-r[0]))
            return users,raw,bound,neighbor[1],neighbor[2]
        (users,raw_bound,bound,estimated_full,estimated_local),select_ms=clock(estimate)
        chosen="sparse" if estimated_local<.90*estimated_full else "full"
        def append():
            for g in graphs:
                g.append(begin,end)
        _,append_ms=clock(append)
        result={}
        layers_by_route={}
        reference=None

        for name in rng.permutation(names):
            select_cost=select_ms if name in ("B3","B4") else 0.
            if name=="B0":
                def ref():
                    s=[g.snapshot(end) for g in graphs]
                    return s,[full(g,v) for g,v in zip(graphs,s)]
                (reference,layers),graph_ms=clock(ref)
                counters=[]
            else:
                budget=threshold=None
                if name=="B1":
                    route="sparse" if 1000*size<=end else "full"
                    threshold=.30*end
                elif name=="B2":
                    route="sparse"
                elif name=="B3":
                    route=chosen
                elif name=="B4":
                    route="full" if bound>.23*end else chosen
                    budget=.65*end
                else:
                    route="factor"
                (layers,counters),graph_ms=clock(
                    lambda:update(graphs,caches[name],x,full,begin,end,route,users,budget,threshold))
                graph_ms+=append_ms+select_cost
            emb,forward_ms=clock(lambda:replay(layers))
            (top,score_ms,rank_ms),ranking_ms=clock(lambda:rank(emb,active))
            overhead=other_ms+ranking_ms-score_ms-rank_ms
            result[name]=(emb,top,dict(graph_ms=graph_ms,forward_ms=forward_ms,score_ms=score_ms,
                              rank_ms=rank_ms,context_ms=context_ms,other_ms=overhead,
                              total_ms=graph_ms+forward_ms+ranking_ms+context_ms+other_ms,
                              selection_ms=select_cost,scales=counters))
            layers_by_route[name]=layers

        full_emb,full_rank,base=result["B0"]
        ref_quality=[*quality(full_rank[:,:10],targets),*quality(full_rank,targets)]
        sample=full_emb[0][query[:64]]@full_emb[1].T
        for name,(emb,top,summary) in result.items():
            summary["top20"]=int(np.all(top==full_rank,axis=1).sum())
            summary["quality"]=ref_quality if summary["top20"]==len(query) else [
                *quality(top[:,:10],targets),*quality(top,targets)]
            summary["score_sample_max_error"]=float(((emb[0][query[:64]]@emb[1].T)-sample).abs().max())
            for a,b in zip(emb,full_emb):
                torch.testing.assert_close(a,b,rtol=1e-5,atol=2e-6)
            if name!="B0":
                weight_error=layer_error=0.
                for (state,layer),ref_state,ref_layer in zip(caches[name],reference,layers_by_route["B0"]):
                    np.testing.assert_allclose(state[-1][:end],ref_state[-1],atol=1e-12,rtol=2e-10)
                    weight_error=max(weight_error,float(np.max(np.abs(state[-1][:end]-ref_state[-1]))))
                    for a,b in zip(layer,ref_layer):
                        layer_error=max(layer_error,float(np.max(np.abs(a-b))))
                        np.testing.assert_allclose(a,b,atol=1e-9,rtol=1e-8)
                summary.update(weight_max_error=weight_error,layer_max_error=layer_error)
        structure=[]
        for g,old,new in zip(graphs,baseline_old,reference):
            raw_ids=np.flatnonzero(new[1]!=np.r_[old[1],np.zeros(size)])
            changed_items=np.flatnonzero(new[3]!=old[3])
            candidate=np.union1d(g.gather(users,g.by_u),g.gather(np.unique(g.i[raw_ids]),g.by_i))
            ids=np.flatnonzero(new[-1]!=np.r_[old[-1],np.zeros(size)])
            frontier=g.frontier(ids)
            nodes1=np.unique(np.r_[g.u[ids],g.i[ids]+g.m])
            nodes2=np.unique(np.r_[g.u[frontier],g.i[frontier]+g.m])
            structure.append(dict(raw=len(raw_ids),items=len(changed_items),norm=len(candidate),
                                  delta=len(ids),l1_rows=len(nodes1),l2_rows=len(nodes2),
                                  l2_edges=len(frontier),rank_bound=len(users)+len(changed_items)))
        layout={}
        if trial==2:
            for name in ("B0","B4"):
                emb,forward_ms=clock(lambda:replay(layers_by_route[name],compact_layout=True))
                (ranked,score_ms,rank_ms),ranking_ms=clock(lambda:rank(emb,active,True))
                for a,b in zip(emb,result[name][0]):
                    torch.testing.assert_close(a,b,rtol=0,atol=0)
                equal=int(np.all(ranked==full_rank,axis=1).sum())
                layout[name]=dict(forward_ms=forward_ms,score_ms=score_ms,rank_ms=rank_ms,
                                  top20=equal,total_ms=result[name][2]["graph_ms"]+
                                  forward_ms+ranking_ms+context_ms+other_ms)
        print(json.dumps(dict(window=window,batch=size,users=len(query),trial=trial,graph_edges=end,
                              event_users=len(users),catalog=int(active.sum()),norm_bound=bound,
                              raw_bound=raw_bound,predicted_full_ms=estimated_full,
                              predicted_local_ms=estimated_local,structure=structure,
                              layout=layout,
                              routes={name:result[name][2] for name in names})),flush=True)
        baseline_old,begin=reference,end
    print(json.dumps(dict(process_peak_mib=peak_mib())),flush=True)
