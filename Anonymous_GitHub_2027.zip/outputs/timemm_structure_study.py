"""Paired tests of structural updates and certified ranking on TimeMM."""
import json
from time import perf_counter

import numpy as np
from scipy.sparse import csr_matrix
import torch

from d_author_kernel_benchmark import quality
from timemm_inplace import normalize_inplace, propagate_inplace


def clock(fn):
    t = perf_counter()
    result = fn()
    return result, (perf_counter() - t) * 1000


def shared_normalize(graphs, states, begin, end):
    g = graphs[0]
    new = np.arange(begin, end)
    users = np.unique(g.u[new])
    edges = g.gather(users, g.by_u)
    u, i = g.u[edges], g.i[edges]
    anchor = states[0][0]
    np.maximum.at(anchor, g.u[new], g.t[new])
    log_age = np.log1p((anchor[u] - g.t[edges]).astype(np.float32))
    patches = []
    for graph, state in zip(graphs, states):
        a, raw, du, di, norm = state
        a[users] = anchor[users]
        values = np.clip(np.exp(-log_age / graph.tau), .001, 1).astype(np.float64)
        diff = values - raw[edges]
        np.add.at(du, u, diff)
        np.add.at(di, i, diff)
        raw[edges] = values
        items = np.unique(i[diff != 0])
        candidates = np.union1d(edges, g.gather(items, g.by_i))
        values = raw[candidates] / np.sqrt(du[g.u[candidates]] * di[g.i[candidates]])
        delta = values - norm[candidates]
        norm[candidates] = values
        mask = delta != 0
        patches.append((candidates[mask], delta[mask], len(edges), len(candidates)))
    return patches


def factorize(g, ids, delta, users, state, old=None):
    """Disjoint row/column factors of ΔS, in compact coordinates."""
    u, i = g.u[ids], g.i[ids]
    ru, ur = np.unique(u, return_inverse=True)
    ri, ir = np.unique(i, return_inverse=True)
    p_edges = np.isin(u, users)
    q_edges = ~p_edges
    p_rows, p_inverse = np.unique(ur[p_edges], return_inverse=True)
    q_cols, q_inverse = np.unique(ir[q_edges], return_inverse=True)
    p = csr_matrix((delta[p_edges], (p_inverse, ir[p_edges])),
                   shape=(len(p_rows), len(ri)))
    # On unaffected user rows the change is the old column times its degree ratio.
    cols = i[q_edges]
    q_delta = delta[q_edges] if old is None else (
        old[-1][ids[q_edges]] * (np.sqrt(old[3][cols] / state[3][cols]) - 1))
    q = csr_matrix((q_delta, (ur[q_edges], q_inverse)), shape=(len(ru), len(q_cols)))
    return ru, ri + g.m, p_rows, q_cols, p, q


def factor_propagate(g, factors, state, x, layers, frontier):
    ru, ri, pr, qc, p, q = factors
    rows = np.r_[ru, ri]

    def contract(z):
        left, right = z[ru], z[ri]
        out_left, out_right = q @ right[qc], p.T @ left[pr]
        out_left[pr] += p @ right
        out_right[qc] += q.T @ left
        return np.vstack((out_left, out_right))

    first, second = layers
    d1 = contract(x)
    d2_direct = contract(first)
    u, i = g.u[frontier], g.i[frontier] + g.m
    dst, src = np.r_[u, i], np.r_[i, u]
    col = np.searchsorted(rows, src)
    valid = rows[np.minimum(col, len(rows)-1)] == src
    changed, ir = np.unique(dst[valid], return_inverse=True)
    a_new = csr_matrix((np.tile(state[-1][frontier], 2)[valid], (ir, col[valid])),
                       shape=(len(changed), len(rows)))
    d2_spread = a_new @ d1
    return rows, changed, d1, d2_direct, d2_spread


def materialize(layers, result):
    first, second = layers
    rows, changed, d1, d2_direct, d2_spread = result
    first[rows] += d1
    second[rows] += d2_direct
    second[changed] += d2_spread


class CertifiedRank:
    """Frozen reference block maxima plus conservative dot-product perturbation bounds."""
    block = 256

    def __init__(self, embeddings, query, reference_top):
        self.user = embeddings[0][query].contiguous()
        self.item = embeddings[1].contiguous()
        self.seed = torch.as_tensor(reference_top, dtype=torch.long)
        self.blocks = list(self.item.split(self.block))
        self.item_norm = torch.stack([b.double().norm(dim=1).max() for b in self.blocks])
        self.maxima = torch.stack([(self.user @ b.T).amax(dim=1) for b in self.blocks], dim=1).double()

    def rank(self, embeddings, query, seen, active, full_rank):
        user, item = embeddings[0][query], embeddings[1]
        user64 = user.double()
        du = (user64 - self.user.double()).norm(dim=1)
        un = user64.norm(dim=1)
        dn = torch.stack([p.norm(dim=1).max() for p in (item.double()-self.item.double()).split(self.block)])
        new_norm = torch.stack([b.double().norm(dim=1).max() for b in item.split(self.block)])
        # Guard both old and new float32 dot-product roundoff and norm arithmetic.
        gamma = (user.shape[1] + 4) * torch.finfo(torch.float32).eps
        error = 4 * gamma * (un[:,None]*new_norm + self.user.double().norm(dim=1)[:,None]*self.item_norm + 1)
        bound = self.maxima + du[:,None]*self.item_norm + un[:,None]*dn + error
        blocked = [set(seen[u]) for u in query]
        seeded = (user[:,None]*item[self.seed]).sum(dim=2).double()
        for row, candidates in enumerate(self.seed.numpy()):
            invalid = [j for j,i in enumerate(candidates) if not active[i] or i in blocked[row]]
            seeded[row, invalid] = -torch.inf
        lower = seeded.amin(dim=1) - error.amax(dim=1)
        keep = bound >= lower[:,None]
        # Use the original dense path when the mask offers little savings.
        fraction = float(keep.float().mean())
        if fraction > .45:
            return full_rank(embeddings, active), fraction, True
        # The sparse scoring path groups surviving user/block pairs.
        scores = torch.full((len(query),len(item)), -torch.inf)
        for k,b in enumerate(item.split(self.block)):
            rows = torch.where(keep[:,k])[0]
            if len(rows):
                scores[rows,k*self.block:k*self.block+len(b)] = user[rows] @ b.T
        scores[:,~active] = -torch.inf
        for row,u in enumerate(query):
            scores[row,seen[u]] = -torch.inf
        return torch.topk(scores,20,dim=1).indices.numpy(), fraction, False


def feature(end, q, visited, frontier, rank):
    return np.array([1, end/1e5, q/1e3, visited/1e5, frontier/1e5, rank/1e4])

def evaluate(graphs, x, full, context, replay, rank, query, seen, targets, start, sizes):
    g = graphs[0]
    stop = start+sum(sizes)
    old = [graph.snapshot(start) for graph in graphs]
    layers = [full(graph,state) for graph,state in zip(graphs,old)]
    context(start)
    initial = replay(layers)
    active = np.bincount(g.i[:start],minlength=g.n)>0
    top = rank(initial,active)
    cert, setup_ms = clock(lambda:CertifiedRank(initial, query, top))
    print(json.dumps({"rank_cache_init_ms":setup_ms,
                      "rank_cache_mib":sum(t.numel()*t.element_size() for t in
                                           (cert.user,cert.item,cert.seed,cert.item_norm,cert.maxima))/2**20}),
          flush=True)
    training = []
    begin = start
    names = ("full","sparse","factor","shared")
    for idx, size in enumerate(sizes):
        end = begin+size
        def append():
            for graph in graphs:
                graph.append(begin,end)
        _, append_ms = clock(append)
        for u,i in zip(g.u[begin:end],g.i[begin:end]):
            seen[u].append(i)
        active = np.bincount(g.i[:end],minlength=g.n)>0
        _, context_ms = clock(lambda:context(end))
        users = np.unique(g.u[begin:end])

        def rebuild():
            state = [graph.snapshot(end) for graph in graphs]
            return state,[full(graph,s) for graph,s in zip(graphs,state)]

        (expected, new_layers), full_ms = clock(rebuild)
        emb, full_model = clock(lambda:replay(new_layers))
        baseline, full_rank_ms = clock(lambda:rank(emb,active))
        (certified, fraction, rank_fallback), cert_ms = clock(
            lambda:cert.rank(emb,query,seen,active,rank))
        routes = {"full":{"graph_ms":full_ms,"forward_ms":full_model,"rank_ms":full_rank_ms,
                          "top20":len(query)}}
        cert_count = int(np.all(certified==baseline,axis=1).sum())
        meta = None
        for name in (names[1:] if idx%2==0 else tuple(reversed(names[1:]))):
            state = [(s[0].copy(),np.pad(s[1],(0,size)),s[2].copy(),s[3].copy(),np.pad(s[4],(0,size)))
                     for s in old]
            cache = [(a.copy(),b.copy()) for a,b in layers]
            if name == "shared":
                patches,norm_ms = clock(lambda:shared_normalize(graphs,state,begin,end))
            else:
                patches,norm_ms = clock(lambda:[normalize_inplace(graph,s,begin,end)
                                               for graph,s in zip(graphs,state)])
            fronts,front_ms = clock(lambda:[graph.frontier(p[0]) for graph,p in zip(graphs,patches)])
            records = []
            construction = prop = output = 0.
            for graph,s,h,patch,front,prev in zip(graphs,state,cache,patches,fronts,old):
                ids,delta,raw_count,candidate_count = patch
                changed_items = int(np.count_nonzero(s[3]!=prev[3]))
                bytes_factor = None
                if name == "factor":
                    factors,ms = clock(lambda:factorize(graph,ids,delta,users,s,prev))
                    construction += ms
                    p,q = factors[-2:]
                    bytes_factor = sum(a.nbytes for m in (p,q) for a in (m.data,m.indices,m.indptr))
                    result,ms = clock(lambda:factor_propagate(graph,factors,s,x,h,front))
                    prop += ms
                    _,ms = clock(lambda:materialize(h,result))
                    output += ms
                    rows1 = len(result[0])
                    rows2 = len(np.union1d(result[0],result[1]))
                else:
                    (rows1,rows2),ms = clock(
                        lambda:propagate_inplace(graph,h,x,s[-1],ids,delta,front))
                    prop += ms
                records.append(dict(raw=raw_count,candidates=candidate_count,changed=len(ids),
                                    frontier=len(front),rows1=rows1,rows2=rows2,
                                    changed_items=changed_items,rank_bound=len(users)+changed_items,
                                    factor_csr_bytes=bytes_factor,explicit_csr_est_bytes=24*len(ids)+4*(rows1+1)))
            pred, model_ms = clock(lambda:replay(cache))
            order, rank_ms = clock(lambda:rank(pred,active))
            count = int(np.all(order==baseline,axis=1).sum())
            for s,ref in zip(state,expected):
                np.testing.assert_allclose(s[-1],ref[-1],atol=1e-12,rtol=2e-10)
            error = max(float((a-b).abs().max()) for a,b in zip(pred,emb))
            for a,b in zip(pred,emb):
                torch.testing.assert_close(a,b,atol=2e-6,rtol=1e-5)
            routes[name] = dict(graph_ms=append_ms+norm_ms+front_ms+construction+prop+output,
                                forward_ms=model_ms,rank_ms=rank_ms,top20=count,
                                norm_ms=norm_ms,front_ms=front_ms,construct_ms=construction,
                                propagation_ms=prop,materialize_ms=output,err=error)
            if name=="factor":
                meta=records
            del cache,state,pred
        f=feature(end,size,meta[0]["candidates"],meta[0]["frontier"],meta[0]["rank_bound"])
        # First chronological cycle is calibration. Query the two nearest earlier workloads.
        def choose():
            if not training:
                return "full"
            near=sorted(training,key=lambda row:np.linalg.norm(f-row[0]))[:2]
            return min(("full","sparse","factor"),key=lambda r:sum(t[r] for _,t in near))
        chosen,choice_ms=clock(choose)
        if idx<4:
            training.append((f,{r:routes[r]["graph_ms"] for r in ("full","sparse","factor")}))
        print(json.dumps(dict(window=idx,batch=size,edges=end,users=len(query),updates_users=len(users),
                              context_ms=context_ms,index_ms=append_ms,structure=meta,routes=routes,
                              cert_ms=cert_ms,cert_top20=cert_count,keep_fraction=fraction,
                              cert_fallback=rank_fallback,adaptive=chosen,selection_ms=choice_ms,
                              calibrating=idx<4,metrics=[*quality(baseline[:,:10],targets),*quality(baseline,targets)])),
              flush=True)
        old,layers,begin=expected,new_layers,end
