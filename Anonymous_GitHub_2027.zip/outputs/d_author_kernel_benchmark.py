"""Exact streaming normalization and propagation on chronological Amazon events."""
from pathlib import Path
import argparse
from sys import getsizeof
import numpy as np
from graph_filter_experiments import timed


class Stream:
    def __init__(self, events, users, items, start):
        self.u, self.i, self.t = events.T
        self.m, self.n = users, items
        self.by_u = [[] for _ in range(users)]
        self.by_i = [[] for _ in range(items)]
        self.append(0,start)

    def append(self,start,end):
        for edge in range(start,end):
            self.by_u[self.u[edge]].append(edge)
            self.by_i[self.i[edge]].append(edge)

    @staticmethod
    def gather(ids, adjacency):
        return np.fromiter((edge for node in ids for edge in adjacency[node]),dtype=np.int64)

    def raw_weights(self, edges, anchor):
        age = anchor[self.u[edges]]-self.t[edges]
        return np.clip(np.exp(-np.log1p(age.astype(np.float32))/self.tau),1e-3,1).astype(np.float64)

    def snapshot(self,end):
        u,i = self.u[:end],self.i[:end]
        anchor = np.zeros(self.m,dtype=np.int64)
        np.maximum.at(anchor,u,self.t[:end])
        raw = self.raw_weights(np.arange(end),anchor)
        du = np.bincount(u,raw,minlength=self.m)
        di = np.bincount(i,raw,minlength=self.n)
        return anchor,raw,du,di,raw/np.sqrt(du[u]*di[i])

    def local_snapshot(self, old, start, end, *, allow_fallback=True):
        anchor,raw,du,di,w = (v.copy() for v in old)
        new = np.arange(start,end)
        users = np.unique(self.u[new])
        np.maximum.at(anchor,self.u[new],self.t[new])
        edges = self.gather(users,self.by_u)
        previous = np.zeros(len(edges))
        existing = edges<start
        previous[existing] = raw[edges[existing]]
        values = self.raw_weights(edges,anchor)
        diff = values-previous
        np.add.at(du,self.u[edges],diff)
        np.add.at(di,self.i[edges],diff)
        items = np.unique(self.i[edges[diff!=0]])
        # The indexed degree sum bounds the normalization footprint from above.
        degree_bound = sum(len(self.by_i[item]) for item in items)
        if allow_fallback and len(edges)+degree_bound > .60*end:
            return None
        touched = np.union1d(edges,self.gather(items,self.by_i))
        raw = np.r_[raw,np.zeros(end-start)]
        raw[edges] = values
        w = np.r_[w,np.zeros(end-start)]
        updated = raw[touched]/np.sqrt(du[self.u[touched]]*di[self.i[touched]])
        change = updated-w[touched]
        w[touched] = updated
        nonzero = change!=0
        return (anchor,raw,du,di,w), touched[nonzero], change[nonzero]

    def apply(self,x,edges,weights):
        u,i = self.u[edges],self.i[edges]
        return np.stack([np.r_[np.bincount(u,weights*v[self.m+i],minlength=self.m),
                               np.bincount(i,weights*v[u],minlength=self.n)]
                         for v in x.T],axis=1)

    def frontier(self,changed):
        users = np.unique(self.u[changed])
        items = np.unique(self.i[changed])
        return np.union1d(self.gather(users,self.by_u),
                          self.gather(items,self.by_i))

    def propagate(self,x,weights):
        edges = slice(0,len(weights))
        first = self.apply(x,edges,weights)
        return first,self.apply(first,edges,weights)


def top10(embedding, query, seen, m, catalog):
    output = []
    for first in range(0,len(query),128):
        ids = query[first:first+128]
        scores = embedding[ids] @ embedding[m:].T
        scores[:,~catalog] = -np.inf
        for index,user in enumerate(ids):
            scores[index,seen[user]] = -np.inf
        candidates = np.argpartition(scores,-10,axis=1)[:,-10:]
        for row, items in zip(scores,candidates):
            output.append(items[np.lexsort((items,-row[items]))])
    return np.array(output)


def fit_embeddings(x, events, m, rng):
    """Fit a fixed BPR backbone to the history, with feature-initialized items."""
    x = x.copy()*.1
    u,i = events[:,:2].T
    n = len(x)-m
    catalog = np.unique(i)
    positive = np.unique(u*n+i)
    def observed(user, item):
        key = user*n+item
        pos = np.minimum(np.searchsorted(positive,key),len(positive)-1)
        return positive[pos]==key

    for _ in range(3):
        order = rng.permutation(len(events))
        for start in range(0,len(order),512):
            batch = order[start:start+512]
            user,pos = u[batch],i[batch]
            neg = rng.choice(catalog,len(batch))
            overlap = observed(user,neg)
            while overlap.any():
                neg[overlap] = rng.choice(catalog,overlap.sum())
                overlap = observed(user,neg)
            pu,pi,pj = x[user],x[m+pos],x[m+neg]
            margin = np.sum(pu*(pi-pj),axis=1)
            coeff = .03/(1+np.exp(np.clip(margin,-40,40)))[:,None]
            np.add.at(x,user,coeff*(pi-pj)-.00003*pu)
            np.add.at(x,m+pos,coeff*pu-.00003*pi)
            np.add.at(x,m+neg,-coeff*pu-.00003*pj)
    return x


def quality(order,truth):
    hits = np.array([np.isin(items,list(target)) for items,target in zip(order,truth)])
    cutoff = order.shape[1]
    discount = 1/np.log2(np.arange(2,cutoff+2))
    counts = np.array([len(t) for t in truth])
    return np.mean(hits.sum(axis=1)/counts),np.mean((hits@discount)/discount.cumsum()[np.minimum(cutoff,counts)-1])


def run(folder,tau):
    events = np.loadtxt(folder/f"{folder.name}.inter",delimiter="\t",skiprows=1,
                        usecols=(0,1,3),dtype=np.int64)
    events = events[np.argsort(events[:,2],kind="stable")]
    m,n = events[:,:2].max(axis=0)+1
    start = int(.70*len(events))
    batch_sizes = (10,100,1000,6000)
    stop = start+sum(batch_sizes)
    assert stop < len(events)
    rng = np.random.default_rng(30)
    initial_catalog = np.isin(np.arange(n),events[:start,1])
    truth = [set() for _ in range(m)]
    for user,item,_ in events[stop:]:
        if initial_catalog[item]:
            truth[user].add(item)
    eligible = np.array([u for u in np.unique(events[:start,0]) if truth[u]])
    users = rng.choice(eligible,5000,replace=False)
    targets = [truth[u] for u in users]
    assert len(np.unique(users))==5000
    item_features = []
    for modality in ("text","image"):
        raw = np.load(folder/f"{modality}_feat.npy",mmap_mode="r")
        values = np.array(raw[:,rng.choice(raw.shape[1],8,replace=False)],dtype=float)
        values -= values.mean(axis=0)
        item_features.append(values/np.maximum(values.std(axis=0),1e-12))
    x = np.vstack((rng.normal(size=(m,16)),np.hstack(item_features)))
    x,train_ms = timed(lambda:fit_embeddings(x,events[:start],m,rng),repeats=1)
    graph,index_ms = timed(lambda:Stream(events[:stop],m,n,start),repeats=1)
    graph.tau = tau
    old,cache_ms = timed(lambda:graph.snapshot(start),repeats=1)
    (h1,h2),prop_cache_ms = timed(lambda:graph.propagate(x,old[-1]),repeats=1)
    index_bytes = sum(getsizeof(row) for row in graph.by_u+graph.by_i) + start*getsizeof(0)
    print(f"setup,{folder.name},tau={tau},index_ms={index_ms:.3f},cache_ms={cache_ms+prop_cache_ms:.3f},"
          f"train_ms={train_ms:.3f},index_mib={index_bytes/2**20:.3f},layer_cache_mib={(h1.nbytes+h2.nbytes)/2**20:.3f}",flush=True)
    seen = [[] for _ in range(m)]
    for u,i,_ in events[:start]:
        seen[u].append(i)
    for size in batch_sizes:
        end = start+size
        _,append_ms = timed(lambda:graph.append(start,end),repeats=1)
        for u,i,_ in events[start:end]:
            seen[u].append(i)
        reference,global_ms = timed(lambda:graph.snapshot(end))
        (full1,full2),full_ms = timed(lambda:graph.propagate(x,reference[-1]))
        def scan():
            delta = reference[-1]-np.r_[old[-1],np.zeros(size)]
            ids = np.flatnonzero(delta)
            return ids,delta[ids]

        (scan_edges,scan_delta),scan_extract_ms = timed(scan)

        def update(edges,delta,w,frontier):
            dh1 = graph.apply(x,edges,delta)
            dh2 = graph.apply(h1,edges,delta)
            if frontier is None:
                dh2 += graph.apply(dh1,slice(0,end),w)
            else:
                dh2 += graph.apply(dh1,frontier,w[frontier])
            return h1+dh1,h2+dh2

        global_layers,scan_ms = timed(lambda:update(scan_edges,scan_delta,reference[-1],None))
        scanned_frontier,scan_frontier_ms = timed(lambda:graph.frontier(scan_edges))
        scan_local_layers,scan_local_ms = timed(
            lambda:update(scan_edges,scan_delta,reference[-1],scanned_frontier))

        def dispatch():
            patch = None if 256*size >= end else graph.local_snapshot(old,start,end)
            if patch is None:
                state = graph.snapshot(end)
                return state,graph.propagate(x,state[-1]),"full"
            state,changed,dw = patch
            if 2*len(changed) >= 1.5*end:
                return state,graph.propagate(x,state[-1]),"local_norm_full"
            frontier = graph.frontier(changed)
            if 2*len(changed)+len(frontier) >= 1.5*end:
                return state,graph.propagate(x,state[-1]),"local_norm_full"
            return state,update(changed,dw,state[-1],frontier),"local"

        (local,new_layers,route),adaptive_ms = timed(dispatch)
        np.testing.assert_allclose(local[-1],reference[-1],rtol=2e-10,atol=1e-13)
        catalog=reference[3]>0
        layers = [(full1,full2),global_layers,scan_local_layers,new_layers]
        embeddings = [x+first+second for first,second in layers]
        rankings = [timed(lambda emb=emb:top10(emb,users,seen,m,catalog)) for emb in embeddings]
        for answer,_ in rankings[1:]:
            np.testing.assert_array_equal(answer,rankings[0][0])
        recall,ndcg = quality(rankings[0][0],targets)
        error=max(float(np.max(np.abs(v-embeddings[0]))) for v in embeddings[1:])
        assert error < 1e-9
        print(f"window,{folder.name},tau={tau},batch={size},history={start},users=5000,top10=5000/5000,"
              f"changed={len(scan_edges)},frontier={len(scanned_frontier)},route={route},"
              f"full_ms={global_ms+full_ms:.3f},global_delta_ms={global_ms+scan_extract_ms+scan_ms:.3f},"
              f"global_frontier_ms={append_ms+global_ms+scan_extract_ms+scan_frontier_ms+scan_local_ms:.3f},"
              f"adaptive_ms={append_ms+adaptive_ms:.3f},"
              f"R10={recall:.6f},N10={ndcg:.6f},rank_ms={'/'.join(f'{ms:.3f}' for _,ms in rankings)},error={error:.3g}",flush=True)
        old,h1,h2,start = local,*new_layers,end


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("folders",nargs="+",type=Path)
    for folder in parser.parse_args().folders:
        for tau in (4.,6.,10.):
            run(folder,tau)
