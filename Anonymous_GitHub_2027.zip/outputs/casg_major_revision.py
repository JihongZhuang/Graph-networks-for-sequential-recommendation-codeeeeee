"""Five-route CASG replay with measured raw-prefix startup and phase timings."""
import argparse
from collections import Counter, defaultdict
import ctypes
import json
from math import comb
from pathlib import Path
import pickle
import platform
from time import perf_counter, time

import numpy as np
from numpy.polynomial import Polynomial
import psutil
from scipy.sparse import csr_matrix
from threadpoolctl import threadpool_limits
import torch

from casg_cinm import FullRowIndex, MaterializedTopK, OrderedIndex, WinnerIndex, edge, load_replay
from exact_polynomial import full_layers, polynomial
from integration_casg import append_merged, rank_checked
from saeif_casg_pilot import append, full_graph, matrix, timed
from saeif_casg_sasrec import SampledProjection, author_model


DATASETS = ('Luxury_Beauty', 'Musical_Instruments', 'Yelp2018_matched')
INDEXES = {'affected_rows': FullRowIndex, 'ordered': OrderedIndex,
           'view': MaterializedTopK, 'CINM': WinnerIndex}
ROUTES = ('full_rebuild', *INDEXES)


def emit(**record):
    print(json.dumps(record), flush=True)


def add_history(events, histories):
    for user, item, _ in events:
        histories[user].append(item)


def rebuild(events, n):
    counts = Counter()
    _, count_ms = timed(lambda: append(events, counts, defaultdict(list)))

    def select():
        incident = defaultdict(list)
        for (i, j), count in counts.items():
            incident[i].append((j, count))
            incident[j].append((i, count))
        kept = {edge(i, j) for i, row in incident.items()
                for j, _ in sorted(row, key=lambda key: (-key[1], str(key[0])))[:20]}
        return {pair: counts[pair] for pair in kept}

    weights, selection_ms = timed(select)
    op, normalization_ms = timed(lambda: matrix(weights, n))
    return op, dict(count_ms=count_ms, selection_ms=selection_ms,
                    normalization_ms=normalization_ms, state_ms=0.,
                    candidate_keys=2 * len(counts), changed_normalized_candidates=len(weights))


def maintain(state, counts, changed):
    """WinnerIndex.update, split at the existing selection and normalization stages."""
    t = perf_counter()
    candidates = defaultdict(set)
    for i, j in changed:
        candidates[i].add(j)
        candidates[j].add(i)
    affected = set(changed)
    examined = 0
    for i, neighbors in candidates.items():
        before = state.winners[i]
        after, compared = state.select(i, neighbors, counts)
        examined += compared
        state.winners[i] = after
        affected.update(edge(i, j) for j in before ^ after)
    selection_ms = (perf_counter() - t) * 1000

    t = perf_counter()
    degree_change = Counter()
    dirty = set()
    for i, j in affected:
        old = state.weights.get((i, j), 0)
        new = counts[i, j] if j in state.winners[i] or i in state.winners[j] else 0
        if new == old:
            continue
        dirty.add((i, j))
        degree_change[i] += new - old
        degree_change[j] += new - old
        if new:
            state.weights[i, j] = new
            state.links[i].add(j)
            state.links[j].add(i)
        else:
            del state.weights[i, j]
            state.links[i].remove(j)
            state.links[j].remove(i)
    state_ms = (perf_counter() - t) * 1000

    t = perf_counter()
    for i, change in degree_change.items():
        if change:
            state.degree[i] += change
            dirty.update(edge(i, j) for j in state.links[i])
    if dirty:
        pairs = list(dirty)
        row, col = np.asarray(pairs).T
        new = np.asarray([state.weights.get(pair, 0) for pair in pairs], dtype=float)
        present = new > 0
        new[present] /= np.sqrt(state.degree[row[present]] * state.degree[col[present]])
        old = np.asarray(state.operator[row, col]).ravel()
        delta = new - old
        patch = csr_matrix((np.tile(delta, 2), (np.r_[row, col], np.r_[col, row])),
                           shape=state.operator.shape)
        state.operator = state.operator + patch
    normalization_ms = (perf_counter() - t) * 1000

    if isinstance(state, OrderedIndex):
        t = perf_counter()
        for pair in changed:
            state.old_counts[pair] = counts[pair]
        state_ms += (perf_counter() - t) * 1000
    return state.operator, dict(selection_ms=selection_ms, normalization_ms=normalization_ms,
                                state_ms=state_ms, candidate_keys=examined,
                                changed_normalized_candidates=len(dirty))


def check():
    rng = np.random.default_rng(893)
    events = np.column_stack((rng.integers(8, size=250), rng.integers(45, size=250), np.arange(250)))
    counts = Counter()
    histories = defaultdict(list)
    append(events[:100], counts, histories)
    paired = [(cls(counts, 45), cls(counts, 45)) for cls in INDEXES.values()]
    for lo, hi in ((100, 110), (110, 150), (150, 250)):
        changed = append_merged(events[lo:hi], counts, histories)
        reference, _ = rebuild(events[:hi], 45)
        assert (reference != full_graph(events[:hi], 45)).nnz == 0
        for original, instrumented in paired:
            expected, *_ = original.update(counts, changed)
            actual, _ = maintain(instrumented, counts, changed)
            different = {key: (original.winners.get(key), instrumented.winners.get(key))
                         for key in original.winners.keys() | instrumented.winners.keys()
                         if original.winners.get(key) != instrumented.winners.get(key)}
            assert not different, (type(original).__name__, lo, different)
            assert original.weights == instrumented.weights
            assert np.array_equal(original.degree, instrumented.degree)
            assert (expected != actual).nnz == 0
            assert np.max(np.abs((reference - actual).data), initial=0) < 1e-14
    print('All five instrumented graph routes match the frozen kernels.')


def run(dataset, repeats):
    folder = Path('work/saeif/casg') / dataset
    train, test, sizes, weights, total, n = load_replay(folder, Path('outputs') / f'saceif_general_casg_{dataset}.txt')
    prefix = len(train) - sum(sizes)
    depth = len(weights) - 1
    p, q = Polynomial([.5, .5]), Polynomial([.5, -.5])
    coeff = sum(w * comb(depth, k) * p**k * q**(depth-k) for k, w in enumerate(weights)).coef
    with (folder / 'bert_cls.pkl').open('rb') as f:
        inputs = np.asarray(pickle.load(f), np.float64)
    inputs -= inputs.mean(axis=0)
    model = author_model(torch.from_numpy(inputs).float())
    model.in_proj = SampledProjection(model.in_proj, n)
    model.load_state_dict(torch.load(folder / 'sasrec_validation_selected.pt', weights_only=True))
    model.eval()

    def filter_graph(op):
        features = polynomial(full_layers(op, inputs, depth), coeff)
        isolated = np.diff(op.indptr) == 0
        features[isolated] = inputs[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(features).float())

    warm_histories = defaultdict(list)
    add_history(train[:prefix], warm_histories)
    warm_users = np.array(sorted(warm_histories)[:128])
    warm_op = full_graph(train[:prefix], n)
    rank_checked(model, filter_graph(warm_op), warm_histories, warm_users, test)
    del warm_op, warm_histories
    emit(kind='metadata', dataset=dataset, prefix=prefix, stop=len(train), interactions=total,
         items=n, repeats=repeats, batches=sizes, thread_count=torch.get_num_threads(),
         platform=platform.platform(), python=platform.python_version(), torch=torch.__version__,
         cuda_build=torch.version.cuda, ram_bytes=psutil.virtual_memory().total,
         seed_model=30, seed_route_order='974 + repeat',
         warmup='one untimed full prefix graph, filter and 128-user full-catalog batch per dataset',
         startup_scope='resident chronological events to history and index; independent per repeat')
    for repeat in range(1, repeats + 1):
        rng = np.random.default_rng(974 + repeat)
        histories_full, histories = defaultdict(list), defaultdict(list)
        counts = Counter()
        for name in rng.permutation(['full_rebuild', 'maintained']):
            if name == 'full_rebuild':
                _, history_ms = timed(lambda: add_history(train[:prefix], histories_full))
            else:
                _, counts_ms = timed(lambda: append(train[:prefix], counts, histories))
        query = np.array(sorted(u for u, h in histories.items() if h and test.loc[u] not in h))
        assert len(query) >= 5000 and histories == histories_full
        emit(kind='initialization', dataset=dataset, repeat=repeat, route='full_rebuild',
             users=len(query), prefix_ms=history_ms, index_ms=0.)
        states = {}
        for name in rng.permutation(list(INDEXES)):
            states[name], index_ms = timed(lambda: INDEXES[name](counts, n))
            emit(kind='initialization', dataset=dataset, repeat=repeat, route=name,
                 users=len(query), prefix_ms=counts_ms, index_ms=index_ms)
        begin = prefix
        for window, size in enumerate(sizes, 1):
            wall_start, monotonic_start = time(), perf_counter()
            end = begin + size
            events = train[begin:end]
            changed, count_ms = timed(lambda: append_merged(events, counts, histories))
            _, history_ms = timed(lambda: add_history(events, histories_full))
            assert all(histories[u] == histories_full[u] for u, _, _ in events)
            results, operators, features, tops = {}, {}, {}, {}
            order = rng.permutation(ROUTES).tolist()
            for name in order:
                if name == 'full_rebuild':
                    (op, metrics), graph_ms = timed(lambda: rebuild(train[:end], n))
                    history_time, score_history = history_ms, histories_full
                else:
                    (op, metrics), graph_ms = timed(lambda: maintain(states[name], counts, changed))
                    metrics['count_ms'] = count_ms
                    graph_ms += count_ms
                    history_time, score_history = 0., histories
                z, filter_ms = timed(lambda: filter_graph(op))
                top, _, _, score_ms = rank_checked(model, z, score_history, query, test)
                operators[name], features[name], tops[name] = op, z, top
                metrics.update(graph_ms=graph_ms, filter_ms=filter_ms, score_rank_ms=score_ms,
                               history_ms=history_time,
                               total_ms=graph_ms + history_time + filter_ms + score_ms)
                results[name] = metrics
            reference = operators['full_rebuild']
            for name, result in results.items():
                error = float(np.max(np.abs((operators[name] - reference).data), initial=0))
                same = torch.equal(features[name], features['full_rebuild'])
                matches = int(np.all(tops[name] == tops['full_rebuild'], axis=1).sum())
                assert error < 1e-14 and same and matches == len(query), (name, error, same, matches)
                result.update(operator_error=error, identical_scorer_input=same, top20_matches=matches)
            emit(kind='window', dataset=dataset, repeat=repeat, window=window, batch=size,
                 users=len(query), changed_pairs=len(changed), order=order, routes=results,
                 elapsed_ms=(perf_counter() - monotonic_start) * 1000,
                 wall_elapsed_ms=(time() - wall_start) * 1000)
            del results, operators, features, tops, reference, op, z, top
            begin = end


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('dataset', nargs='?', choices=DATASETS)
    parser.add_argument('--repeats', type=int, default=3)
    parser.add_argument('--check', action='store_true')
    args = parser.parse_args()
    torch.manual_seed(30)
    torch.set_num_threads(4)
    with threadpool_limits(limits=4):
        if args.check:
            check()
        else:
            if args.dataset is None:
                parser.error('a dataset is required')
            if platform.system() == 'Windows':
                ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
            run(args.dataset, args.repeats)
