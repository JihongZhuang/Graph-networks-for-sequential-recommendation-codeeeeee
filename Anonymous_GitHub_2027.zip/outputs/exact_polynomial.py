"""Evaluation and exact-arithmetic updates for polynomial filters."""


def full_layers(operator, inputs, depth):
    layers = [inputs]
    for _ in range(depth):
        layers.append(operator @ layers[-1])
    return layers


def update_layers(operator, delta_operator, delta_inputs, cached):
    delta = delta_inputs
    layers = [cached[0] + delta]
    for old_input, old_result in zip(cached, cached[1:]):
        delta = delta_operator @ old_input + operator @ delta
        layers.append(old_result + delta)
    return layers


def polynomial(layers, coefficients):
    result = coefficients[-1] * layers[-1]
    for weight, layer in zip(reversed(coefficients[:-1]), reversed(layers[:-1])):
        if weight:
            result += weight * layer
    return result
