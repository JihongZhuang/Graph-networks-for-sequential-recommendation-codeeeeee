"""Train an independent DIGEST-style checkpoint using the published losses."""
import argparse
from pathlib import Path
from time import perf_counter

import numpy as np
import torch
from torch import nn
import torch.nn.functional as F

from saeif_digest_pilot import cosine_neighbors


class DIGEST(nn.Module):
    def __init__(self,m,n,visual,textual,semantic_edges):
        super().__init__()
        self.m,self.n=m,n
        self.ids=nn.Parameter(torch.empty(m+n,64))
        nn.init.xavier_normal_(self.ids)
        self.visual=nn.Linear(visual.shape[1],64,bias=False)
        self.text=nn.Linear(textual.shape[1],64,bias=False)
        self.gate=nn.Linear(128,64)
        self.register_buffer("v",visual)
        self.register_buffer("t",textual)
        self.semantic=semantic_edges

    @staticmethod
    def view(x,rows,cols,base,undirected):
        v=x
        result=x
        for _ in range(2):
            w=(v[rows]*v[cols].tanh()).sum(dim=-1).sigmoid()
            if base is not None:
                w=w*base
            dst,src=rows,cols
            if undirected:
                dst,src,w=torch.cat((rows,cols)),torch.cat((cols,rows)),torch.cat((w,w))
            d=torch.zeros(len(x),dtype=x.dtype).index_add_(0,dst,w).clamp_min(1e-12)
            coeff=w*(d[dst]*d[src]).rsqrt()
            v=torch.zeros_like(v).index_add_(0,dst,coeff[:,None]*v[src])
            result=result+v
        return result/3

    def forward(self,rows,cols):
        collaborative=self.view(self.ids,rows,cols,None,True)
        items=collaborative[self.m:]
        semantic=self.view(self.ids[self.m:],*self.semantic,False)
        gate=self.gate(torch.cat((items,semantic),dim=-1)).sigmoid()
        return collaborative[:self.m],gate*items+(1-gate)*semantic,items,semantic


def train(folder,checkpoint,steps):
    torch.set_num_threads(4)
    torch.manual_seed(30)
    rng=np.random.default_rng(30)
    events=np.loadtxt(folder/f"{folder.name}.inter",delimiter="\t",skiprows=1,
                      usecols=(0,1,3),dtype=np.int64)
    events=events[np.argsort(events[:,2],kind="stable")]
    m,n=events[:,:2].max(axis=0)+1
    end=int(.70*len(events))
    valid_end=int(.75*len(events))
    train=events[:end,:2]
    r,c=train.T
    history=[set() for _ in range(m)]
    for u,i in train:
        history[u].add(i)
    validation=[set() for _ in range(m)]
    for u,i,_ in events[end:valid_end]:
        if i not in history[u]:
            validation[u].add(i)
    val=np.array([u for u in range(m) if history[u] and validation[u]])
    val=rng.choice(val,min(2500,len(val)),replace=False)
    degree_u=np.bincount(r,minlength=m)
    degree_i=np.bincount(c,minlength=n)
    weights=(degree_u[r]*degree_i[c])**-.5
    weights/=weights.sum()
    text=cosine_neighbors(folder,"text",n)
    image=cosine_neighbors(folder,"image",n)
    src=np.repeat(np.arange(n),6)
    semantic=(torch.from_numpy(np.tile(src,2)),
              torch.from_numpy(np.r_[text.ravel(),image.ravel()].astype(np.int64)),
              torch.cat((torch.full((n*6,),.9),torch.full((n*6,),.1))))
    model=DIGEST(m,n,torch.from_numpy(np.load(folder/"image_feat.npy")).float(),
                 torch.from_numpy(np.load(folder/"text_feat.npy")).float(),semantic)
    optimizer=torch.optim.Adam(model.parameters(),lr=.001)
    tr=torch.from_numpy(r.copy())
    tc=torch.from_numpy(c.copy()+m)

    @torch.no_grad()
    def valid():
        user,item,*_=model(tr,tc)
        hits=[]
        for block in np.array_split(val,20):
            scores=user[block]@item.T
            for j,u in enumerate(block):
                scores[j,list(history[u])]=-torch.inf
            top=scores.topk(20,dim=1).indices.numpy()
            hits.extend(len(set(row)&validation[u])/len(validation[u]) for u,row in zip(block,top))
        return float(np.mean(hits))

    best=-1
    for step in range(1,steps+1):
        start=perf_counter()
        kept=rng.choice(end,int(.9*end),p=weights,replace=False)
        u,i=train[rng.choice(end,8192,replace=True)].T
        j=rng.integers(n,size=len(u))
        invalid=np.array([b in history[a] for a,b in zip(u,j)])
        while invalid.any():
            j[invalid]=rng.integers(n,size=invalid.sum())
            invalid=np.array([b in history[a] for a,b in zip(u,j)])
        user,item,collaborative,semantic=model(tr[kept],tc[kept])
        batch=rng.choice(n,1024,replace=False)
        labels=torch.arange(len(batch))
        content=.1*model.visual(model.v[batch])+.9*model.text(model.t[batch])
        sem=F.normalize(semantic[batch])
        align=F.cross_entropy(F.normalize(collaborative[batch])@sem.T/.2,labels)
        align+=F.cross_entropy(sem@F.normalize(content).T/.2,labels)
        z=semantic[batch]
        z=(z-z.mean(dim=0))/(z.std(dim=0,unbiased=False)+1e-6)
        corr=z.T@z/len(batch)
        ddr=(corr-torch.eye(64)).square().sum()
        bpr=F.softplus(-(user[u]*(item[i]-item[j])).sum(dim=-1)).mean()
        reg=sum(w.square().sum() for w in model.parameters())
        loss=bpr+.01*align+.001*ddr+1e-5*reg
        optimizer.zero_grad(set_to_none=True)
        loss.backward()
        optimizer.step()
        if step in (1,steps) or step%10==0:
            metric=valid()
            if metric>best:
                best=metric
                torch.save({"ids":model.ids.detach(),"fusion_weight":model.gate.weight.detach(),
                            "fusion_bias":model.gate.bias.detach(),"step":step,"recall20":best},checkpoint)
            print(f"step={step},loss={loss.item():.6f},valid_recall20={metric:.6f},best={best:.6f},last_step_s={perf_counter()-start:.3f}",flush=True)


if __name__=="__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("folder",type=Path)
    parser.add_argument("checkpoint",type=Path)
    parser.add_argument("--steps",type=int,default=60)
    args=parser.parse_args()
    train(args.folder,args.checkpoint,args.steps)
