"""Exact-reference experiments for low-degree screening and dynamic updates."""
from time import perf_counter
import numpy as np
from cram_gf import operators, ranking
from mmgf_low_degree_control import CONFIGS


class Graph:
    def __init__(self, n, rng):
        self.n = n
        self.u = np.repeat(np.arange(n), 16)
        self.i = self.u // 50 * 50 + rng.integers(50, size=self.u.size)
        mixed = rng.random(self.u.size) < .15
        self.i[mixed] = rng.integers(n, size=mixed.sum())
        self.raw = np.ones(self.u.size)
        self.by_item = np.argsort(self.i)
        self.offsets = np.r_[0, np.cumsum(np.bincount(self.i, minlength=n))]
        self.weights = self.normalize(self.raw)

    def normalize(self, raw):
        rows = np.bincount(self.u, raw, minlength=self.n)
        cols = np.bincount(self.i, raw, minlength=self.n)
        return raw / np.sqrt(rows[self.u] * cols[self.i])

    def mul(self, x, weights, transpose=False):
        src, dst = (self.u, self.i) if transpose else (self.i, self.u)
        return np.bincount(dst, weights * x[src], minlength=self.n)

    def gram(self, x, weights):
        return self.mul(self.mul(x, weights), weights, True)

    def selected(self, y, items):
        starts, ends = self.offsets[items], self.offsets[items + 1]
        counts = ends - starts
        slots = np.repeat(starts - np.r_[0, np.cumsum(counts[:-1])], counts)
        edges = self.by_item[slots + np.arange(slots.size)]
        return np.bincount(self.i[edges], self.weights[edges] * y[self.u[edges]], minlength=self.n), edges.size


def timed(function, repeats=3):
    times = []
    for _ in range(repeats):
        start = perf_counter()
        result = function()
        times.append(perf_counter() - start)
    return result, 1e3 * np.median(times)


def signals(n, rng, count):
    rows = np.zeros((count, n))
    for r in rows:
        block = rng.integers(n // 50)
        r[block * 50 + rng.choice(50, 8, replace=False)] = 1
    return rows


def screen(n, seed, name, config):
    rng = np.random.default_rng(seed)
    g = Graph(n, rng)
    _, text_op, image_op = operators(rng, n)
    a, b, c, beta, gamma = config
    # Group repeated (user,item) edges before taking squared column norms.
    # For multiplicities, sum(weights^2) alone would underestimate the norm.
    key = g.u * n + g.i
    _, first, inv = np.unique(key, return_index=True, return_inverse=True)
    values = np.bincount(inv, g.weights)
    column_norm = np.sqrt(np.bincount(g.i[first], values**2, minlength=n))
    rows = signals(n, rng, 40)

    def run(prune):
        results, total_edges, retained = [], 0, 0
        for r in rows:
            candidates = np.flatnonzero(r == 0)
            v = g.gram(r, g.weights)
            w = g.gram(v, g.weights)
            base = a*v + b*w + beta*text_op(r)
            if gamma:
                base += gamma*image_op(r)
            y = g.mul(w, g.weights)
            pool = candidates
            if prune:
                # Nonnegative B and y yield the one-sided interval 0 <= z_i <= bound_i.
                width = abs(c) * column_norm[candidates] * np.linalg.norm(y)
                lower = base[candidates] - (width if c < 0 else 0)
                upper = base[candidates] + (width if c > 0 else 0)
                kth = np.partition(lower, -10)[-10]
                pool = candidates[upper >= kth - 1e-12]
                if pool.size > 0.75 * candidates.size:
                    pool = candidates
            if pool.size == candidates.size:
                final = g.mul(y, g.weights, True)
                edges = g.i.size
            else:
                final, edges = g.selected(y, pool)
            total_edges += edges
            retained += pool.size
            # Existing ranking requires at least K+1 candidates.
            if pool.size == 10:
                order = pool[np.lexsort((pool, -(base + c*final)[pool]))]
            else:
                order = ranking(base + c*final, pool)[0]
            results.append(order)
        return results, total_edges / (len(rows)*g.i.size), retained / (len(rows)*(n-8))

    (reference, _, _), full_ms = timed(lambda: run(False))
    (result, edge_ratio, pool_ratio), screen_ms = timed(lambda: run(True))
    assert all(np.array_equal(x, y) for x, y in zip(reference, result))
    print(f"A,{n},{seed},{name},{pool_ratio:.6f},{edge_ratio:.6f},{full_ms/40:.6f},{screen_ms/40:.6f}", flush=True)


def dynamic(n, seed, q, normalization):
    rng = np.random.default_rng(seed)
    g = Graph(n, rng)
    raw = g.raw.copy()
    users = rng.choice(n, q, replace=False)
    edited = users * 16
    raw[edited] += .5
    columns = np.unique(g.i[edited])
    old = g.weights
    new = g.normalize(raw) if normalization == "recomputed" else raw * old
    a = np.array([.05, .7, -.3, .15])
    rows = signals(n, rng, 256)
    dr = np.zeros_like(rows)
    # Include changed query signals and exclude newly seen candidates.
    for r, change in zip(rows[:q], dr[:q]):
        change[np.flatnonzero(r == 0)[0]] = 1

    def polynomial(x, weights):
        y = a[-1]*x
        for coefficient in a[-2::-1]:
            y = g.gram(y, weights) + coefficient*x
        return y

    def factor():
        # Delta B = F G.T, with row corrections and changed-column scaling.
        old_scaled = old.copy()
        if normalization == "recomputed":
            d0 = np.bincount(g.i, minlength=n)
            d1 = np.bincount(g.i, raw, minlength=n)
            old_scaled *= np.sqrt(d0[g.i] / d1[g.i])
        delta_rows = new - old_scaled
        left, right = [], []
        for u in users:
            sel = slice(u*16, (u+1)*16)
            e = np.zeros(n)
            e[u] = 1
            left.append(e)
            right.append(np.bincount(g.i[sel], delta_rows[sel], minlength=n))
        if normalization == "recomputed":
            for i in columns:
                mask = g.i == i
                left.append(np.bincount(g.u[mask], (old_scaled-old)[mask], minlength=n))
                e = np.zeros(n)
                e[i] = 1
                right.append(e)
        F, G = np.array(left), np.array(right)
        U = np.vstack(([g.mul(f, new, True) for f in F], G))
        V = np.vstack((G, [g.mul(f, old, True) for f in F]))
        probe = rows[0]
        np.testing.assert_allclose(U.T @ (V @ probe),
                                   g.gram(probe,new)-g.gram(probe,old), atol=1e-12)
        return U, V

    def prepare(exact):
        U, V = factor()
        Y, W = [U], [a[-1]*V]
        for coefficient in a[-2:0:-1]:
            Y.append(np.array([g.gram(y, new if exact else old) for y in Y[-1]]))
            W.append(coefficient*V + np.array([g.gram(w, old) for w in W[-1]]))
        return np.vstack(Y), np.vstack(W[::-1])

    old_scores = np.array([polynomial(r, old) for r in rows])
    for exact in (True, False):
        (Y, W), prep_ms = timed(lambda: prepare(exact))
        for h in (16, 64, 256):
            current = rows[:h]+dr[:h]
            ref, ref_ms = timed(lambda: np.array([polynomial(r,new) for r in current]))

            def update():
                scores = old_scores[:h] + (rows[:h] @ W.T) @ Y
                for j in np.flatnonzero(dr[:h].any(axis=1)):
                    scores[j] += polynomial(dr[j], new if exact else old)
                return scores

            scores, update_ms = timed(update)
            error = np.max(np.abs(scores-ref))
            matches = []
            for r, target, result in zip(current, ref, scores):
                eligible = np.flatnonzero(r == 0)
                matches.append(set(ranking(target,eligible)[0]) == set(ranking(result,eligible)[0]))
            if exact:
                assert error < 1e-11 and all(matches)
            print(f"D,{n},{seed},{q},{normalization},{int(exact)},{h},{Y.shape[0]//3},"
                  f"{(Y.nbytes+W.nbytes+old_scores[:h].nbytes)/2**20:.6f},{prep_ms:.6f},"
                  f"{update_ms:.6f},{ref_ms:.6f},{error:.9g},{np.mean(matches):.6f}", flush=True)


if __name__ == "__main__":
    print("A,items,seed,profile,retained_ratio,last_transpose_edge_ratio,full_ms_per_query,screen_ms_per_query")
    for n in (500, 3000):
        for seed in (11, 23, 37):
            for name, config in CONFIGS.items():
                screen(n, seed, name, config)
    print("D,items,seed,changed_rows,normalization,exact,queries,factor_width,cache_mib,prep_ms,update_ms,recompute_ms,max_abs_error,set_match")
    for q in (1, 5, 20):
        for mode in ("fixed", "recomputed"):
            for seed in (11, 23, 37):
                dynamic(1500, seed, q, mode)
