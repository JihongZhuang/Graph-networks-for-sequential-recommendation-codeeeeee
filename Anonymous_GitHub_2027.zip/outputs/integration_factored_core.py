"""Separately versioned lazy normalization candidate for the integration study.

This candidate is not a replacement of the frozen spectral benchmark.
"""
import numpy as np
from scipy.sparse import csr_matrix, issparse


def scale_rows(x, scale):
    return x.multiply(scale[:, None]).tocsr() if issparse(x) else scale[:, None]*x


class ScaledCore:
    """A = diag(scale) raw diag(scale); no normalized-edge materialization."""
    def __init__(self, raw, scale):
        self.raw=raw.tocsr();self.scale=np.asarray(scale);self.shape=raw.shape
        self.indptr=self.raw.indptr

    def __matmul__(self, x):
        return scale_rows(self.raw@scale_rows(x,self.scale),self.scale)

    def materialize(self):
        return self.raw.multiply(self.scale[:,None]).multiply(self.scale[None,:]).tocsr()


class ScaledDifference:
    """Exact difference using changed diagonal rows/columns and a raw sparse core."""
    def __init__(self, old, new, raw_delta):
        self.shape=old.shape
        ratio=np.divide(new.scale,old.scale,out=np.ones_like(new.scale),where=old.scale!=0)
        self.ratio=ratio;self.diagonal=ratio-1;self.ids=np.flatnonzero(self.diagonal)
        # Old zero-scale rows have zero old operator. Their new values enter via E.
        self.rows=old.raw[self.ids].multiply(old.scale[self.ids,None]).multiply(old.scale[None,:]).tocsr()
        self.cols=old.raw.tocsc()[:,self.ids].multiply(old.scale[:,None]).multiply(old.scale[self.ids][None,:]).tocsr()
        self.core=raw_delta.multiply(new.scale[:,None]).multiply(new.scale[None,:]).tocsr()

    def __matmul__(self, x):
        result=self.core@x
        if len(self.ids):
            row=scale_rows(self.rows@scale_rows(x,self.ratio),self.diagonal[self.ids])
            col=self.cols@scale_rows(x[self.ids],self.diagonal[self.ids])
            if issparse(x):
                coo=row.tocoo()
                row=csr_matrix((coo.data,(self.ids[coo.row],coo.col)),shape=(self.shape[0],x.shape[1]))
                result=result+row+col
            else:
                result+=col;result[self.ids]+=row
        return result


def powered_core_delta(old_gram, delta, power):
    """Entrywise power is applied to old+delta, never to delta alone."""
    delta=delta.tocoo();u,v=delta.row,delta.col
    previous=np.asarray(old_gram[u,v]).ravel()
    updated=previous+delta.data
    tolerance=1e-12*max(1.,float(np.max(previous,initial=0)))
    assert float(np.min(updated,initial=0))>=-tolerance
    values=np.maximum(updated,0)**power-previous**power
    result=csr_matrix((values,(u,v)),shape=old_gram.shape);result.eliminate_zeros()
    return result


def check():
    rng=np.random.default_rng(443);n=25
    a=rng.random((n,n));a[a<.8]=0;a=a+a.T;a[0]=0;a[:,0]=0
    delta=np.zeros_like(a);delta[0,4]=delta[4,0]=.5;delta[2,7]=delta[7,2]=-.1*a[2,7]
    s=rng.random(n)+.5;s[0]=0;t=s.copy();t[[0,3,5]]=[.8,.9,1.7]
    for power in (1.,.6):
        raw=csr_matrix(a**power);dd=powered_core_delta(csr_matrix(a),csr_matrix(delta),power)
        old=ScaledCore(raw,s);new=ScaledCore(raw+dd,t);change=ScaledDifference(old,new,dd)
        expected=new.materialize()-old.materialize()
        for x in (rng.normal(size=(n,8)),csr_matrix(rng.normal(size=(n,8))*(rng.random((n,8))>.7))):
            actual=change@x;reference=expected@x
            error=float(np.max(np.abs((actual-reference).data),initial=0)) if issparse(x) else float(np.max(np.abs(actual-reference)))
            assert error<1e-12,error
    print('Scaled-core/difference checks passed, including zero-degree and nonlinear power.')


if __name__=='__main__':check()
