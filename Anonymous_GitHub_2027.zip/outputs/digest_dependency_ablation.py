"""Measure separate contributions of cached DIGEST gates and propagation."""
import argparse
import json
from pathlib import Path

import numpy as np
from scipy.sparse import csr_matrix
from scipy.special import expit
import torch

from d_author_kernel_benchmark import quality
from saeif_digest_pilot import cosine_neighbors, gates, normalized, timed
from saceif_benchmark import peak_mib


def run(folder, checkpoint, users):
    torch.set_num_threads(4)
    events = np.loadtxt(folder/f"{folder.name}.inter", delimiter="\t", skiprows=1,
                        usecols=(0, 1, 3), dtype=np.int64)
    events = events[np.argsort(events[:, 2], kind="stable")]
    source, item = events[:, :2].T.copy()
    m, n = source.max()+1, item.max()+1
    destination = item+m
    state = torch.load(checkpoint, map_location="cpu", weights_only=True)
    x = state["ids"].numpy().astype(np.float64)
    weight, bias = state["fusion_weight"].numpy(), state["fusion_bias"].numpy()
    start = int(.75*len(events))+7310
    sizes = (10, 50, 100, 1000)
    stop = start+sum(sizes)
    active = np.bincount(item[:start], minlength=n)>0
    future = [set() for _ in range(m)]
    for u, i in zip(source[stop:], item[stop:]):
        if active[i]:
            future[u].add(i)
    eligible = [u for u in np.unique(source[:start]) if future[u]]
    query = (np.asarray(eligible) if users==0 else
             np.random.default_rng(30).choice(eligible, users, replace=False))
    users = len(query)
    targets = [future[u] for u in query]

    def semantic():
        adj = csr_matrix((n,n), dtype=np.float64)
        for scale, tag in ((.9,"text"), (.1,"image")):
            cols = cosine_neighbors(folder, tag, n).ravel()
            adj += csr_matrix((np.full(n*6, scale), (np.repeat(np.arange(n),6),cols)), shape=(n,n))
        a, b = adj.nonzero()
        base = np.asarray(adj[a,b]).ravel()
        y = total = x[m:]
        for _ in range(2):
            raw = base*gates(y,a,b)
            degree = np.maximum(np.bincount(a,raw,minlength=n),1e-12)
            op = csr_matrix((raw/np.sqrt(degree[a]*degree[b]), (a,b)), shape=(n,n))
            y = op@y
            total = total+y
        return total/3

    sem, sem_ms = timed(semantic)
    def full(end):
        a, b = source[:end], destination[:end]
        raw0 = gates(x,a,b)
        op0 = normalized(a,b,raw0,m+n)
        h1 = op0@x
        raw1 = gates(h1,a,b)
        op1 = normalized(a,b,raw1,m+n)
        return raw0, op0, h1, raw1, op1, op1@h1

    for repeat in (1,2):
        old, init_ms = timed(lambda:full(start))
        begin = start
        history = [set() for _ in range(m)]
        for u,i in zip(source[:begin],item[:begin]):
            history[u].add(i)
        rng = np.random.default_rng(661+repeat)
        print(json.dumps(dict(dataset=folder.name, repeat=repeat, users=users,
                              eligible=len(eligible), dataset_users=int(m), items=int(n),
                              events=len(events), start=start, stop=stop,
                              checkpoint_step=state["step"], semantic_ms=sem_ms, init_ms=init_ms,
                              cached_dense_mib=sum(old[i].nbytes for i in (0,2,3,5))/2**20)),flush=True)
        for size in sizes:
            end = begin+size
            a, b = source[:end], destination[:end]
            def prepare():
                for u,i in zip(source[begin:end],item[begin:end]):
                    history[u].add(i)
                return np.bincount(item[:end],minlength=n)>0

            catalog, setup_ms = timed(prepare)
            def select(method):
                w0,s0,h1,w1,s1,h2 = old
                raw0 = np.r_[w0,gates(x,a[begin:],b[begin:])]
                op0 = normalized(a,b,raw0,m+n)
                change = (op0-s0)@x if method=="DAERM" else None
                new_h1 = h1+change if method=="DAERM" else op0@x
                if method=="first_gate":
                    reevaluated = end
                    raw1 = gates(new_h1,a,b)
                else:
                    changed = np.any(new_h1!=h1,axis=1)
                    dirty = np.flatnonzero(changed[a]|changed[b]|(np.arange(end)>=begin))
                    reevaluated = len(dirty)
                    raw1 = np.r_[w1,np.zeros(size)]
                    raw1[dirty] = gates(new_h1,a[dirty],b[dirty])
                op1 = normalized(a,b,raw1,m+n)
                new_h2 = h2+(op1-s1)@h1+op1@change if method=="DAERM" else op1@new_h1
                return (raw0,op0,new_h1,raw1,op1,new_h2), reevaluated

            def ranking(prediction):
                combined = (x+prediction[2]+prediction[5])/3
                collab = combined[m:]
                gate = expit(np.hstack((collab,sem))@weight.T+bias)
                products = torch.from_numpy((gate*collab+(1-gate)*sem).astype(np.float32)).T
                out = []
                for block in np.array_split(query,20):
                    score = torch.from_numpy(combined[block].astype(np.float32)) @ products
                    score[:,~catalog] = -torch.inf
                    for j,u in enumerate(block):
                        score[j,list(history[u])] = -torch.inf
                    out.append(torch.topk(score,20,dim=1).indices.numpy())
                return np.vstack(out)

            results = {}
            for name in rng.permutation(("full","first_gate","dependency_gate","DAERM")):
                call = (lambda:(full(end),end)) if name=="full" else (lambda:select(name))
                (new, reevaluated), graph_ms = timed(call)
                order, rank_ms = timed(lambda:ranking(new))
                results[name] = (new,order,dict(first_gates=int(end if name=="full" else size),
                                               second_gates=int(reevaluated),graph_ms=graph_ms,
                                               rank_ms=rank_ms,setup_ms=setup_ms,
                                               total_ms=graph_ms+rank_ms+setup_ms))
            base, top, _ = results["full"]
            for value, order, metrics in results.values():
                err = max(float(np.max(np.abs(value[i]-base[i]))) for i in (0,2,3,5))
                assert err<1e-10
                metrics.update(error=err, top20=int(np.all(order==top,axis=1).sum()),
                               quality=[*quality(order[:,:10],targets),*quality(order,targets)])
            print(json.dumps(dict(batch=size,repeat=repeat,users=users,edges=end,
                                  process_peak_mib=peak_mib(),
                                  routes={k:v[-1] for k,v in results.items()})),flush=True)
            old, begin = results["DAERM"][0], end


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("folder", type=Path)
    parser.add_argument("checkpoint", type=Path)
    parser.add_argument("--users", type=int, default=2500, help="0 uses all eligible users")
    args = parser.parse_args()
    run(args.folder, args.checkpoint, args.users)
