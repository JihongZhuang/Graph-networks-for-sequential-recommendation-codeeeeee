"""Indexed normalization and compact, two-layer propagation for TimeMM."""
import numpy as np
from scipy.sparse import csr_matrix


def normalize_inplace(graph, state, start, end):
    anchor, raw, du, di, normalized = state
    new = np.arange(start, end)
    users = np.unique(graph.u[new])
    np.maximum.at(anchor, graph.u[new], graph.t[new])
    edges = graph.gather(users, graph.by_u)
    weights = graph.raw_weights(edges, anchor)
    difference = weights - raw[edges]
    np.add.at(du, graph.u[edges], difference)
    np.add.at(di, graph.i[edges], difference)
    raw[edges] = weights
    items = np.unique(graph.i[edges[difference != 0]])
    candidates = np.union1d(edges, graph.gather(items, graph.by_i))
    values = raw[candidates] / np.sqrt(du[graph.u[candidates]] * di[graph.i[candidates]])
    delta = values - normalized[candidates]
    normalized[candidates] = values
    changed = delta != 0
    return candidates[changed], delta[changed], len(edges), len(candidates)


def propagate_inplace(graph, layers, x, weights, ids, delta, frontier):
    first, second = layers
    u, i = graph.u[ids], graph.i[ids] + graph.m
    rows, inverse = np.unique(np.r_[u, i], return_inverse=True)
    opposite = np.r_[inverse[len(ids):], inverse[:len(ids)]]
    shape = (len(rows), len(rows))
    change = csr_matrix((np.tile(delta, 2), (inverse, opposite)), shape=shape)
    first_delta = change @ x[rows]
    second[rows] += change @ first[rows]

    u, i = graph.u[frontier], graph.i[frontier] + graph.m
    dst, src = np.r_[u, i], np.r_[i, u]
    source = np.searchsorted(rows, src)
    match = rows[np.minimum(source, len(rows) - 1)] == src
    affected, target = np.unique(dst[match], return_inverse=True)
    edge_values = np.tile(weights[frontier], 2)[match]
    spread = csr_matrix((edge_values, (target, source[match])),
                        shape=(len(affected), len(rows)))
    second[affected] += spread @ first_delta
    first[rows] += first_delta
    return len(rows), len(np.union1d(rows, affected))
