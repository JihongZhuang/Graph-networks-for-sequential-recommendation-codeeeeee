"""Prepare the statistics-matched CASG replay from FreeRec Yelp2018 version 1."""
import argparse
import csv
from pathlib import Path
from zipfile import ZipFile

import pandas as pd


def reconstruct(archive, destination):
    with ZipFile(archive) as data:
        with data.open('Yelp2018.inter') as stream:
            raw = pd.read_csv(stream, sep='\t', usecols=['USER', 'ITEM', 'RATING', 'TIMESTAMP'])
        with data.open('Yelp2018.item') as stream:
            metadata = pd.read_csv(stream, sep='\t', quoting=csv.QUOTE_NONE, keep_default_na=False,
                                   usecols=['ITEM', 'ITEM_NAME', 'CATEGORIES', 'CITY', 'STATE'])
    rated = raw.loc[raw['RATING'] >= 4, ['USER', 'ITEM', 'TIMESTAMP']]
    keep = rated
    while True:
        users = keep['USER'].value_counts()
        items = keep['ITEM'].value_counts()
        subset = keep[keep['USER'].map(users).ge(10) & keep['ITEM'].map(items).ge(10)]
        if len(subset) == len(keep):
            break
        keep = subset

    user_ids = pd.Index(rated['USER'].unique())
    item_ids = pd.Index(rated['ITEM'].unique())
    user_ids = user_ids[user_ids.isin(keep['USER'].unique())]
    item_ids = item_ids[item_ids.isin(keep['ITEM'].unique())]
    u = user_ids.get_indexer(keep['USER'])
    i = item_ids.get_indexer(keep['ITEM'])
    assert (len(user_ids), len(item_ids), len(keep)) == (41801, 26512, 1022604)
    events = pd.DataFrame(dict(user=u, item=i, time=keep['TIMESTAMP'].to_numpy()))
    events = events.sort_values(['user', 'time'], kind='stable')
    item_map = pd.DataFrame(dict(item=range(len(item_ids)), business_id=item_ids))
    indexed = metadata.set_index('ITEM').loc[item_ids]
    item_text = indexed[['ITEM_NAME', 'CATEGORIES', 'CITY', 'STATE']].agg(' '.join, axis=1)
    text = pd.DataFrame(dict(ITEM=range(len(item_ids)), TEXT=item_text.to_numpy()))
    destination.mkdir(parents=True)
    for name, table in [('events', events), ('item_ids', item_map), ('item_text', text)]:
        table.to_csv(destination / f'{name}.tsv', sep='\t', index=False)


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive', type=Path)
    parser.add_argument('destination', type=Path, help='new output directory')
    args = parser.parse_args()
    reconstruct(args.archive, args.destination)
