"""Generate the third revision's tables, figures and timing audit."""

import argparse
import csv
from itertools import accumulate
import json
from pathlib import Path
import re
from statistics import mean, median

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
ROUTES = {
    "full_rebuild": ("Full rebuild", "#344455", ":"),
    "affected_rows": ("Affected rows", "#a44828", "--"),
    "view": ("Bounded view", "#006c6c", "-"),
    "CINM": ("CINM", "#315b9a", "-."),
}
EPOCH = re.compile(r"^SASRec epoch=(\d+),loss=([\d.]+),valid_ndcg5=([\d.]+),seconds=([\d.]+)$")


def records(path):
    return [json.loads(line) for line in path.read_text(encoding="utf-8-sig").splitlines() if line.startswith("{")]


def describe(values):
    return dict(mean=mean(values), median=median(values), low=min(values), high=max(values))


def write_json(path, value):
    path.write_text(json.dumps(value, indent=2) + "\n", encoding="utf-8")


def write_csv(path, rows):
    with path.open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tex_rows(name, rows):
    body = [" & ".join(map(str, row)) + r" \\" for row in rows]
    (ROOT / "latex" / f"{name}.tex").write_text("\n".join([*body, r"\bottomrule"]) + "\n", encoding="utf-8")


def summarize_long():
    folder = EVIDENCE / "long"
    schedule = json.loads((folder / "route_orders.json").read_text(encoding="utf-8-sig"))
    assert len(schedule) == 3
    timing_rows = []
    summaries = {route: [] for route in ROUTES}
    for repeat, order in enumerate(schedule, 1):
        assert len(order) == 4 and set(order) == set(ROUTES)
        for place, route in enumerate(order, 1):
            meta, *windows, audit = records(folder / f"r{repeat}_{route}.jsonl")
            assert meta["route"] == audit["route"] == route and audit["final_graph_error"] < 1e-14
            assert len(windows) == meta["windows"] == 24 and meta["batch"] == 1000
            assert meta["start"] == 915002 and meta["stop"] == 939002
            assert all(w["window"] == j and w["end"] == meta["start"] + 1000*j
                       for j, w in enumerate(windows, 1))
            init = meta["initialization_ms"] / 1000
            times = [w["graph_ms"] / 1000 for w in windows]
            cumulative = list(accumulate(times, initial=init))
            for j, (update, total) in enumerate(zip([0., *times], cumulative, strict=True)):
                timing_rows.append(dict(repeat=repeat, order_position=place, route=route, batch=j,
                                        events=1000*j, setup_s=init, update_s=update, cumulative_s=total))
            summaries[route].append(dict(init_s=init, updates_s=sum(times), total_s=cumulative[-1],
                                         cumulative_s=cumulative, batch_s=times,
                                         peak_mib=audit["peak_before_audit_mib"]))

    comparison = []
    for rows, view in zip(summaries["affected_rows"], summaries["view"], strict=True):
        delta = [a-b for a, b in zip(view["cumulative_s"], rows["cumulative_s"], strict=True)]
        first = next((i for i in range(25) if delta[i] < 0), None)
        persistent = next((i for i in range(25) if max(delta[i:]) < 0), None)
        comparison.append(dict(initialization_delta_s=delta[0], first_crossing=first,
                               persistent_crossing=persistent, total_savings_s=-delta[-1],
                               cumulative_view_minus_affected_s=delta))
    write_csv(EVIDENCE / "long_cumulative.csv", timing_rows)
    return dict(schedule=schedule, repeats=summaries, comparison=comparison)


def summarize_structure():
    meta, *windows, end = records(EVIDENCE / "long_structure.jsonl")
    assert len(windows) == meta["windows"] == end["windows"] == 24 and end["compared_states"] == 72
    assert meta["start"] == 915002 and meta["stop"] == 939002
    routes = {}
    for route in meta["routes"]:
        checks = [window["checks"][route] for window in windows]
        assert all(all(v for k, v in check.items() if k.endswith("_exact")) for check in checks)
        error = max(check["normalized_max_abs_error"] for check in checks)
        assert error < 1e-14
        routes[route] = dict(exact_windows=len(checks), max_error=error)
    return routes


def summarize_training(prior):
    path = EVIDENCE / "luxury_training.jsonl"
    meta, checkpoint, *logged = records(path)
    windows = [r for r in logged if r["kind"] == "quality_window"]
    old, = records(EVIDENCE / "luxury_old_checkpoint_reference.jsonl")
    old_prior, = records(prior / "quality_luxury.jsonl")
    assert {k: v for k,v in old.items() if k != "ranking_ms"} == {
        k: v for k,v in old_prior.items() if k != "ranking_ms"
    }
    epochs = [
        dict(epoch=int(match[1]), loss=float(match[2]), validation_ndcg5=float(match[3]), seconds=float(match[4]))
        for line in path.read_text(encoding="utf-8-sig").splitlines()
        if (match := EPOCH.match(line))
    ]
    assert len(epochs) == meta["epochs"] and [r["epoch"] for r in epochs] == list(range(1, len(epochs)+1))
    assert len(windows) == 6 and all(w["kind"] == "quality_window" for w in windows)
    assert all(w["users"] == old["users"] == 7976 for w in windows)
    assert all(w["batch"] == q for w, q in zip(windows, meta["batches"], strict=True))
    assert all(check["features_bitwise_equal"] and check["top20_matches"] == w["users"]
               and check["operator_max_abs_error"] < 1e-14 for w in windows for check in w["checks"].values())
    key = lambda r: r["validation_ndcg5"]
    write_csv(EVIDENCE / "luxury_validation_curve.csv", epochs)
    return dict(meta=meta, checkpoint=checkpoint, epochs=epochs, best=max(epochs, key=key),
                best_first_eight=max(epochs[:8], key=key), last_eight=describe([key(x) for x in epochs[-8:]]),
                windows=windows, old_final=old)


def short_tables(prior):
    audited = json.loads((prior / "round2_audit.json").read_text(encoding="utf-8"))
    output = {}
    for dataset, summary in audited["main"].items():
        raw = records(prior / "round1" / f"{dataset}.jsonl")
        windows = [w for w in raw if w["kind"] == "window"]
        setup = [r for r in raw if r["kind"] == "initialization"]
        assert len(windows) == 18 and len(setup) == 15
        output[dataset] = {}
        for route, previous in summary["routes"].items():
            rows = [w["routes"][route] for w in windows]
            stages = {k: sum(r[k] for r in rows) / 1000 for k in previous["stages_s"]}
            init = sum(r["prefix_ms"] + r["index_ms"] for r in setup if r["route"] == route) / 1000
            residual = stages["graph_ms"] - sum(stages[k] for k in ("count_ms", "selection_ms", "state_ms", "normalization_ms"))
            aggregate = sum(stages[k] for k in ("graph_ms", "history_ms", "filter_ms", "score_rank_ms"))
            shared = init + stages["graph_ms"] + stages["history_ms"] + sum(
                w["routes"]["full_rebuild"][k] for w in windows for k in ("filter_ms", "score_rank_ms")
            ) / 1000
            checks = dict(
                steady_s=stages["total_ms"], cold_s=aggregate+init, setup_s=init,
                common_downstream_s=shared, residual_graph_s=residual, stages_s=stages,
                prefix_s=mean(r["prefix_ms"] for r in setup if r["route"] == route) / 1000,
                index_s=mean(r["index_ms"] for r in setup if r["route"] == route) / 1000,
                single_setup_s=stages["total_ms"] + init / 3,
            )
            assert abs(aggregate-stages["total_ms"]) < 1e-8
            assert abs(checks["cold_s"]-previous["total_cold_s"]) < 1e-8
            assert abs(shared-previous["common_downstream_s"]) < 1e-8
            assert abs(residual-previous["graph_residual_s"]) < 1e-8
            assert all(abs(v-previous["stages_s"][k]) < 1e-8 for k,v in stages.items())
            checks["component_vs_affected_s"] = shared-summary["routes"]["affected_rows"]["common_downstream_s"]
            checks["observed_vs_affected_s"] = checks["cold_s"]-summary["routes"]["affected_rows"]["total_cold_s"]
            output[dataset][route] = checks
    return output, audited["diagnostics"]["cutoff"]


def check_tex_short_tables(short):
    result_file = ROOT / "latex" / "revision_results.tex"
    timing_file = ROOT / "latex" / "revision_timing_appendix.tex"

    def cells(path, label):
        content = path.read_text(encoding="utf-8")
        body = content.split(r"\label{" + label + "}", 1)[1].split(r"\end{tabular}", 1)[0]
        body = body.split(r"\midrule", 1)[1]
        include = re.search(r"\\input\{(.*?)\}", body)
        if include:
            body = (path.parent / f"{include[1]}.tex").read_text(encoding="utf-8")
        return [tuple(s.strip() for s in line.strip().removesuffix(r"\\").split("&"))
                for line in body.splitlines() if " & " in line]

    steady = cells(result_file, "tab:revision-steady")
    cold = cells(result_file, "tab:revision-cold")
    contrast = cells(result_file, "tab:round2-graph")
    phases = cells(timing_file, "tab:revision-phases")
    residual = cells(timing_file, "tab:round2-residual")
    phase_fields = ("count_ms", "selection_ms", "state_ms", "normalization_ms",
                    "history_ms", "filter_ms", "score_rank_ms")
    for dataset_index, routes in enumerate(short.values()):
        assert steady[dataset_index][2:] == tuple(f'{m["steady_s"]:.1f}' for m in routes.values())
        assert residual[dataset_index][1:] == tuple(f'{m["residual_graph_s"]:.3f}' for m in routes.values())
        for route_index, values in enumerate(routes.values()):
            row = 5 * dataset_index + route_index
            assert cold[row][2:] == tuple(
                f'{values[k]:.2f}' for k in ("prefix_s", "index_s")
            ) + tuple(f'{values[k]:.1f}' for k in ("single_setup_s", "cold_s", "common_downstream_s"))
            assert phases[row][2:] == tuple(f'{values["stages_s"][k]:.2f}' for k in phase_fields)
        affected = routes["affected_rows"]
        graph = lambda v: v["stages_s"]["graph_ms"] + v["stages_s"]["history_ms"]
        for j, route in enumerate(("ordered", "view", "CINM")):
            values = routes[route]
            expected = (graph(values)-graph(affected), values["setup_s"]-affected["setup_s"],
                        values["component_vs_affected_s"], values["observed_vs_affected_s"])
            assert contrast[3*dataset_index+j][2:] == tuple(f"{v:+.2f}" for v in expected)
    return {"table_1": len(steady), "table_2": len(cold), "table_4": len(contrast),
            "table_13": len(phases), "table_14": len(residual)}


def export_tables(result):
    long = result["long"]
    training = result["training"]
    rows = []
    for name, reps in long["repeats"].items():
        totals = describe([r["total_s"] for r in reps])
        peaks = describe([r["peak_mib"] for r in reps])
        rows.append((ROUTES[name][0], f'{mean(r["init_s"] for r in reps):.2f}',
                     f'{mean(r["updates_s"] for r in reps):.2f}',
                     f'{totals["mean"]:.2f} [{totals["low"]:.2f}, {totals["high"]:.2f}]',
                     f'{peaks["low"]:.1f}--{peaks["high"]:.1f}'))
    tex_rows("round3_long_rows", rows)
    quality_cols = ("recall_at_10", "ndcg_at_10", "recall_at_20", "ndcg_at_20")
    tex_rows("round3_luxury_rows", [
        (name, *(f"{q[k]:.4f}" for k in quality_cols)) for name, q in (
            ("Original local fit", training["old_final"]), ("48-epoch fit", training["windows"][-1]),
        )
    ])
    keys = ("selection_ms", "retained_edges_ms", "degree_incidence_ms", "weight_values_ms", "patch_build_ms", "csr_merge_ms")
    tex_rows("round3_cutoff_medians", [
        (k, *(f'{stats[key]["median"]:.1f}' for key in keys)) for k, stats in result["cutoff"].items()
    ])

    view = long["repeats"]["view"]
    affected = long["repeats"]["affected_rows"]
    paired = long["comparison"]
    savings = describe([p["total_savings_s"] for p in paired])
    def crossing(name):
        values = [str(p[name]) if p[name] is not None else "none" for p in paired]
        return f"{values[0]}, {values[1]} and {values[2]}"
    post = [check for w in training["windows"] for check in w["checks"].values()]
    def fmt_error(error):
        if error == 0:
            return "0"
        significand, exponent = f"{error:.2e}".split("e")
        return rf"{significand}\times 10^{{{int(exponent)}}}"
    macros = dict(
        LongViewMean=f'{mean(r["total_s"] for r in view):.2f}',
        LongAffectedMean=f'{mean(r["total_s"] for r in affected):.2f}',
        LongSavingMean=f'{savings["mean"]:.2f}',
        LongSavingRange=f'{savings["low"]:.2f} to {savings["high"]:.2f}',
        LongInitDelta=f'{mean(p["initialization_delta_s"] for p in paired):+.2f}',
        LongFirstCross=crossing("first_crossing"),
        LongLastCross=crossing("persistent_crossing"),
        LongMaxError=fmt_error(max(x["max_error"] for x in result["structure"].values())),
        LuxuryMaxError=fmt_error(max(x["operator_max_abs_error"] for x in post)),
        LuxuryBestEarly=f'{training["best_first_eight"]["validation_ndcg5"]:.4f}',
        LuxuryBest=f'{training["best"]["validation_ndcg5"]:.4f}',
        LuxuryBestEpoch=training["best"]["epoch"],
        LuxuryLastEight=f'{training["last_eight"]["low"]:.4f}--{training["last_eight"]["high"]:.4f}',
        LuxuryLossInitial=f'{training["epochs"][0]["loss"]:.3f}',
        LuxuryLossFinal=f'{training["epochs"][-1]["loss"]:.3f}',
    )
    lines = [rf"\newcommand{{\{k}}}{{{v}}}" for k, v in macros.items()]
    (ROOT / "latex" / "round3_values.tex").write_text("\n".join(lines)+"\n", encoding="utf-8")


def figures(result):
    plt.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "DejaVu Sans"],
                         "font.size": 8, "axes.spines.top": False, "axes.spines.right": False,
                         "pdf.fonttype": 42, "svg.fonttype": "none"})
    folder = ROOT / "latex" / "figures"
    def save(fig, name):
        for extension in ("pdf", "svg"):
            fig.savefig(folder / f"{name}.{extension}")
        plt.close(fig)

    repeats = result["long"]["repeats"]
    fig, axes = plt.subplots(1, 2, figsize=(7, 2.9), layout="constrained")
    for panel, ax in enumerate(axes):
        for route, (label, color, line) in ROUTES.items():
            if panel == 1 and route == "full_rebuild":
                continue
            points = list(zip(*(r["cumulative_s"] for r in repeats[route]), strict=True))
            ax.fill_between(range(25), [min(p) for p in points], [max(p) for p in points], color=color, alpha=.16)
            ax.plot(range(25), [mean(p) for p in points], label=label, color=color, ls=line, lw=1.5)
        ax.set_title(("a   All routes", "b   Maintained routes")[panel], loc="left", fontweight="bold")
        ax.set(xlim=(0, 24), xticks=range(0, 25, 4), xlabel="Completed 1,000-event batches",
               ylabel="Cumulative graph cost (s)")
        ax.grid(axis="y", lw=.4, alpha=.4)
        ax.legend(frameon=False, loc="upper left", fontsize=7.5)
    save(fig, "casg_long_amortization")

    training = result["training"]
    epochs = training["epochs"]
    fig, ax = plt.subplots(figsize=(6.4, 2.5), layout="constrained")
    ax.plot([x["epoch"] for x in epochs], [x["validation_ndcg5"] for x in epochs],
            color="#315b9a", lw=1.45, label="Validation trajectory")
    ax.axvline(8, color="#999999", ls="--", lw=.9, label="Original epoch budget")
    best = training["best"]
    ax.scatter(best["epoch"], best["validation_ndcg5"], color="#006c6c", s=27, label="Selected checkpoint", zorder=5)
    ax.set(xlabel="SASRec epoch", ylabel="Validation NDCG@5", xlim=(1, len(epochs)))
    ax.grid(axis="y", lw=.4, alpha=.4)
    ax.legend(frameon=False, fontsize=7.5)
    save(fig, "casg_luxury_validation")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--prior", type=Path, default=ROOT.parent / "evidence")
    parser.add_argument("--tables-only", action="store_true")
    args = parser.parse_args()
    short, cutoff = short_tables(args.prior)
    verified_tex_rows = check_tex_short_tables(short)
    result = dict(short_table_audit=short, verified_tex_rows=verified_tex_rows, cutoff=cutoff, long=summarize_long(),
                  structure=summarize_structure(), training=summarize_training(args.prior))
    write_json(EVIDENCE / "round3_audit.json", result)
    export_tables(result)
    if not args.tables_only:
        figures(result)
