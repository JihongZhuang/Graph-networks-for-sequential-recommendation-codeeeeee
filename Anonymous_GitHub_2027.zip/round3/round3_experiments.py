"""Supplementary CASG structure and frozen-predictor checks."""

import argparse
from collections import Counter, defaultdict
import ctypes
import hashlib
from math import comb
from pathlib import Path
import pickle
import platform

import numpy as np
from numpy.polynomial import Polynomial
import pandas as pd
from threadpoolctl import threadpool_limits
import torch

from casg_cinm import load_replay
from casg_major_revision import INDEXES, emit, maintain, rebuild
from casg_revision_sensitivity import ranked_state
from exact_polynomial import full_layers, polynomial
from integration_casg import append_merged, rank_checked
from saeif_casg_pilot import append, full_graph, matrix
from saeif_casg_sasrec import train as fit_sasrec


def load_inputs(dataset):
    folder = Path("work/saeif/casg") / dataset
    replay = load_replay(folder, Path("outputs") / f"saceif_general_casg_{dataset}.txt")
    return folder, replay


def exact_long_graph():
    _, (events, _, _, _, _, n) = load_inputs("Yelp2018_matched")
    batch, windows = 1000, 24
    start = len(events) - batch * windows
    counts, histories = Counter(), defaultdict(list)
    append(events[:start], counts, histories)
    routes = ("affected_rows", "view", "CINM")
    states = {name: INDEXES[name](counts, n) for name in routes}
    emit(kind="metadata", dataset="Yelp2018_matched", routes=routes, start=start,
         stop=len(events), windows=windows, batch=batch, scope="separate untimed state audit")

    for j in range(1, windows + 1):
        begin, end = start + (j - 1) * batch, start + j * batch
        changed = append_merged(events[begin:end], counts, histories)
        full_counts, full_histories = Counter(), defaultdict(list)
        append(events[:end], full_counts, full_histories)
        assert counts == full_counts and histories == full_histories, j
        fresh = ranked_state(full_counts, 20)
        links, degrees = defaultdict(set), np.zeros(n, dtype=np.int64)
        for (i, k), weight in fresh.weights.items():
            links[i].add(k)
            links[k].add(i)
            degrees[i] += weight
            degrees[k] += weight
        reference = matrix(fresh.weights, n).sorted_indices()
        checks = {}
        for name, state in states.items():
            op, _ = maintain(state, counts, changed)
            op = op.sorted_indices()
            checks[name] = dict(
                counts_exact=True, histories_exact=True,
                winners_exact={i: row for i, row in state.winners.items() if row} == fresh.chosen,
                retained_weights_exact=state.weights == fresh.weights,
                incidence_exact={i: row for i, row in state.links.items() if row} == links,
                degrees_exact=np.array_equal(state.degree, degrees),
                normalized_support_exact=np.array_equal(op.indptr, reference.indptr)
                and np.array_equal(op.indices, reference.indices),
                normalized_max_abs_error=float(np.max(np.abs((op - reference).data), initial=0)),
            )
            assert all(v for k, v in checks[name].items() if k.endswith("_exact")), (j, name, checks[name])
            assert checks[name]["normalized_max_abs_error"] < 1e-14, (j, name, checks[name])
        emit(kind="window", window=j, end=end, reference_edges=len(fresh.weights), checks=checks)
    emit(kind="complete", windows=windows, compared_states=windows * len(routes))


def quality_metrics(top, targets):
    hits = top == targets[:, None]
    discounts = 1 / np.log2(np.arange(2, 22))
    return {
        f"{metric}_at_{k}": float((hits[:, :k] * weights).sum(axis=1).mean())
        for k in (10, 20)
        for metric, weights in (("recall", 1), ("ndcg", discounts[:k]))
    }


def luxury_retrain(checkpoint_dir, epochs):
    folder, (events, test, sizes, weights, _, n) = load_inputs("Luxury_Beauty")
    prefix = len(events) - sum(sizes)
    raw = pd.read_csv(folder / "events.tsv", sep="\t")
    groups = raw.groupby("user", sort=False)
    validation = raw[groups.cumcount() == groups.user.transform("size") - 2].set_index("user").item.to_dict()
    with (folder / "bert_cls.pkl").open("rb") as source:
        features = np.asarray(pickle.load(source), dtype=np.float64)
    features -= features.mean(axis=0)
    p, q = Polynomial([.5, .5]), Polynomial([.5, -.5])
    depth = len(weights) - 1
    coeff = sum(w * comb(depth, k) * p**k * q**(depth-k) for k, w in enumerate(weights)).coef

    def filtered(op):
        z = polynomial(full_layers(op, features, depth), coeff)
        isolated = np.diff(op.indptr) == 0
        z[isolated] = features[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(z).float())

    counts, histories = Counter(), defaultdict(list)
    append(events[:prefix], counts, histories)
    query = np.asarray(sorted(u for u, h in histories.items() if h and test.loc[u] not in h))
    targets = test.loc[query].to_numpy()
    z0 = filtered(full_graph(events[:prefix], n))
    checkpoint_dir.mkdir(parents=True, exist_ok=False)
    emit(kind="training_config", dataset="Luxury_Beauty", epochs=epochs, users=len(query),
         items=n, prefix=prefix, stop=len(events), batches=sizes, seed=30, threads=4,
         validation_rule="highest full-catalogue NDCG@5, fixed up to 2500 users",
         predictor="fresh SASRec fit; frozen prefix Bernstein coefficients and BERT vectors")
    model = fit_sasrec(z0, histories, validation, checkpoint_dir, epochs=epochs)
    checkpoint = checkpoint_dir / "sasrec_validation_selected.pt"
    emit(kind="checkpoint", sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
         bytes=checkpoint.stat().st_size)

    states = {name: INDEXES[name](counts, n) for name in ("view", "CINM")}
    begin = prefix
    for j, size in enumerate(sizes, 1):
        end = begin + size
        changed = append_merged(events[begin:end], counts, histories)
        reference, _ = rebuild(events[:end], n)
        ref_z = filtered(reference)
        top, _, _, reference_ms = rank_checked(model, ref_z, histories, query, test)
        checks = {}
        for route, state in states.items():
            op, _ = maintain(state, counts, changed)
            error = float(np.max(np.abs((op-reference).data), initial=0))
            z = filtered(op)
            ranks, _, _, score_ms = rank_checked(model, z, histories, query, test)
            checks[route] = dict(operator_max_abs_error=error,
                                 features_bitwise_equal=torch.equal(z, ref_z),
                                 feature_max_abs_error=float(torch.max(torch.abs(z-ref_z))),
                                 top20_matches=int(np.all(ranks == top, axis=1).sum()),
                                 score_rank_ms=score_ms)
            assert error < 1e-14 and checks[route]["features_bitwise_equal"] and checks[route]["top20_matches"] == len(query)
        emit(kind="quality_window", window=j, end=end, users=len(query), batch=size,
             reference_score_rank_ms=reference_ms, checks=checks,
             top20_sha256=hashlib.sha256(top.astype("<i8").tobytes()).hexdigest(),
             **quality_metrics(top, targets))
        begin = end


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("experiment", choices=("structure", "luxury"))
    parser.add_argument("--checkpoint-dir", type=Path)
    parser.add_argument("--epochs", type=int, default=48)
    args = parser.parse_args()
    if args.experiment == "luxury" and args.checkpoint_dir is None:
        parser.error("--checkpoint-dir is required for luxury")
    torch.set_num_threads(4)
    torch.manual_seed(30)
    if platform.system() == "Windows":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    with threadpool_limits(limits=4):
        if args.experiment == "structure":
            exact_long_graph()
        else:
            luxury_retrain(args.checkpoint_dir, args.epochs)
