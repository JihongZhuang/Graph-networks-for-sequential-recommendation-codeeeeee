"""Matched graph-refresh experiment and leave-one-out timestamp audit."""

import argparse
from collections import defaultdict
import ctypes
import hashlib
from math import comb
from pathlib import Path
import pickle
import platform

import numpy as np
from numpy.polynomial import Polynomial
import pandas as pd
from threadpoolctl import threadpool_limits
import torch

from casg_cinm import load_replay
from casg_major_revision import DATASETS, add_history, emit, rebuild
from exact_polynomial import full_layers, polynomial
from integration_casg import rank_checked
from saeif_casg_pilot import timed
from saeif_casg_sasrec import SampledProjection, author_model


def score_metrics(top, targets):
    hit = top[:, :10] == targets[:, None]
    return dict(hits_at_10=int(hit.sum()),
                discounted_hits_at_10=float((hit / np.log2(np.arange(2, 12))).sum()))


def timestamp_counts(targets, cutoff):
    return dict(earlier=int(np.count_nonzero(targets < cutoff)),
                equal=int(np.count_nonzero(targets == cutoff)))


def run(dataset):
    folder = Path("work/saeif/casg") / dataset
    log = Path("outputs") / f"saceif_general_casg_{dataset}.txt"
    train, test, sizes, weights, _, n = load_replay(folder, log)
    prefix = len(train) - sum(sizes)
    raw = pd.read_csv(folder / "events.tsv", sep="\t")
    users = raw.groupby("user", sort=False)
    target_rows = raw[users.cumcount() == users.user.transform("size") - 1].set_index("user")
    assert target_rows.item.equals(test)
    assert np.all(train[:-1, 2] <= train[1:, 2])

    histories = defaultdict(list)
    add_history(train[:prefix], histories)
    query = np.array(sorted(u for u, h in histories.items() if h and test.loc[u] not in h))
    assert len(query) >= 5000
    targets = test.loc[query].to_numpy()
    all_target_times = target_rows.time.to_numpy()
    cohort_times = target_rows.loc[query].time.to_numpy()
    assert np.isfinite(train[:, 2]).all() and np.isfinite(all_target_times).all()
    with (folder / "bert_cls.pkl").open("rb") as f:
        x = np.asarray(pickle.load(f), dtype=np.float64)
    x -= x.mean(axis=0)
    depth = len(weights) - 1
    p, q = Polynomial([.5, .5]), Polynomial([.5, -.5])
    coeff = sum(w * comb(depth, k) * p**k * q**(depth-k) for k, w in enumerate(weights)).coef

    def filtered(op):
        features = polynomial(full_layers(op, x, depth), coeff)
        isolated = np.diff(op.indptr) == 0
        features[isolated] = x[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(features).float())

    model = author_model(torch.from_numpy(x).float())
    model.in_proj = SampledProjection(model.in_proj, n)
    checkpoint = folder / "sasrec_validation_selected.pt"
    model.load_state_dict(torch.load(checkpoint, weights_only=True))
    model.eval()

    old, _ = rebuild(train[:prefix], n)
    z_old = filtered(old)
    emit(kind="metadata", dataset=dataset, users=len(query), heldout_users=len(test), items=n,
         start=prefix, stop=len(train), batches=sizes, model_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
         cohort_sha256=hashlib.sha256(query.astype("<i8").tobytes()).hexdigest(),
         train_time_min=int(train[0, 2]), prefix_time_max=int(train[prefix-1, 2]),
         target_time_min=int(all_target_times.min()), target_time_max=int(all_target_times.max()),
         prefix_query_timestamp_counts=timestamp_counts(cohort_times, train[prefix-1, 2]),
         scope="all eligible users, same newest training histories and complete catalogue for both arms")
    begin = prefix
    for j, size in enumerate(sizes, 1):
        end = begin + size
        add_history(train[begin:end], histories)
        (new, _), rebuild_ms = timed(lambda: rebuild(train[:end], n))
        z_new, filter_ms = timed(lambda: filtered(new))
        changed = (new-old).tocsr()
        changed.eliminate_zeros()
        assert changed.nnz % 2 == 0 and (changed - changed.T).nnz == 0
        representations = {"stale": z_old, "fresh": z_new}
        order = ("stale", "fresh") if j % 2 else ("fresh", "stale")
        ranks, metrics = {}, {}
        for key in order:
            top, _, _, score_ms = rank_checked(model, representations[key], histories, query, test)
            ranks[key] = top
            metrics[key] = dict(**score_metrics(top, targets), score_ms=score_ms,
                                top20_sha256=hashlib.sha256(top.astype("<i8").tobytes()).hexdigest())
        differing = np.any(ranks["stale"] != ranks["fresh"], axis=1)
        differing_set = np.any(np.sort(ranks["stale"], axis=1) != np.sort(ranks["fresh"], axis=1), axis=1)
        emit(kind="window", dataset=dataset, window=j, batch=size, users=len(query), start=begin, stop=end,
             normalized_entries_changed=changed.nnz, normalized_pairs_changed=changed.nnz//2,
             normalized_max_abs_delta=float(np.max(np.abs(changed.data), initial=0)),
             changed_ordered_lists=int(differing.sum()), changed_item_sets=int(differing_set.sum()),
             old_training_time_max=int(train[begin-1, 2]), new_training_time_max=int(train[end-1, 2]),
             new_batch_time_min=int(train[begin, 2]), all_heldout=timestamp_counts(all_target_times, train[end-1, 2]),
             eligible_heldout=timestamp_counts(cohort_times, train[end-1, 2]),
             stale_eligible_heldout=timestamp_counts(cohort_times, train[begin-1, 2]),
             order=order, rebuild_ms=rebuild_ms, filter_ms=filter_ms, **metrics)
        old, z_old, begin = new, z_new, end
    emit(kind="complete", dataset=dataset, windows=len(sizes), user_window_pairs=len(sizes)*len(query))


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", choices=DATASETS)
    args = parser.parse_args()
    torch.set_num_threads(4)
    torch.manual_seed(30)
    if platform.system() == "Windows":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    with threadpool_limits(limits=4):
        run(args.dataset)
