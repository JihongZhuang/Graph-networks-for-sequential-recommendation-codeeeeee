"""Recalculate fourth-round claims from raw measurements and check inherited tables."""

import argparse
import csv
from hashlib import sha256
from itertools import accumulate
import json
from pathlib import Path
import runpy
from statistics import mean, median


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
DATA = {
    "Luxury_Beauty": ("Luxury Beauty", "luxury"),
    "Musical_Instruments": ("Musical Instruments", "musical"),
    "Yelp2018_matched": ("Yelp2018", "yelp"),
}
PHASES = ("selection_ms", "retained_edges_ms", "degree_incidence_ms", "weight_values_ms",
          "patch_build_ms", "csr_merge_ms")


def records(path):
    return [json.loads(s) for s in path.read_text(encoding="utf-8-sig").splitlines() if s.startswith("{")]


def describe(values):
    return dict(mean=mean(values), median=median(values), low=min(values), high=max(values))


def write_csv(name, rows):
    with (EVIDENCE / name).open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def tex_rows(name, rows):
    lines = [" & ".join(map(str, row)) + r" \\" for row in rows]
    (ROOT / "latex" / f"{name}.tex").write_text("\n".join([*lines, r"\bottomrule"]) + "\n", encoding="utf-8")


def balanced():
    folder = EVIDENCE / "balanced"
    protocol = json.loads((folder / "protocol.json").read_text(encoding="utf-8"))
    assert protocol["frozen_sha256"] == sha256((ROOT / "round2_experiments.py").read_bytes()).hexdigest()
    assert protocol["orders"] == [["affected_rows", "view"], ["view", "affected_rows"]] * 2
    environment = records(folder / "environment.jsonl")
    assert len(environment) == 16
    assert {r["plugged_in"] for r in environment} == {True}
    assert {r["power_scheme"] for r in environment} == {"8c5e7fda-e8bf-4a96-9a85-a6e23a8c635c"}
    row_data, pairs = [], []
    for rep, order in enumerate(protocol["orders"], 1):
        routes = {}
        for position, route in enumerate(order, 1):
            affinity, meta, *windows, end = records(folder / f"r{rep}_{route}.jsonl")
            assert affinity["cores"] == protocol["affinity"] and affinity["kind"] == "affinity"
            assert affinity["priority"] == "32"
            assert len(windows) == 24 and meta["start"] == 915002 and meta["stop"] == 939002 and meta["batch"] == 1000
            assert meta["route"] == end["route"] == route and end["final_graph_error"] < 1e-14
            assert all(w["window"] == j and w["end"] == meta["start"]+1000*j
                       for j,w in enumerate(windows, 1))
            init = meta["initialization_ms"]/1000
            updates = [w["graph_ms"]/1000 for w in windows]
            cumulative = list(accumulate(updates, initial=init))
            for j,(update,total) in enumerate(zip([0.,*updates],cumulative,strict=True)):
                row_data.append(dict(repeat=rep, position=position, route=route, batch=j,
                                     init_s=init, update_s=update, cumulative_s=total))
            routes[route] = dict(init_s=init, update_s=sum(updates), total_s=cumulative[-1],
                                 cumulative_s=cumulative, peak_mib=end["peak_before_audit_mib"],
                                 final_error=end["final_graph_error"])
        a,v = routes["affected_rows"],routes["view"]
        diff = [x-y for x,y in zip(a["cumulative_s"],v["cumulative_s"],strict=True)]
        pairs.append(dict(repeat=rep, order=order, routes=routes,
                          update_saving_s=a["update_s"]-v["update_s"], net_saving_s=diff[-1],
                          first_cheaper=next((j for j,d in enumerate(diff) if d>0),None)))
    write_csv("balanced_cumulative.csv",row_data)
    return dict(protocol=protocol, environment=environment, pairs=pairs)


def refresh_and_dates(prior):
    dataset_rows, timing_rows, pooled, result = [], [], [], {}
    for dataset, (label,short) in DATA.items():
        meta,*windows,end = records(EVIDENCE / "refresh" / f"{dataset}.jsonl")
        prior_quality, = records(prior / f"quality_{short}.jsonl")
        assert meta["dataset"] == dataset and meta["users"] == prior_quality["users"]
        assert meta["cohort_sha256"] == prior_quality["user_sha256"]
        assert len(windows) == end["windows"] == 6 and end["user_window_pairs"] == 6*meta["users"]
        assert windows[-1]["fresh"]["top20_sha256"] == prior_quality["top20_sha256"]
        for j,w in enumerate(windows,1):
            n = w["users"]
            assert w["window"] == j and w["batch"] == meta["batches"][j-1] and w["stop"]-w["start"] == w["batch"]
            assert n == meta["users"] and 0 <= w["changed_item_sets"] <= w["changed_ordered_lists"] <= n
            assert w["normalized_entries_changed"] == 2*w["normalized_pairs_changed"]
            assert w["old_training_time_max"] <= w["new_batch_time_min"] <= w["new_training_time_max"]
            for field,limit in (("all_heldout",meta["heldout_users"]),("eligible_heldout",n),("stale_eligible_heldout",n)):
                assert 0 <= w[field]["earlier"] + w[field]["equal"] <= limit
            stale,fresh = w["stale"],w["fresh"]
            dataset_rows.append(dict(
                dataset=dataset,window=j,batch=w["batch"],users=n,changed_lists=w["changed_ordered_lists"],
                changed_sets=w["changed_item_sets"],changed_percent=100*w["changed_ordered_lists"]/n,
                normalized_pairs=w["normalized_pairs_changed"],normalized_entries=w["normalized_entries_changed"],
                recall_stale=stale["hits_at_10"]/n,recall_fresh=fresh["hits_at_10"]/n,
                ndcg_stale=stale["discounted_hits_at_10"]/n,ndcg_fresh=fresh["discounted_hits_at_10"]/n,
                recall_delta_pp=100*(fresh["hits_at_10"]-stale["hits_at_10"])/n,
                ndcg_delta_pp=100*(fresh["discounted_hits_at_10"]-stale["discounted_hits_at_10"])/n,
            ))
            timing_rows.append(dict(
                dataset=dataset,window=j,eligible_users=n,all_users=meta["heldout_users"],
                min_training_timestamp=meta["train_time_min"],stale_cutoff_timestamp=w["old_training_time_max"],
                refreshed_cutoff_timestamp=w["new_training_time_max"],min_target_timestamp=meta["target_time_min"],
                max_target_timestamp=meta["target_time_max"],earlier_all=w["all_heldout"]["earlier"],
                equal_all=w["all_heldout"]["equal"],earlier_eligible=w["eligible_heldout"]["earlier"],
                equal_eligible=w["eligible_heldout"]["equal"],earlier_stale_eligible=w["stale_eligible_heldout"]["earlier"],
                equal_stale_eligible=w["stale_eligible_heldout"]["equal"],
            ))
        for q in sorted(set(meta["batches"])):
            same = [r for r in dataset_rows if r["dataset"] == dataset and r["batch"] == q]
            assert len(same) == 2
            pooled.append(dict(dataset=dataset,batch=q,changed_percent=mean(r["changed_percent"] for r in same),
                               normalized_pairs=[r["normalized_pairs"] for r in same],
                               recall_delta_pp=mean(r["recall_delta_pp"] for r in same),
                               ndcg_delta_pp=mean(r["ndcg_delta_pp"] for r in same)))
        result[dataset]=dict(label=label, meta=meta, windows=windows)
    write_csv("refresh_per_window.csv",dataset_rows)
    write_csv("timestamp_audit_per_window.csv",timing_rows)
    return result,dataset_rows,timing_rows,pooled


def cutoff(prior):
    raw = records(prior / "cutoff_profile.jsonl")
    output = {}
    for k in (10,20,40):
        w = [r for r in raw if r["kind"] == "profile" and r["k"] == k]
        assert len(w) == 18
        means = {p:mean(r[p] for r in w) for p in PHASES}
        residuals = [r["update_ms"] - sum(r[p] for p in PHASES) for r in w]
        assert min(residuals) >= 0
        totals=describe([r["update_ms"] for r in w])
        assert abs(totals["mean"] - sum(means.values()) - mean(residuals)) < 1e-10
        output[k]=dict(totals=totals,means=means,residual=describe(residuals),
                       median_pairs=median(r["patch_pairs"] for r in w))
    old = [r["cutoffs"]["40"]["update_ms"] for r in records(prior / "round1/yelp_graph_sensitivity.jsonl")
           if r["kind"] == "window"]
    assert round(max(old),2) == 1559.86
    return output


def inherited(prior2,prior3):
    old=runpy.run_path(str(prior3 / "round3_analysis.py"))
    prior_values=json.loads((prior3 / "evidence/round3_audit.json").read_text(encoding="utf-8"))
    short,_=old["short_tables"](prior2)
    audit=old["check_tex_short_tables"].__globals__
    audit["ROOT"]=ROOT
    rows=old["check_tex_short_tables"](short)
    for name in ("round3_long_rows.tex", "round3_luxury_rows.tex", "figures/casg_luxury_validation.pdf"):
        assert (ROOT / "latex" / name).read_bytes() == (prior3 / "latex" / name).read_bytes(), name
    repeats=prior_values["long"]["repeats"]
    a,v=repeats["affected_rows"],repeats["view"]
    phase=mean(x["updates_s"]-y["updates_s"] for x,y in zip(a,v,strict=True))
    net=mean(x["total_s"]-y["total_s"] for x,y in zip(a,v,strict=True))
    reduction=100*net/mean(x["total_s"] for x in a)
    return dict(short_tables=rows, long_update_saving_s=phase, long_net_saving_s=net,
                long_net_percent=reduction, verified_unchanged=["Table 9", "Table 16", "Figure 4"])


def export(stats):
    bal=stats["balanced"]
    pairs=bal["pairs"]
    tex_rows("round4_balanced_rows", [
        (label, f'{mean(r["init_s"] for r in rows):.2f}', f'{mean(r["update_s"] for r in rows):.2f}',
         f'{mean(totals):.2f} [{min(totals):.2f}, {max(totals):.2f}]')
        for route,label in (("affected_rows","Affected rows"),("view","Bounded view"))
        for rows in [[p["routes"][route] for p in pairs]]
        for totals in [[r["total_s"] for r in rows]]
    ])
    tex_rows("round4_refresh_rows", [
        (DATA[r["dataset"]][0],f'{r["batch"]:,}',f'{r["changed_percent"]:.2f}',
         f'{min(r["normalized_pairs"]):,}--{max(r["normalized_pairs"]):,}',
         f'{r["recall_delta_pp"]:+.4f}',f'{r["ndcg_delta_pp"]:+.4f}')
        for r in stats["pooled_refresh"]
    ])
    tex_rows("round4_timestamp_rows", [
        (DATA[d][0],f'{m["eligible_users"]:,}',f'{first["earlier_eligible"]:,}',
         f'{m["earlier_eligible"]:,}',f'{m["earlier_all"]:,}/{m["all_users"]:,}',
         f'{m["equal_eligible"]:,}')
        for d in DATA
        for first in [next(x for x in stats["timestamps"] if x["dataset"] == d and x["window"] == 1)]
        for m in [next(x for x in stats["timestamps"] if x["dataset"] == d and x["window"] == 6)]
    ])
    tex_rows("round4_cutoff_rows", [
        (k,f'{r["median_pairs"]:,.0f}',f'{r["totals"]["median"]:.1f} [{r["totals"]["low"]:.1f}, {r["totals"]["high"]:.1f}]',
         f'{r["totals"]["mean"]:.2f}',*(f'{r["means"][p]:.2f}' for p in PHASES),f'{r["residual"]["mean"]:.3f}')
        for k,r in stats["cutoff"].items()
    ])
    ns=[p["net_saving_s"] for p in pairs]
    us=[p["update_saving_s"] for p in pairs]
    phase=stats["inherited"]
    changed=[r["changed_percent"] for r in stats["refresh_windows"]]
    recall=[r["recall_delta_pp"] for r in stats["refresh_windows"]]
    ndcg=[r["ndcg_delta_pp"] for r in stats["refresh_windows"]]
    batch_groups = [[r for r in stats["refresh_windows"] if r["batch"] == size] for size in (10,100,1000)]
    def rates(field):
        values = [100*sum(r[field] for r in rows)/sum(r["users"] for r in rows) for rows in batch_groups]
        return rf"{values[0]:.2f}\%, {values[1]:.2f}\% and {values[2]:.2f}\%"
    def span(seq,prec=2):
        return f"{min(seq):.{prec}f} to {max(seq):.{prec}f}"
    macros=dict(
        PreviousUpdateSaving=f'{phase["long_update_saving_s"]:.2f}',
        PreviousReduction=f'{phase["long_net_percent"]:.1f}',
        BalancedNet=f'{mean(ns):.2f}', BalancedNetRange=span(ns), BalancedUpdate=f'{mean(us):.2f}',
        BalancedAffectedFirst=span([p["net_saving_s"] for p in pairs if p["order"][0]=="affected_rows"]),
        BalancedViewFirst=span([p["net_saving_s"] for p in pairs if p["order"][0]=="view"]),
        RefreshChanged=span(changed), RefreshRecall=span(recall,4), RefreshNdcg=span(ndcg,4),
        RefreshBatchLists=rates("changed_lists"), RefreshBatchSets=rates("changed_sets"),
        RefreshQueryCount=f'{sum(r["users"] for r in stats["refresh_windows"]):,}',
    )
    (ROOT / "latex/round4_values.tex").write_text(
        "\n".join(rf"\newcommand{{\{name}}}{{{value}}}" for name,value in macros.items())+"\n",encoding="utf-8")


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--prior2",type=Path,default=ROOT.parent / "evidence")
    parser.add_argument("--prior3",type=Path,default=ROOT.parent / "round3")
    args=parser.parse_args()
    refresh,per_window,timestamps,pooled=refresh_and_dates(args.prior2)
    result=dict(balanced=balanced(), refresh=refresh,refresh_windows=per_window, timestamps=timestamps,
                pooled_refresh=pooled,cutoff=cutoff(args.prior2), inherited=inherited(args.prior2,args.prior3))
    (EVIDENCE / "round4_audit.json").write_text(json.dumps(result,indent=2)+"\n",encoding="utf-8")
    export(result)
