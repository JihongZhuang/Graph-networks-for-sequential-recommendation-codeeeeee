"""Counterbalanced cold-start comparison of the two strong-baseline routes."""

import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import runpy
import struct
import subprocess
import sys

import psutil


HERE = Path(__file__).resolve().parent
ORDERS = [
    ("affected_rows", "view"), ("view", "affected_rows"),
    ("affected_rows", "view"), ("view", "affected_rows"),
]


def cpu_classes():
    if os.name != "nt":
        return {}
    api = ctypes.windll.kernel32.GetSystemCpuSetInformation
    length = ctypes.c_ulong()
    api(None, 0, ctypes.byref(length), None, 0)
    buffer = ctypes.create_string_buffer(length.value)
    if not api(buffer, length.value, ctypes.byref(length), None, 0):
        return {}
    result = {}
    offset = 0
    while offset + 20 <= length.value:
        size, kind = struct.unpack_from("<II", buffer, offset)
        if size < 20:
            break
        if kind == 0 and struct.unpack_from("<H", buffer, offset + 12)[0] == 0:
            result[buffer.raw[offset + 14]] = buffer.raw[offset + 18]
        offset += size
    return result


def power_state():
    if os.name == "nt":
        result = subprocess.run(["powercfg", "/getactivescheme"], capture_output=True, check=False)
        text = result.stdout.decode("ascii", errors="replace")
        return next((x for x in text.split() if len(x) == 36 and x.count("-") == 4), None)
    return None


def control_snapshot():
    battery = psutil.sensors_battery() if hasattr(psutil, "sensors_battery") else None
    return dict(utc=datetime.now(timezone.utc).isoformat(), power_scheme=power_state(),
                plugged_in=None if battery is None else battery.power_plugged,
                cpu_percent=psutil.cpu_percent(interval=.4, percpu=True),
                available_ram_bytes=psutil.virtual_memory().available)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--route", choices=("affected_rows", "view"))
    parser.add_argument("--cores", type=int, nargs="+")
    args = parser.parse_args()
    frozen = HERE / "round2_experiments.py"
    if args.route:
        proc = psutil.Process()
        proc.cpu_affinity(args.cores)
        assert sorted(proc.cpu_affinity()) == args.cores
        print(json.dumps(dict(kind="affinity", cores=args.cores, priority=str(proc.nice()))), flush=True)
        sys.argv = [str(frozen), "long", "--route", args.route]
        runpy.run_path(str(frozen), run_name="__main__")
        return

    root = args.root.resolve()
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    allowed = psutil.Process().cpu_affinity()
    classes = cpu_classes()
    cores = sorted(sorted(allowed, key=lambda cpu: (-classes.get(cpu, 0), cpu))[:4])
    if len(cores) != 4:
        raise RuntimeError(f"Four logical CPUs are required, found {allowed}")
    env = dict(os.environ, PYTHONPATH=str(root / "outputs"), PYTHONHASHSEED="0",
               PYTHONDONTWRITEBYTECODE="1", PYTHONIOENCODING="utf-8",
               OMP_NUM_THREADS="4", OPENBLAS_NUM_THREADS="4", MKL_NUM_THREADS="4")
    meta = dict(orders=ORDERS, allowed=allowed, efficiency_classes=classes, affinity=cores, threads=4,
                scope="same frozen graph-only replay, independent fresh processes, normal priority",
                frozen_sha256=hashlib.sha256(frozen.read_bytes()).hexdigest())
    (output / "protocol.json").write_text(json.dumps(meta, indent=2) + "\n", encoding="utf-8")
    with (output / "environment.jsonl").open("w", encoding="utf-8") as environment:
        for repeat, order in enumerate(ORDERS, 1):
            for position, route in enumerate(order, 1):
                prefix = output / f"r{repeat}_{route}"
                key = dict(repeat=repeat, position=position, route=route)
                environment.write(json.dumps(dict(**key, phase="before", **control_snapshot())) + "\n")
                environment.flush()
                print(f"Starting repeat {repeat}, position {position}: {route}", flush=True)
                with prefix.with_suffix(".jsonl").open("wb") as log, prefix.with_suffix(".err").open("wb") as error:
                    command = [sys.executable, str(Path(__file__).resolve()), "--route", route,
                               "--cores", *map(str, cores)]
                    subprocess.run(command, cwd=root, env=env, stdout=log, stderr=error, check=True)
                environment.write(json.dumps(dict(**key, phase="after", **control_snapshot())) + "\n")
                environment.flush()
                print(f"Completed repeat {repeat}, position {position}: {route}", flush=True)


if __name__ == "__main__":
    main()
