"""Round-two CASG diagnostics using the frozen first-revision inputs and kernels."""
import argparse
import ast
from collections import Counter, defaultdict
import ctypes
import hashlib
from io import StringIO
import logging
from math import comb
from pathlib import Path
import pickle
import platform
from time import perf_counter
from typing import Dict, List, Tuple

import numpy as np
import pandas as pd
from numpy.polynomial import Polynomial
from scipy.sparse import csr_matrix
from threadpoolctl import threadpool_limits
import torch

from casg_cinm import edge, load_replay
from casg_major_revision import DATASETS, INDEXES, add_history, emit, maintain, rebuild
from casg_revision_sensitivity import ConfigurableCertificate, ranked_state
from exact_polynomial import full_layers, polynomial
from integration_casg import append_merged, rank_checked
from saeif_casg_pilot import append, full_graph, matrix, timed
from saeif_casg_sasrec import SampledProjection, author_model, pad
from saceif_benchmark import peak_mib


def inputs(dataset):
    folder = Path('work/saeif/casg') / dataset
    return folder, load_replay(folder, Path('outputs') / f'saceif_general_casg_{dataset}.txt')


def check_example():
    events = [(0, item, t) for t, item in enumerate((0, 1, 0, 2))]
    counts, histories = Counter(), defaultdict(list)
    append(events[:3], counts, histories)
    old = counts.copy()
    changed = append_merged(events[3:], counts, histories)
    direct, direct_histories = Counter(), defaultdict(list)
    append(events, direct, direct_histories)
    expected = {(0, 1):4,(0, 2):2,(1, 2):2}
    assert dict(old)=={(0,1):4} and changed=={(0,2),(1,2)}
    assert counts == direct == expected and histories == direct_histories
    state = ranked_state(counts, 1)
    assert dict(state.chosen)=={0:{1},1:{0},2:{0}}
    assert state.weights=={(0,1):4,(0,2):2}
    source = Path("work/saeif/CASG-main/filter/train_bernstein.py")
    tree = ast.parse(source.read_text(encoding="utf-8"))
    names = {"build_cooccurrence_graph", "truncate_edges"}
    functions = [node for node in tree.body if getattr(node, "name", None) in names]
    scope = dict(pd=pd, Dict=Dict, List=List, Tuple=Tuple, defaultdict=defaultdict,
                 logging=logging, tqdm=lambda iterable, **_: iterable)
    exec(compile(ast.Module(body=functions, type_ignores=[]), str(source), "exec"), scope)
    upstream_counts = scope["build_cooccurrence_graph"]
    table = pd.DataFrame(events, columns=["USER", "ITEM", "TIMESTAMP"])
    old_reference, _ = upstream_counts(StringIO(table.iloc[:3].to_csv(sep="\t", index=False)))
    new_reference, items = upstream_counts(StringIO(table.to_csv(sep="\t", index=False)))
    retained = scope["truncate_edges"](new_reference, sorted(items), 1)
    assert old_reference == {("0", "1"): 4}
    assert new_reference == {(str(i), str(j)): w for (i, j), w in counts.items()}
    assert retained == {(str(i), str(j)): w for (i, j), w in state.weights.items()}
    adjacency = matrix(state.weights,3)
    assert np.max(np.abs(adjacency.toarray()-np.array([[0,4/np.sqrt(24),2/np.sqrt(12)],
        [4/np.sqrt(24),0,0],[2/np.sqrt(12),0,0]]))) < 1e-14
    emit(kind='example', events=events, new_pairs=[[[2,4],[1,2]],[[3,4],[0,2]]],
         old_counts=[[i,j,w] for (i,j),w in old.items()],
         new_counts=[[i,j,w] for (i,j),w in counts.items()],
         k=1, winners={i:sorted(s) for i,s in state.chosen.items()},
         retained=[[i,j,w] for (i,j),w in sorted(state.weights.items())],
         adjacency=adjacency.toarray().tolist(), exact_full_count_match=True,
         released_constructor_match=True, released_source_sha256=hashlib.sha256(source.read_bytes()).hexdigest())


def quality(dataset):
    folder, (train, test, sizes, weights, _, n) = inputs(dataset)
    prefix = len(train) - sum(sizes)
    histories = defaultdict(list)
    add_history(train[:prefix], histories)
    query = np.array(sorted(u for u, h in histories.items() if h and test.loc[u] not in h))
    add_history(train[prefix:], histories)
    targets = test.loc[query].to_numpy()
    depth = len(weights)-1
    p,q = Polynomial([.5,.5]),Polynomial([.5,-.5])
    coeff = sum(w*comb(depth,k)*p**k*q**(depth-k) for k,w in enumerate(weights)).coef
    with (folder/'bert_cls.pkl').open('rb') as f:
        x = np.asarray(pickle.load(f),np.float64)
    text_rows = pd.read_csv(folder/'item_text.tsv',sep='\t')['ITEM'].to_numpy()
    assert np.array_equal(text_rows,np.arange(n)) and x.shape==(n,768) and np.isfinite(x).all()
    assert np.array_equal(np.unique(train[:,1]),np.arange(n)) or set(train[:,1]).issubset(range(n))
    x -= x.mean(axis=0)
    op = full_graph(train,n)
    z = polynomial(full_layers(op,x,depth),coeff)
    isolated = np.diff(op.indptr)==0
    z[isolated]=x[isolated]
    z = torch.nn.functional.normalize(torch.from_numpy(z).float())
    model=author_model(torch.from_numpy(x).float())
    model.in_proj=SampledProjection(model.in_proj,n)
    checkpoint=folder/'sasrec_validation_selected.pt'
    model.load_state_dict(torch.load(checkpoint,weights_only=True))
    model.eval()
    sample = query[:128]
    data={'sequence':pad(histories,sample)}
    assert np.array_equal(data['sequence'][:,-1].numpy(),np.array([histories[u][-1]+1 for u in sample]))
    with torch.no_grad():
        model.text_item_feats.copy_(z)
        raw = model.recommend_from_full(data)
        model.in_proj.catalog=model.in_proj.projection(z)
        cached=model.recommend_from_full(data)
        model.in_proj.catalog=None
        assert torch.equal(raw,cached)
    top,_,_,ranking_ms=rank_checked(model,z,histories,query,test)
    # Independently check the final seen-item policy on a fixed batch.
    for j,u in enumerate(sample):
        raw[j,[i for i in histories[u] if i!=test[u]]]=-torch.inf
    assert np.array_equal(torch.topk(raw,20,dim=1).indices.numpy(),top[:len(sample)])
    hit=top==targets[:,None]
    discount=1/np.log2(np.arange(2,22))
    metrics={}
    for k in (10,20):
        metrics[f'recall_at_{k}']=float(hit[:,:k].sum(axis=1).mean())
        metrics[f'ndcg_at_{k}']=float((hit[:,:k]*discount[:k]).sum(axis=1).mean())
    emit(kind='quality', dataset=dataset, scope='first revision five-route protocol; rebuilt route, fixed final window',
         window=len(sizes), prefix=prefix, stop=len(train), users=len(query), items=n, isolated_items=int(isolated.sum()),
         repeated_test_targets_at_stop=sum(target in histories[u] for u,target in zip(query,targets)),
         user_sha256=hashlib.sha256(query.astype('<i8').tobytes()).hexdigest(),
         top20_sha256=hashlib.sha256(top.astype('<i8').tobytes()).hexdigest(),
         cached_released_scorer_exact=True, mask_checked_users=len(sample),
         ranking_ms=ranking_ms, **metrics)


def profile_patch(state, counts, changed):
    """Instrument the existing path at phase boundaries; leave its data structures intact."""
    marks = [perf_counter()]
    candidates=defaultdict(set)
    for i,j in changed:
        candidates[i].add(j); candidates[j].add(i)
    affected=set(changed)
    examined=0
    for i,row in candidates.items():
        before=state.winners[i]
        after,n=state.select(i,row,counts)
        state.winners[i]=after
        examined+=n
        affected.update(edge(i,j) for j in before^after)
    marks.append(perf_counter())
    degree_change=Counter()
    dirty=set()
    for i,j in affected:
        old=state.weights.get((i,j),0)
        new=counts[i,j] if j in state.winners[i] or i in state.winners[j] else 0
        if new==old:
            continue
        dirty.add((i,j))
        degree_change[i]+=new-old
        degree_change[j]+=new-old
        if new:
            state.weights[i,j]=new
            state.links[i].add(j); state.links[j].add(i)
        else:
            del state.weights[i,j]
            state.links[i].remove(j); state.links[j].remove(i)
    marks.append(perf_counter())
    for i,change in degree_change.items():
        if change:
            state.degree[i]+=change
            dirty.update(edge(i,j) for j in state.links[i])
    marks.append(perf_counter())
    patch_ms=merge_ms=0.
    if dirty:
        pairs=list(dirty)
        row,col=np.asarray(pairs).T
        new=np.asarray([state.weights.get(pair,0) for pair in pairs],dtype=float)
        present=new>0
        new[present]/=np.sqrt(state.degree[row[present]]*state.degree[col[present]])
        old=np.asarray(state.operator[row,col]).ravel()
        delta=new-old
        marks.append(perf_counter())
        patch,patch_ms=timed(lambda:csr_matrix((np.tile(delta,2),(np.r_[row,col],np.r_[col,row])),
                                               shape=state.operator.shape))
        state.operator,merge_ms=timed(lambda:state.operator+patch)
    else:
        marks.append(perf_counter())
    parts=dict(zip(('selection_ms','retained_edges_ms','degree_incidence_ms','weight_values_ms'),
                   ((b-a)*1000 for a,b in zip(marks,marks[1:]))))
    return dict(**parts,patch_build_ms=patch_ms,csr_merge_ms=merge_ms,
                patch_pairs=len(dirty),examined_keys=examined,kept_edges=len(state.weights),
                operator_nnz=state.operator.nnz)


def cutoff_profile(repeats):
    _,(train,_,sizes,_,_,n)=inputs('Yelp2018_matched')
    prefix=len(train)-sum(sizes)
    emit(kind='metadata', dataset='Yelp2018_matched', prefix=prefix, sizes=sizes, repeats=repeats,
         scope='phase-instrumented graph-only replay, independent setup each repeat',
         allocation_scope='array allocation included where performed; allocator time not independently measured')
    for rep in range(1,repeats+1):
        counts,histories=Counter(),defaultdict(list)
        append(train[:prefix],counts,histories)
        states={k:ConfigurableCertificate(counts,n,k) for k in (10,20,40)}
        begin=prefix
        rng=np.random.default_rng(2480+rep)
        for win,size in enumerate(sizes,1):
            end=begin+size
            changed=append_merged(train[begin:end],counts,histories)
            order=[int(k) for k in rng.permutation(list(states))]
            for k in order:
                phases,total_ms=timed(lambda:profile_patch(states[k],counts,changed))
                emit(kind='profile',repeat=rep,window=win,batch=size,k=k,route_order=order,
                     update_ms=total_ms,**phases)
            begin=end
        for k,state in states.items():
            fresh=ranked_state(counts,k)
            assert fresh.weights==state.weights
            error=float(np.max(np.abs((matrix(fresh.weights,n)-state.operator).data),initial=0))
            assert error<1e-14
            emit(kind='verification',repeat=rep,k=k,final_graph_error=error)
        del states


def long_graph(route):
    _,(train,_,_,_,_,n)=inputs('Yelp2018_matched')
    batch,windows=1000,24
    start=len(train)-batch*windows
    counts,histories=Counter(),defaultdict(list)
    init_ms=0.
    if route!='full_rebuild':
        _,t=timed(lambda:append(train[:start],counts,histories))
        state,init_ms=timed(lambda:INDEXES[route](counts,n))
        init_ms+=t
    emit(kind='metadata',dataset='Yelp2018_matched',route=route,batch=batch,windows=windows,
         start=start,stop=len(train),initialization_ms=init_ms,initial_peak_mib=peak_mib(),
         scope='single graph-only replay in a separate process; input loading and score/filter excluded')
    begin=start
    for win in range(1,windows+1):
        end=begin+batch
        if route=='full_rebuild':
            (op,_),ms=timed(lambda:rebuild(train[:end],n))
        else:
            changed,ms=timed(lambda:append_merged(train[begin:end],counts,histories))
            (op,_),cost=timed(lambda:maintain(state,counts,changed))
            ms+=cost
        emit(kind='window',window=win,end=end,graph_ms=ms,peak_mib=peak_mib(),operator_nnz=op.nnz)
        begin=end
    peak=peak_mib()
    ref=full_graph(train,n)
    error=float(np.max(np.abs((ref-op).data),initial=0))
    assert error<1e-14
    emit(kind='verification',route=route,final_graph_error=error,peak_before_audit_mib=peak)


if __name__=='__main__':
    p=argparse.ArgumentParser()
    p.add_argument('experiment',choices=('example','quality','profile','long'))
    p.add_argument('--dataset',choices=DATASETS)
    p.add_argument('--route',choices=('full_rebuild','affected_rows','ordered','view','CINM'))
    p.add_argument('--repeats',type=int,default=3)
    a=p.parse_args()
    if a.experiment=='quality' and not a.dataset:
        p.error('--dataset is required for quality')
    if a.experiment=='long' and not a.route:
        p.error('--route is required for long')
    torch.set_num_threads(4)
    torch.manual_seed(30)
    if platform.system()=='Windows':
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    with threadpool_limits(limits=4):
        if a.experiment=='example':check_example()
        if a.experiment=='quality':quality(a.dataset)
        if a.experiment=='profile':cutoff_profile(a.repeats)
        if a.experiment=='long':long_graph(a.route)
