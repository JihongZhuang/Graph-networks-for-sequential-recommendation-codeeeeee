"""Audit paired window records and write traceable second-round result tables."""

import csv
import json
import math
from pathlib import Path
from statistics import mean, median, stdev


ROOT = Path(__file__).resolve().parent
EVIDENCE = ROOT / "evidence"
DATA = {
    "Luxury_Beauty": ("Luxury Beauty", "luxury"),
    "Musical_Instruments": ("Musical Instruments", "musical"),
    "Yelp2018_matched": ("Yelp2018", "yelp"),
}
ROUTES = {
    "full_rebuild": "Rebuild",
    "affected_rows": "Affected",
    "ordered": "Full order",
    "view": "Bounded view",
    "CINM": "CINM",
}
PAIRS = (
    ("view", "full_rebuild"), ("view", "affected_rows"),
    ("CINM", "affected_rows"), ("view", "ordered"), ("view", "CINM"),
    ("ordered", "affected_rows"),
)
PHASES = ("count_ms", "selection_ms", "state_ms", "normalization_ms")
PROFILE_PHASES = (
    "selection_ms", "retained_edges_ms", "degree_incidence_ms",
    "weight_values_ms", "patch_build_ms", "csr_merge_ms",
)


def records(name):
    return [json.loads(line) for line in (EVIDENCE / name).read_text(encoding="utf-8-sig").splitlines()]


def describe(values):
    return dict(mean=mean(values), median=median(values), low=min(values), high=max(values))


def interval(values):
    assert len(values) == 3
    margin = 4.302652729911275 * stdev(values) / math.sqrt(3)
    return [mean(values) - margin, mean(values) + margin]


def same(a, b):
    assert math.isclose(a, b, rel_tol=1e-9, abs_tol=1e-8), (a, b)


def ms_sum(rows, keys):
    return sum(row[key] for row in rows for key in keys) / 1000


def audit_main(dataset, frozen, window_pairs):
    raw = records(f"round1/{dataset}.jsonl")
    meta = raw[0]
    windows = {(w["repeat"], w["window"]): w for w in raw if w["kind"] == "window"}
    setups = {(s["repeat"], s["route"]): s for s in raw if s["kind"] == "initialization"}
    repeats = (1, 2, 3)
    assert len(windows) == 18 and len(setups) == 15
    assert all(w["batch"] == meta["batches"][j - 1] for (_, j), w in windows.items())
    users = {w["users"] for w in windows.values()}.pop()
    result = dict(
        prefix=meta["prefix"], added=meta["stop"] - meta["prefix"], users=users,
        lists_per_route=18 * users, routes={}, comparisons={},
    )
    for route in ROUTES:
        rows = [w["routes"][route] for w in windows.values()]
        assert all(w["users"] == users for w in windows.values())
        assert all(r["top20_matches"] == users and r["identical_scorer_input"] for r in rows)
        for row in rows:
            same(row["total_ms"], sum(row[k] for k in ("graph_ms", "history_ms", "filter_ms", "score_rank_ms")))
        keys = (*PHASES, "graph_ms", "history_ms", "filter_ms", "score_rank_ms", "total_ms")
        phase = {k: ms_sum(rows, [k]) for k in keys}
        prefix = [setups[j, route]["prefix_ms"] / 1000 for j in repeats]
        index = [setups[j, route]["index_ms"] / 1000 for j in repeats]
        starts = [p + i for p, i in zip(prefix, index)]
        repeat_rows = [[w["routes"][route] for (r, _), w in windows.items() if r == j] for j in repeats]
        steady = [ms_sum(rr, ["total_ms"]) for rr in repeat_rows]
        graph = [ms_sum(rr, ["graph_ms", "history_ms"]) for rr in repeat_rows]
        cold = [s + t for s, t in zip(starts, steady)]
        rebuild_rows = [w["routes"]["full_rebuild"] for w in windows.values()]
        item = dict(
            stages_s=phase, steady_repeats_s=steady, startup_repeats_s=starts, cold_repeats_s=cold,
            total_cold_s=sum(cold), mean_prefix_s=mean(prefix), mean_index_s=mean(index),
            single_init_s=sum(steady) + mean(starts),
            common_downstream_s=sum(starts) + sum(graph) + ms_sum(rebuild_rows, ["filter_ms", "score_rank_ms"]),
            graph_residual_s=phase["graph_ms"] - sum(phase[k] for k in PHASES),
            graph_history_repeat_s=graph,
            window_s=describe([r["total_ms"] / 1000 for r in rows]),
            max_operator_error=max(r["operator_error"] for r in rows),
        )
        for key, value in frozen["routes"][route].items():
            baseline = item[key]
            if isinstance(value, dict):
                for field in value:
                    same(value[field], baseline[field])
            elif isinstance(value, list):
                for expected, actual in zip(value, baseline, strict=True):
                    same(expected, actual)
            else:
                same(value, baseline)
        result["routes"][route] = item
    reference = result["routes"]["full_rebuild"]
    for item in result["routes"].values():
        item["figure1_ratios"] = {
            k: [a / b for a, b in zip(item[k], reference[k], strict=True)]
            for k in ("graph_history_repeat_s", "cold_repeats_s")
        }
    for a, b in PAIRS:
        comparisons = []
        for (j, window), w in windows.items():
            left, right = w["routes"][a], w["routes"][b]
            record = dict(dataset=dataset, method=a, comparator=b, repeat=j, window=window, batch=w["batch"])
            for field in ("graph_ms", "history_ms", "filter_ms", "score_rank_ms", "total_ms"):
                record[field] = left[field] - right[field]
            comparisons.append(record)
        window_pairs.extend(comparisons)
        left, right = result["routes"][a], result["routes"][b]
        cold = [x - y for x, y in zip(left["cold_repeats_s"], right["cold_repeats_s"])]
        component = left["common_downstream_s"] - right["common_downstream_s"]
        graph = [x - y for x, y in zip(left["graph_history_repeat_s"], right["graph_history_repeat_s"])]
        startup = [x - y for x, y in zip(left["startup_repeats_s"], right["startup_repeats_s"])]
        same(component, sum(graph) + sum(startup))
        result["comparisons"][f"{a}/{b}"] = dict(
            cold_repeats_s=cold, cold_mean_s=mean(cold), cold_ci_s=interval(cold),
            component_delta_s=component, graph_history_delta_s=sum(graph),
            startup_delta_s=sum(startup), window_wins=sum(w["total_ms"] < 0 for w in comparisons),
            distributions_ms={
                k: describe([row[k] for row in comparisons])
                for k in ("graph_ms", "history_ms", "filter_ms", "score_rank_ms", "total_ms")
            },
        )
    return result


def check_old_intervals(main):
    with (EVIDENCE / "round1/paired_comparisons.csv").open(newline="", encoding="utf-8-sig") as handle:
        for record in csv.DictReader(handle):
            d, a, b = (record[k] for k in ("dataset", "route", "reference"))
            pair = main[d]["comparisons"].get(f"{a}/{b}")
            if pair is None:
                continue
            same(pair["cold_mean_s"], float(record["cold_delta_mean_s"]))
            for result, name in zip(pair["cold_ci_s"], ("ci95_low_s", "ci95_high_s"), strict=True):
                same(result, float(record[name]))
            assert pair["window_wins"] == int(record["windows_faster"])


def audit_diagnostics():
    raw = records("cutoff_profile.jsonl")
    cutoff = {}
    for k in (10, 20, 40):
        rows = [r for r in raw if r["kind"] == "profile" and r["k"] == k]
        checks = [r for r in raw if r["kind"] == "verification" and r["k"] == k]
        assert len(rows) == 18 and len(checks) == 3
        assert all(r["final_graph_error"] < 1e-14 for r in checks)
        cutoff[k] = dict(
            **{field: describe([r[field] for r in rows]) for field in ("update_ms", "patch_pairs", *PROFILE_PHASES)},
            window2_ms=[r["update_ms"] for r in rows if r["window"] == 2],
            by_batch_ms={
                q: describe([r["update_ms"] for r in rows if r["batch"] == q]) for q in (10, 100, 1000)
            },
        )
    old = [r["cutoffs"]["40"] for r in records("round1/yelp_graph_sensitivity.jsonl") if r["kind"] == "window"]
    long = {}
    for route in ("full_rebuild", "affected_rows", "view", "CINM"):
        meta, *windows, check = records(f"long_{route}.jsonl")
        assert len(windows) == 24 and check["final_graph_error"] < 1e-14
        assert all(r["end"] == meta["start"] + 1000 * i for i, r in enumerate(windows, 1))
        elapsed = ms_sum(windows, ["graph_ms"])
        long[route] = dict(
            start=meta["start"], stop=meta["stop"], windows=len(windows),
            initialization_s=meta["initialization_ms"] / 1000, updates_s=elapsed,
            total_s=elapsed + meta["initialization_ms"] / 1000,
            peak_mib=check["peak_before_audit_mib"], final_error=check["final_graph_error"],
        )
    return dict(
        cutoff=cutoff, long=long, old_cutoff40_median_ms=median(r["update_ms"] for r in old),
        old_cutoff40_max=max(old, key=lambda r: r["update_ms"]),
    )


def row(*cells):
    return " & ".join(map(str, cells)) + r" \\"


def tab_body(path, rows):
    body = "\n".join([*rows, r"\bottomrule"]) + "\n"
    (ROOT / "latex" / f"{path}.tex").write_text(body, encoding="utf-8")


def export_tables(audit):
    main = audit["main"]
    quality = audit["quality"]
    metrics = ("recall_at_10", "ndcg_at_10", "recall_at_20", "ndcg_at_20")
    tab_body("round2_quality_rows", [
        row(DATA[d][0], f'{q["users"]:,}', *(f"{q[k]:.4f}" for k in metrics)) for d, q in quality.items()
    ])
    cols = ("graph_ms", "filter_ms", "score_rank_ms")
    short = dict(ROUTES, view="View", ordered="Order", affected_rows="Rows")
    def med_span(r):
        values = [round(r[k], 1) or 0.0 for k in ("median", "low", "high")]
        return f"{values[0]:.1f} [{values[1]:.1f}, {values[2]:.1f}]"
    tab_body("round2_paired_rows", [
        row(DATA[d][0], f"{short[a]} / {short[b]}", *(med_span(c["distributions_ms"][k]) for k in cols))
        for d, m in main.items()
        for a, b in PAIRS[1:]
        for c in [m["comparisons"][f"{a}/{b}"]]
    ])
    tab_body("round2_graph_rows", [
        row(DATA[d][0], ROUTES[a], *(f"{c[k]:+.2f}" for k in (
            "graph_history_delta_s", "startup_delta_s", "component_delta_s",
        )), f'{sum(c["cold_repeats_s"]):+.2f}')
        for d, m in main.items()
        for a in ("ordered", "view", "CINM")
        for c in [m["comparisons"][f"{a}/affected_rows"]]
    ])
    profile = audit["diagnostics"]["cutoff"]
    tab_body("round2_cutoff_rows", [
        row(k, f'{p["patch_pairs"]["median"]:,.0f}', med_span(p["update_ms"]),
            *(f'{p[key]["mean"]:.1f}' for key in PROFILE_PHASES))
        for k, p in profile.items()
    ])
    tab_body("round2_long_rows", [
        row(ROUTES[r], *(f"{p[k]:.2f}" for k in ("initialization_s", "updates_s", "total_s")), f'{p["peak_mib"]:.1f}')
        for r, p in audit["diagnostics"]["long"].items()
    ])
    tab_body("round2_residual_rows", [
        row(DATA[d][0], *(f'{m["routes"][r]["graph_residual_s"]:.3f}' for r in ROUTES))
        for d, m in main.items()
    ])


def main():
    frozen = json.loads((EVIDENCE / "round1/summary.json").read_text(encoding="utf-8-sig"))
    paired = []
    audit = dict(
        main={d: audit_main(d, frozen[d], paired) for d in DATA},
        diagnostics=audit_diagnostics(),
        quality={d: records(f"quality_{tag}.jsonl")[0] for d, (_, tag) in DATA.items()},
        count_example=records("count_example_upstream.jsonl")[0],
    )
    assert audit["count_example"]["released_constructor_match"]
    for d, q in audit["quality"].items():
        m = audit["main"][d]
        assert q["users"] == m["users"] and q["prefix"] == m["prefix"]
        assert q["stop"] == m["prefix"] + m["added"] and q["cached_released_scorer_exact"]
    check_old_intervals(audit["main"])
    (EVIDENCE / "round2_audit.json").write_text(json.dumps(audit, indent=2) + "\n", encoding="utf-8")
    with (EVIDENCE / "round2_paired_windows.csv").open("w", newline="", encoding="utf-8") as handle:
        writer = csv.DictWriter(handle, fieldnames=list(paired[0]))
        writer.writeheader()
        writer.writerows(paired)
    export_tables(audit)


if __name__ == "__main__":
    main()
