"""Reaudit frozen Yelp evidence and summarize the independent music control."""

import ast
from hashlib import file_digest, sha256
import json
from pathlib import Path
import runpy
from statistics import mean


HERE=Path(__file__).resolve().parent
ROOT=HERE.parent
OLD=runpy.run_path(str(ROOT/'round11/analyze.py'))
read,summary,csv_out,tex_rows=(OLD[k] for k in ('read','summary','csv_out','tex_rows'))
ROUTES=OLD['ROUTES']
LABEL=OLD['LABEL']
PAIRS=(*OLD['PAIRS'],('view','CINM'))


def collect(logs,dataset,prefix,stop,batches):
    protocol=json.loads((logs/'protocol.json').read_text(encoding='utf-8'))
    assert len(protocol['orders'])==4
    assert all({order[i] for order in protocol['orders']}==set(ROUTES) for i in range(4))
    controls=read(logs/'environment.jsonl')
    assert len(controls)==32
    for j,order in enumerate(protocol['orders'],1):
        assert [(r['position'],r['route'],r['phase']) for r in controls if r['repeat']==j]==[
            (pos,name,phase) for pos,name in enumerate(order,1) for phase in ('before','after')]
    samples,windows=[],[]
    ends=[prefix+sum(batches[:i]) for i in range(1,len(batches)+1)]
    for j in range(1,5):
        for route in ROUTES:
            meta,*rows,last=read(logs/f'r{j}_{route}.jsonl')
            assert meta['kind']=='metadata' and meta['dataset']==dataset and last['kind']=='complete'
            assert (meta['start'],meta['stop'])==(prefix,stop)
            assert meta['threads']==4 and meta['cores']==protocol['affinity']
            assert [r['window'] for r in rows]==list(range(1,len(batches)+1))
            assert [r['end'] for r in rows]==ends and meta['windows']==len(batches)
            init=meta['initialization_ms']/1000
            assert abs(init-(meta['prefix_ms']+meta['index_ms'])/1000)<1e-12
            assert all(abs(r['graph_ms']-r['count_ms']-r['maintain_ms'])<1e-9 for r in rows)
            row=dict(repeat=j,route=route,prefix_s=meta['prefix_ms']/1000,index_s=meta['index_ms']/1000,
                     setup_s=init,update_s=sum(r['graph_ms'] for r in rows)/1000,peak_mib=last['peak_mib'])
            row['total_s']=row['setup_s']+row['update_s']
            samples.append(row)
            windows.extend(dict(repeat=j,route=route,**r) for r in rows)
    indexed={(r['repeat'],r['route']):r for r in samples}
    contrasts,paired={},[]
    for a,b in PAIRS:
        delta=[indexed[j,a]['total_s']-indexed[j,b]['total_s'] for j in range(1,5)]
        contrasts[a+'-'+b]=dict(**summary(delta),values=delta,
            percent=100*mean(delta)/mean(indexed[j,a]['total_s'] for j in range(1,5)))
        for j in range(1,5):
            paired.append(dict(repeat=j,contrast=a+'-'+b,
                **{k:indexed[j,a][k]-indexed[j,b][k] for k in ('setup_s','update_s','total_s')}))
    window_pairs=[]
    by_window={(r['repeat'],r['route'],r['window']):r for r in windows}
    for j in range(1,5):
        for i in range(1,len(batches)+1):
            window_pairs.append(dict(repeat=j,window=i,end=ends[i-1],
                **{name:by_window[j,name,i]['graph_ms']/1000 for name in ROUTES}))
    meta,*verification,end=read(logs/'verification.jsonl')
    assert end['kind']=='complete' and end['route_windows']==len(batches)*4
    assert len(verification)==len(batches)
    for i,v in enumerate(verification,1):
        assert v['window']==i and v['end']==ends[i-1] and v['counts_exact'] and v['histories_exact']
        for name,c in v['checks'].items():
            assert c['graph_state_exact'] and c['normalized_support_exact'] and c['features_bitwise_equal']
            assert c['independent_scoring']==(i==len(batches))
            assert c['top20_matches']==meta['users'] and c['top20_sha256']==v['reference_top20_sha256']
            for j in range(1,5):
                assert all(by_window[j,name,i][k]==c[k] for k in ('candidate_keys','operator_nnz'))
        assert v['checks']['partial']['candidate_keys']==v['checks']['affected_rows']['candidate_keys']
    stem='yelp' if dataset=='Yelp2018_matched' else 'music'
    csv_out(HERE/f'evidence/{stem}_runs.csv',samples)
    csv_out(HERE/f'evidence/{stem}_paired_savings.csv',paired)
    csv_out(HERE/f'evidence/{stem}_paired_windows.csv',window_pairs)
    rows={name:{k:summary([r[k] for r in samples if r['route']==name]) for k in ('setup_s','update_s','total_s','peak_mib')}
          for name in ROUTES}
    power=[r for r in controls if not r['plugged_in']]
    return dict(dataset=dataset,prefix=prefix,stop=stop,batches=batches,routes=rows,contrasts=contrasts,
        controls_not_plugged=power,reference_queries=meta['users']*len(batches),users=meta['users'],
        independent_route_lists=meta['users']*4,independent_windows=[len(batches)],graph_comparisons=4*len(batches),
        maximum_operator_error=max(c['normalized_max_abs_error'] for r in verification for c in r['checks'].values()))


def export(yelp,music):
    tags=dict(affected_rows='Full Sort',partial='Partial',view='View',CINM='CINM')
    for stem,data in [('yelp',yelp),('music',music)]:
        tex_rows(HERE/f'latex/round12_{stem}_pairs.tex',[
            (rf'{tags[a]} $\to$ {tags[b]}',*(f'{v:+.2f}' for v in r['values']),
             f'{r["mean"]:+.2f}',f'{r["median"]:+.2f}',f'[{r["low"]:+.2f}, {r["high"]:+.2f}]')
            for a,b in PAIRS for r in [data['contrasts'][a+'-'+b]]])
    r=music['routes']
    tex_rows(HERE/'latex/round12_music_rows.tex',[(LABEL[k],f'{r[k]["setup_s"]["mean"]:.3f}',
        f'{r[k]["update_s"]["mean"]:.3f}',f'{r[k]["total_s"]["mean"]:.3f}',
        f'[{r[k]["total_s"]["low"]:.3f}, {r[k]["total_s"]["high"]:.3f}]') for k in ROUTES])
    values={}
    for tag,key in [('MusicView','partial-view'),('MusicCINM','partial-CINM'),('YelpCINMView','view-CINM')]:
        r=(music if tag.startswith('Music') else yelp)['contrasts'][key]
        values.update({tag+'Saving':f'{r["mean"]:.3f}',tag+'Median':f'{r["median"]:.3f}',
                       tag+'Range':f'{r["low"]:.3f} to {r["high"]:.3f}',tag+'Pct':f'{r["percent"]:.1f}'})
    values.update(MusicUsers=f'{music["users"]:,}',MusicRefs=f'{music["reference_queries"]:,}',
                  MusicIndependent=f'{music["independent_route_lists"]:,}')
    (HERE/'latex/round12_values.tex').write_text(''.join(rf'\newcommand{{\{k}}}{{{v}}}'+'\n' for k,v in values.items()),encoding='utf-8')


if __name__=='__main__':
    def partial_ast(path):
        return ast.dump(next(n for n in ast.walk(ast.parse(path.read_text(encoding='utf-8')))
                             if isinstance(n,ast.ClassDef) and n.name=='PartialRows'),include_attributes=False)
    assert partial_ast(HERE/'music_replay.py')==partial_ast(ROOT/'round11/partial_replay.py')
    yelp=collect(ROOT/'round11/evidence/long_replay','Yelp2018_matched',915002,939002,[1000]*24)
    music=collect(HERE/'evidence/music_replay','Musical_Instruments',173332,175552,[10,100,1000]*2)
    frozen=ROOT/'round5/qa/full_round5'
    excerpt=HERE/'evidence/frozen_manifest_excerpt.json'
    manifest=json.loads((frozen/'CONTENTS_SHA256.json' if frozen.is_dir() else excerpt).read_text(encoding='utf-8'))
    hashes={}
    for folder in (ROOT/'round11/evidence/long_replay',HERE/'evidence/music_replay'):
        declared=json.loads((folder/'protocol.json').read_text(encoding='utf-8'))['frozen_sha256']
        for path,value in declared.items():
            assert manifest[path]==value
            if frozen.is_dir():
                with (frozen/path).open('rb') as source:
                    actual=file_digest(source,'sha256').hexdigest()
                assert actual==value,path
            hashes[path]=value
    excerpt.write_text(json.dumps(hashes,indent=2)+'\n',encoding='utf-8')
    export(yelp,music)
    result=dict(yelp=yelp,music=music,partial_implementation_ast_identical=True,
                frozen_sha256=hashes,partial_selector_ast_sha256=sha256(partial_ast(HERE/'music_replay.py').encode()).hexdigest())
    (HERE/'evidence/round12_audit.json').write_text(json.dumps(result,indent=2)+'\n',encoding='utf-8')
