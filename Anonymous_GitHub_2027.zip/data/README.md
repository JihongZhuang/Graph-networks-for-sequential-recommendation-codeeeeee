# Data and provenance

We evaluate Luxury Beauty and Musical Instruments from [Amazon Reviews 2018](https://cseweb.ucsd.edu/~jmcauley/datasets/amazon_v2/) and a statistics-matched Yelp2018 reconstruction from the [FreeRec v1 archive](https://zenodo.org/records/10998102). We use radius two, *K* = 20, lexicographic item-ID tie breaking, and second-order Bernstein filtering in the primary replays. The full-catalogue study pools three timed replays per dataset, each on the same six-window update stream. The strict chronological experiment uses the raw Luxury Beauty reviews with the global cutoff at 2017-01-01 UTC.

We record source releases, splits, preprocessing rules, and archive fingerprints in the [data and code manifest](../round2/evidence/round1/data_and_code_manifest.json). [`input_sha256.json`](input_sha256.json) identifies the prepared data, feature arrays, and checkpoints used in replay. The official provider archives supply the raw records. Exact benchmark replay also requires the prepared feature arrays and checkpoints listed in the manifest. The recorded-analysis workflow runs with the files in this repository.

## Prepared input layout

Place each prepared dataset under `work/saeif/casg/` with its original name (`Luxury_Beauty`, `Musical_Instruments`, or `Yelp2018_matched`). Each replay reads `events.tsv`, `bert_cls.pkl`, and `sasrec_validation_selected.pt`. The manifest also records `item_text.tsv` and Yelp's `item_ids.tsv` for preprocessing provenance. The included calibration records carry the archived Bernstein coefficients and batch schedules.

Obtain the [CASG source at commit `76d713b`](https://github.com/blueColdSea/CASG/commit/76d713b7cc6dad608fbdaf5d2fdbebaf87fb6c2a). A checkout of that revision under `work/saeif/CASG-main/` supplies the SASRec scorer and Bernstein training functions.

To reconstruct the event and text inputs, place the original Amazon review and metadata files and `Yelp2018.zip` under `work/saeif/casg/`. Run preparation in a separate checkout when keeping a frozen set of inputs.

```sh
python outputs/saeif_casg_prepare.py Luxury_Beauty Musical_Instruments
python outputs/saeif_yelp2018_matched.py work/saeif/casg/Yelp2018.zip work/saeif/casg/Yelp2018_matched
```

We use 4-core preprocessing for Luxury Beauty, 5-core for Musical Instruments, and iterative 10-core filtering after retaining Yelp ratings of at least four. Feature extraction and the local SASRec fit are in `outputs/saeif_casg_encode.py` and `outputs/saeif_casg_sasrec.py`. Feature extraction requires Transformers and compatible local BERT model and tokenizer files under `work/saeif/casg/bert/`. To reproduce the recorded scores, verify the exact prepared input bytes using `python verify_inputs.py .`. Use the subset option `--prefix work/saeif/casg/Yelp2018_matched/` for a single dataset.

## Additional protocols

For the strict chronological replay, we hold the prediction function fixed across graph conditions. To rerun the paired test using the archived checkpoint, use the supplied chronology record and the matching raw file and checkpoint. Set `PYTHONPATH` as described in the root README.

```sh
python round9/rank_depths.py --raw work/saeif/casg/Luxury_Beauty.json.gz --prior round5/evidence/chronological.jsonl --checkpoint round5/evidence/chronological_checkpoint/sasrec_validation_selected.pt > reruns/rank-depths.jsonl
```

`round5/round5_chronological.py` constructs the cutoff experiment and fits its separate predictor. The `round4/` controls use the five-route study's dataset splits. `outputs/digest_dependency_ablation.py` runs the supplementary DIGEST gate experiments with prepared Baby, Sports, or Clothing inputs and the matching local checkpoint.

## Recorded results

- `round2/evidence/round1/` contains the five-route, full-catalogue logs and separate initialization measurements.
- `round11/evidence/long_replay/` and `round12/evidence/music_replay/` contain four matched timing blocks each, all route-window records, and separate graph and ranking verifications.
- `round3/evidence/long/` contains the three-start Full Sort comparison. `round4/evidence/balanced/` contains its separate counterbalanced control.
- `round5/evidence/chronological.jsonl` and the `round8/` and `round9/` reports record the strict future-item comparison and the first-interaction subset.
- `results/historical/` preserves the observations for the historical, memory, and DIGEST protocols. `results/provenance/` documents the paired Yelp window replay and the calibration-file fingerprints. The distributed calibration and early diagnostic text files retain the original JSON observations and omit a machine-specific runtime message.
