"""Check the identity of the local replay inputs."""
from argparse import ArgumentParser
from hashlib import file_digest
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("root", type=Path, nargs="?", default=ROOT)
    parser.add_argument("--prefix", default="work/saeif/casg/", help="relative manifest path prefix")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "data/input_sha256.json").read_text(encoding="utf-8"))
    selected = {name: sha for name, sha in manifest.items() if name.startswith(args.prefix)}
    if not selected:
        parser.error(f"No manifest entries match {args.prefix!r}")
    failures = []
    for name, expected in selected.items():
        path = args.root / name
        if not path.is_file():
            failures.append(f"Missing: {name}")
            continue
        with path.open("rb") as stream:
            if file_digest(stream, "sha256").hexdigest() != expected:
                failures.append(f"SHA-256 mismatch: {name}")
    if failures:
        raise SystemExit("\n".join(failures))
    print(f"Verified {len(selected)} input files.")


if __name__ == "__main__":
    main()
