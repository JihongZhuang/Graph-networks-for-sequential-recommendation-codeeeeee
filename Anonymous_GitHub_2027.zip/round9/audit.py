"""Validate paired timing and regenerate rank-depth summaries from raw records."""

import csv
import json
from pathlib import Path
from statistics import mean, median


HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
DATA = HERE/'evidence'


def records(path):
    return [json.loads(line) for line in path.read_text(encoding='utf-8-sig').splitlines() if line.startswith('{')]


def write_csv(name, rows):
    with (DATA/name).open('w',encoding='utf-8',newline='') as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def timed_pairs():
    source=records(ROOT/'round5/evidence/counts_baseline.jsonl')
    setups={r['repeat']:r for r in source if r['kind']=='setup'}
    grouped={j:[r for r in source if r['kind']=='window' and r['repeat']==j] for j in setups}
    routes=('recount','counts_rebuild','affected_rows','view','CINM')
    old={(int(r['repeat']),r['route']):r for r in csv.DictReader(
        (ROOT/'round8/evidence/count_reuse_repeats.csv').open(encoding='utf-8'))}
    rows=[]
    for j,windows in sorted(grouped.items()):
        assert [r['window'] for r in windows]==list(range(1,7))
        assert [r['batch'] for r in windows]==source[0]['batches']
        for route in routes:
            init=setups[j]['setup_ms'][route]/1000
            prefix=setups[j]['common_counts_ms']/1000 if route!='recount' else 0.
            phases=[r['routes'][route] for r in windows]
            assert all(abs(r['count_ms']+r['graph_ms']-r['total_ms'])<1e-7 for r in phases)
            assert all(r['operator_max_error']<1e-14 for r in phases)
            count=sum(r['count_ms'] for r in phases)/1000
            graph=sum(r['graph_ms'] for r in phases)/1000
            row=dict(repeat=j,route=route,prefix_s=prefix,index_s=init-prefix,init_s=init,
                     count_update_s=count,graph_update_s=graph,update_s=count+graph,total_s=init+count+graph)
            assert all(abs(v-float(old[j,route][k]))<1e-8 for k,v in row.items() if k not in ('repeat','route'))
            rows.append(row)
    write_csv('count_reuse_verified.csv',rows)
    by_key={(r['repeat'],r['route']):r for r in rows}
    paired=[by_key[j,'affected_rows']['total_s']-by_key[j,'view']['total_s'] for j in sorted(setups)]
    assert [round(x,2) for x in paired]==[9.70,0.48,1.50]
    assert round(mean(paired),2)==3.89 and round(median(paired),2)==1.50
    return dict(savings_s=paired,mean_s=mean(paired),median_s=median(paired),first_share=paired[0]/sum(paired))


def long_pairs():
    protocols={}
    for label, folder, repeats in [('original','round3/evidence/long',3),('balanced','round4/evidence/balanced',4)]:
        pairs=[]
        for j in range(1,repeats+1):
            pair={}
            for route in ('affected_rows','view'):
                raw=records(ROOT/folder/f'r{j}_{route}.jsonl')
                meta=next(r for r in raw if r['kind']=='metadata')
                windows=[r for r in raw if r['kind']=='window']
                assert len(windows)==24 and meta['stop']-meta['start']==24000
                assert [r['end'] for r in windows]==list(range(meta['start']+1000,meta['stop']+1,1000))
                init=meta['initialization_ms']/1000
                update=sum(r['graph_ms'] for r in windows)/1000
                pair[route]=dict(init_s=init,update_s=update,total_s=init+update)
            pairs.append(pair)
        net=[p['affected_rows']['total_s']-p['view']['total_s'] for p in pairs]
        protocols[label]=dict(pairs=pairs,net_s=net,mean_s=mean(net),
            percent=100*mean(net)/mean(p['affected_rows']['total_s'] for p in pairs))
    order=json.loads((ROOT/'round4/evidence/balanced/protocol.json').read_text(encoding='utf-8'))['orders']
    assert [o[0] for o in order]==['affected_rows','view','affected_rows','view']
    assert round(protocols['original']['mean_s'],2)==9.73 and round(protocols['original']['percent'],1)==38.1
    assert round(protocols['balanced']['mean_s'],2)==10.44 and min(protocols['balanced']['net_s'])>0
    protocols['balanced']['orders']=order
    return protocols


def full_recommendation():
    raw=records(ROOT/'round2/evidence/round1/Yelp2018_matched.jsonl' if
                (ROOT/'round2/evidence/round1/Yelp2018_matched.jsonl').is_file() else
                ROOT/'evidence/round1/Yelp2018_matched.jsonl')
    results={}
    for route in ('full_rebuild','view'):
        init=[r['prefix_ms']+r['index_ms'] for r in raw if r['kind']=='initialization' and r['route']==route]
        windows=[r['routes'][route]['total_ms'] for r in raw if r['kind']=='window']
        assert len(init)==3 and len(windows)==18
        results[route]=(sum(init)+sum(windows))/1000
    percent=100*(1-results['view']/results['full_rebuild'])
    assert round(percent,2)==27.84
    return dict(totals_s=results,percent=percent)


def rank_depths():
    all_records=records(DATA/'rank_depths.jsonl')
    windows=[r for r in all_records if r['kind']=='window']
    assert len(windows)==6 and all(r['full_cohort_replay_matches'] for r in windows)
    old_first=[r for r in records(ROOT/'round8/evidence/first_future.jsonl') if r['kind']=='window']
    old_full=[r for r in records(ROOT/'round5/evidence/chronological.jsonl') if r['kind']=='window']
    cohorts={'eligible':old_full,'first':old_first}
    rows=[]
    for cohort,previous in cohorts.items():
        for window,old in zip(windows,previous,strict=True):
            result=window[cohort]
            assert (old['window'],old['batch'],old['users'])==(window['window'],window['batch'],result['users'])
            n=result['users']
            assert [result['prefix_changes'][str(k)] for k in (1,5,10)]==sorted(result['prefix_changes'].values())
            assert result['prefix_changes']['10']<=result['changed_lists']
            row=dict(cohort=cohort,window=window['window'],batch=window['batch'],users=n,
                     **{f'top{k}_change_pct':100*result['prefix_changes'][str(k)]/n for k in (1,5,10)},
                     top20_order_pct=100*result['changed_lists']/n,top20_set_pct=100*result['changed_sets']/n)
            for key in ('changed_lists','changed_sets','jaccard_sum','shared_items','absolute_shared_rank_shift'):
                assert abs(old[key]-result[key])<1e-10
            for metric, delta in result['paired_quality'].items():
                assert delta['positive']+delta['negative']+delta['unchanged']==n
                assert abs(delta['mean_pp']-100*(old['fresh'][metric]-old['stale'][metric]))<1e-10
                row.update({f'{metric}_{k}':v for k,v in delta.items()})
            rows.append(row)
    write_csv('rank_depth_windows.csv',rows)
    pct_fields=('top1_change_pct','top5_change_pct','top10_change_pct','top20_order_pct','top20_set_pct')
    metrics=('recall_10','ndcg_10','recall_20','ndcg_20')
    pooled=[]
    for cohort in cohorts:
        for size in (10,100,1000):
            group=[r for r in rows if r['cohort']==cohort and r['batch']==size]
            assert len(group)==2 and group[0]['users']==group[1]['users']
            pooled.append(dict(cohort=cohort,batch=size,queries=sum(r['users'] for r in group),
                               **{k:mean(r[k] for r in group) for k in pct_fields},
                               **{k:mean(r[f'{k}_mean_pp'] for r in group) for k in metrics}))
    write_csv('rank_depth_pooled.csv',pooled)
    tex=[]
    for r in pooled:
        line=[r['cohort'].capitalize(),f"{r['batch']:,}",*(f'{r[k]:.2f}' for k in pct_fields),
              f"{r['recall_10']:+.4f}",f"{r['ndcg_10']:+.4f}"]
        tex.append(' & '.join(line)+r' \\')
    (HERE/'latex/round9_depth_rows.tex').write_text('\n'.join([*tex,r'\bottomrule'])+'\n',encoding='utf-8')
    return pooled


if __name__=='__main__':
    short=timed_pairs()
    long=long_pairs()
    depths=rank_depths()
    csr=records(DATA/'csr_audit.jsonl')
    assert len(csr)==8 and all(r['structure_equal'] and r['explicit_zeros']==0 and r['operator_max_error']==0 for r in csr)
    audit=dict(count_reuse=short,long=long,full_recommendation=full_recommendation(),rank_depths=depths,csr=csr)
    (DATA/'round9_audit.json').write_text(json.dumps(audit,indent=2)+'\n',encoding='utf-8')
