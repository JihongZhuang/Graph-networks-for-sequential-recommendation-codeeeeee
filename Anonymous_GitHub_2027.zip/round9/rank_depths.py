"""Extend the audited checkpoint replay to paired rank-depth sensitivity."""

from argparse import ArgumentParser
from collections import Counter, defaultdict
from hashlib import file_digest
from math import comb
import gzip
import json
from pathlib import Path

import numpy as np
from numpy.polynomial import Polynomial
from threadpoolctl import threadpool_limits
import torch

from round5_chronological import CUTOFF, prepare, quality, ranking_sensitivity
from casg_major_revision import emit, rebuild
from exact_polynomial import full_layers, polynomial
from integration_casg import append_merged, rank_checked
from saeif_casg_pilot import append
from saeif_casg_sasrec import SampledProjection, author_model


def audit_targets(raw, targets):
    with gzip.open(raw, 'rt', encoding='utf-8') as handle:
        records = [(int(r['unixReviewTime']), r['reviewerID'], r['asin'])
                   for line in handle if (r := json.loads(line))]
    records.sort(key=lambda r: r[0])
    pre = [r for r in records if r[0] <= CUTOFF]
    initial = pre[:-4000]
    user_ids = {u: j for j, u in enumerate(sorted({u for _, u, _ in pre}))}
    counts = Counter(u for _, u, _ in initial)
    last = {u: j for j, (_, u, _) in enumerate(initial) if counts[u] >= 3}
    catalog = sorted({i for j, (_, u, i) in enumerate(initial) if last.get(u) != j})
    raw_targets = {u: catalog[i] for u, i in targets.items()}
    skipped = Counter()
    first_times, target_times = {}, {}
    for time, user, item in records[len(pre):]:
        uid = user_ids.get(user)
        if uid not in raw_targets or uid in target_times:
            continue
        first_times.setdefault(uid, time)
        if item == raw_targets[uid]:
            target_times[uid] = time
        else:
            skipped[uid] += 1
    assert target_times.keys() == targets.keys() and min(target_times.values()) > CUTOFF
    quantiles = [0, 25, 50, 75, 90, 95, 100]
    days = np.asarray([(t - CUTOFF) / 86400 for t in target_times.values()])
    first = set(targets).difference(skipped)
    emit(kind='target_audit', cohort=len(targets), first=len(first), skipped_users=len(skipped),
         skipped_total=sum(skipped.values()), skipped_mean=sum(skipped.values())/len(targets),
         skipped_mean_conditional=sum(skipped.values())/len(skipped),
         skipped_histogram=dict(Counter(skipped.get(u, 0) for u in targets)),
         skipped_on_same_timestamp=sum(first_times[u] == target_times[u] for u in skipped),
         target_days=dict(zip(quantiles, np.percentile(days, quantiles).tolist())),
         target_days_mean=float(days.mean()),
         target_days_first=dict(zip(quantiles, np.percentile(
             [(target_times[u]-CUTOFF)/86400 for u in first], quantiles).tolist())))
    return first, target_times


def paired_report(stale, fresh, targets):
    quality_deltas = {}
    for k in (10,20):
        before = stale[:, :k] == targets[:, None]
        after = fresh[:, :k] == targets[:, None]
        discounts = 1 / np.log2(np.arange(2,k+2))
        for metric, delta in (('recall', after.sum(axis=1)-before.sum(axis=1)),
                              ('ndcg', (after-before.astype(int))@discounts)):
            quality_deltas[f'{metric}_{k}'] = dict(mean_pp=float(delta.mean()*100),
                positive=int((delta>0).sum()),negative=int((delta<0).sum()),unchanged=int((delta==0).sum()))
    return dict(users=len(targets), **ranking_sensitivity(stale,fresh),
                prefix_changes={k:int(np.any(stale[:, :k]!=fresh[:, :k],axis=1).sum()) for k in (1,5,10)},
                paired_quality=quality_deltas)


def run(args):
    previous = [json.loads(line) for line in args.prior.read_text(encoding='utf-8-sig').splitlines()
                if line.startswith('{')]
    _, events, _, targets, inputs, meta = prepare(args.raw)
    assert meta['raw_sha256'] == previous[0]['raw_sha256']
    first, target_times = audit_targets(args.raw, targets)
    assert (min(target_times.values()),max(target_times.values())) == (meta['target_min'],meta['target_max'])
    with args.checkpoint.open('rb') as handle:
        digest = file_digest(handle, 'sha256').hexdigest()
    assert digest == next(r['sha256'] for r in previous if r['kind'] == 'checkpoint')
    emit(kind='configuration', cutoff=CUTOFF, raw_sha256=meta['raw_sha256'], checkpoint_sha256=digest,
         items=len(inputs), features=inputs.shape[1], users=len(targets), batches=meta['batches'])
    coef = next(r['coefficients'] for r in previous if r['kind'] == 'filter_fit')
    p, q = Polynomial([.5,.5]), Polynomial([.5,-.5])
    poly = sum(w*comb(2,k)*p**k*q**(2-k) for k,w in enumerate(coef)).coef

    def features(operator):
        z = polynomial(full_layers(operator,inputs,2),poly)
        isolated = np.diff(operator.indptr) == 0
        z[isolated] = inputs[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(z).float())

    begin = meta['prefix']
    counts, histories = Counter(), defaultdict(list)
    append(events[:begin],counts,histories)
    stale = features(rebuild(events[:begin],len(inputs))[0])
    # The scorer writes into its feature buffer. Keep the replay's stale tensor independent.
    model = author_model(stale.clone())
    model.in_proj = SampledProjection(model.in_proj,len(inputs))
    model.load_state_dict(torch.load(args.checkpoint, weights_only=True))
    users = np.asarray(sorted(targets))
    test = np.asarray([targets[u] for u in users])
    subset = np.asarray([u in first for u in users])
    archive = [r for r in previous if r['kind'] == 'window']
    for record in archive:
        end = begin + record['batch']
        assert events[end-1][2] == record['graph_max'] <= CUTOFF
        append_merged(events[begin:end],counts,histories)
        fresh = features(rebuild(events[:end],len(inputs))[0])
        a, _, _, _ = rank_checked(model,stale,histories,users,targets)
        b, _, _, _ = rank_checked(model,fresh,histories,users,targets)
        for route, scores in (('stale', a), ('fresh', b)):
            for metric, value in quality(scores,test).items():
                assert np.isclose(value,record[route][metric],rtol=0,atol=1e-13), (
                    record['window'], route, metric, value, record[route][metric])
        for key, value in ranking_sensitivity(a,b).items():
            assert np.isclose(value,record[key],rtol=0,atol=1e-10), key
        emit(kind='window', window=record['window'], batch=record['batch'],
             eligible=paired_report(a,b,test), first=paired_report(a[subset],b[subset],test[subset]),
             full_cohort_replay_matches=True)
        stale, begin = fresh, end
    emit(kind='complete', windows=len(archive), users=len(first), query_windows=len(first)*len(archive))


if __name__ == '__main__':
    parser = ArgumentParser()
    for option in ('raw','prior','checkpoint'):
        parser.add_argument('--'+option, type=Path, required=True)
    torch.set_num_threads(4)
    with threadpool_limits(limits=4):
        run(parser.parse_args())
