"""Audit edge changes, explicit zeros and structural equality of the frozen kernels."""

from collections import Counter
import numpy as np
from scipy.sparse import isspmatrix_csr

from casg_major_revision import INDEXES, emit, maintain
from saeif_casg_pilot import normalized


def check():
    counts = Counter({(0,1):2})
    counts.update({(i,j):10 for i in (0,1) for j in range(2,21)})
    added, removed, degree_only = (0,21), (0,1), (0,2)
    changed = {added,(1,22)}
    updated = counts + Counter({pair:4 for pair in changed})
    for route, constructor in INDEXES.items():
        for kernel in ('timed_maintain','index_update'):
            state = constructor(counts,23)
            before = state.operator
            assert all(before[pair] != 0 for pair in (removed,degree_only))
            assert before[added] == 0
            result = (maintain(state,updated,changed)[0] if kernel == 'timed_maintain'
                      else state.update(updated,changed)[0])
            reference = normalized(updated,23)
            assert isspmatrix_csr(result) and result.has_canonical_format
            explicit_zeros = int(np.count_nonzero(result.data == 0))
            assert explicit_zeros == 0 and result.nnz == reference.nnz
            assert np.array_equal(result.indptr,reference.indptr)
            assert np.array_equal(result.indices,reference.indices)
            assert removed[1] not in result.indices[result.indptr[removed[0]]:result.indptr[removed[0]+1]]
            error = float(np.max(np.abs((reference-result).data),initial=0))
            assert result[added] > 0 and result[removed] == 0 and result[degree_only] != before[degree_only]
            assert updated[degree_only] == counts[degree_only] and error < 1e-14
            assert (result-result.T).nnz == 0
            emit(route=route,kernel=kernel,operator_max_error=error,added=float(result[added]),
                 removed=float(result[removed]), degree_only_before=float(before[degree_only]),
                 degree_only_after=float(result[degree_only]),explicit_zeros=explicit_zeros,
                 csr_nnz=int(result.nnz),reference_nnz=int(reference.nnz),structure_equal=True)


if __name__ == '__main__':
    check()
