"""Redraw the six CASG figures from archived observations."""
import csv
import json
from pathlib import Path

import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.ticker import FixedLocator, FuncFormatter, NullLocator
import numpy as np

ROOT = Path(__file__).resolve().parent
DATA = ROOT / "figure_data"
FIGURES = ROOT / "generated_figures"
FIGURES.mkdir(exist_ok=True)
mpl.rcParams.update({
    "font.family": ["Arial", "DejaVu Sans"], "font.size": 7,
    "axes.labelsize": 7, "axes.titlesize": 7, "xtick.labelsize": 6.5,
    "ytick.labelsize": 6.5, "legend.fontsize": 6.5, "axes.linewidth": 0.6,
    "axes.spines.top": False, "axes.spines.right": False,
    "xtick.major.size": 2.5, "ytick.major.size": 2.5, "xtick.major.width": 0.6,
    "ytick.major.width": 0.6, "axes.unicode_minus": True,
    "pdf.fonttype": 42, "svg.fonttype": "none", "savefig.facecolor": "white",
})

PALETTE = {
    "coral": "#E6846D",
    "blush": "#F9BEBB",
    "pale_blush": "#FFE5E1",
    "aqua": "#8DCDD5",
    "teal": "#89C9C8",
    "pale_aqua": "#E1F6F6",
}


def darken(color, amount):
    return mpl.colors.to_hex(tuple(value * (1 - amount) for value in mpl.colors.to_rgb(color)))


METHODS = {
    "full_rebuild": ("Full rebuild", "#474B50", 0.00, "x", (0, (4, 2))),
    "affected_rows": ("Affected rows", PALETTE["blush"], 0.39, "D", (0, (1.5, 2))),
    "partial": ("Partial Top-K", PALETTE["pale_aqua"], 0.55, "s", (0, (4, 2))),
    "ordered": ("Full Order", PALETTE["aqua"], 0.33, "v", (0, (4, 2, 1, 2))),
    "view": ("Bounded View", PALETTE["teal"], 0.27, "o", "-"),
    "CINM": ("CINM", PALETTE["coral"], 0.20, "^", (0, (5, 2))),
}
BANDS = {
    "full_rebuild": ("#DDE0E2", 0.58),
    "affected_rows": (PALETTE["blush"], 0.29),
    "partial": (PALETTE["aqua"], 0.26),
    "view": (PALETTE["pale_aqua"], 0.94),
    "CINM": (PALETTE["pale_blush"], 0.86),
}
DATASETS = {
    "Luxury_Beauty": "Luxury Beauty",
    "Musical_Instruments": "Musical Instruments",
    "Yelp2018_matched": "Yelp2018",
}
POINTS = []


def csv_rows(name):
    with (DATA / name).open(encoding="utf-8-sig", newline="") as stream:
        return list(csv.DictReader(stream))


def json_data(name):
    return json.loads((DATA / name).read_text(encoding="utf-8"))


def panel_label(axis, letter, title):
    axis.text(0, 1.08, letter, transform=axis.transAxes, va="baseline",
              ha="left", fontsize=8, fontweight="bold")
    axis.text(0.10, 1.08, title, transform=axis.transAxes, va="baseline", ha="left")


def panels(titles, height_mm, left, bottom, top, gap):
    fig, axs = plt.subplots(1, len(titles), figsize=(183/25.4, height_mm/25.4),
                            squeeze=False)
    axes = axs[0]
    fig.subplots_adjust(left=left, right=0.974, bottom=bottom, top=top, wspace=gap)
    if len(axes) > 1:
        for letter, axis, title in zip("abc", axes, titles):
            panel_label(axis, letter, title)
    return fig, axes


def key(fig, routes, *, lines=False):
    handles = []
    for route in routes:
        label, fill, depth, shape, line = METHODS[route]
        stroke = darken(fill, depth)
        handles.append(Line2D([], [], color=stroke, marker=shape, markersize=4.0,
                              markerfacecolor=fill, markeredgecolor=stroke,
                              markeredgewidth=0.8, linestyle=line if lines else "none",
                              linewidth=1.2, label=label))
    fig.legend(handles=handles, loc="lower center", bbox_to_anchor=(0.5, 0.014),
               ncol=len(routes), frameon=False, handlelength=2.15, columnspacing=1.35)


def axis_reference(axis, value, orientation):
    if orientation == "x":
        axis.axvline(value, color="#737A80", lw=0.65, ls=(0, (2, 2)), zorder=1)
    else:
        axis.axhline(value, color="#737A80", lw=0.65, ls=(0, (2, 2)), zorder=1)


def ring(axis, x, y, size=9.5):
    axis.plot(x, y, marker="o", ls="none", ms=size, mfc="none", mec="#24282C",
              mew=0.7, zorder=9)


def row_interval(axis, y, samples, route, *, selected=False):
    _, fill, depth, shape, _ = METHODS[route]
    stroke = darken(fill, depth)
    center = samples.mean()
    low, high = samples.min(), samples.max()
    axis.errorbar(center, y, xerr=[[center-low], [high-center]], fmt=shape,
                  ms=4.1, color=stroke, lw=0.9, capsize=1.8, capthick=0.75,
                  markerfacecolor=fill, markeredgecolor=stroke, markeredgewidth=0.75,
                  zorder=3)
    if selected:
        ring(axis, center, y, size=7.4)


def save(fig, name):
    fig.canvas.draw()
    fig.savefig(FIGURES / f"{name}.pdf", metadata={"CreationDate": None, "ModDate": None})
    fig.savefig(FIGURES / f"{name}.svg")
    fig.savefig(FIGURES / f"{name}.png", dpi=600)
    fig.savefig(FIGURES / f"{name}.tiff", dpi=600, pil_kwargs={"compression":"tiff_lzw"})
    plt.close(fig)


def track(figure, panel, dataset, method, repeat, position, value):
    POINTS.append({"figure":figure, "panel":panel, "dataset":dataset,
                   "route":method, "repeat":repeat, "position":position, "value":value})


def relative_costs():
    name = "casg_costs"
    summary = json_data("five_route_summary.json")
    windows = csv_rows("five_route_windows.csv")
    totals = {}
    for row in windows:
        group = (row["dataset"], row["route"], int(row["repeat"]))
        totals.setdefault(group, []).append(float(row["graph_ms"]) + float(row["history_ms"]))
    routes = ("full_rebuild", "affected_rows", "ordered", "view", "CINM")
    repeat_ids = (1, 2, 3)
    fig, axes = panels(("Graph and history", "Full recommendation"), 84, .155, .235, .885, .20)
    group_positions = [2, 8, 14]
    right_samples = []
    left_samples = []
    for (dataset, _), base_y in zip(DATASETS.items(), group_positions):
        graph = {}
        complete = {}
        for route in routes:
            groups = [totals[dataset,route,r] for r in repeat_ids]
            if any(len(group)!=6 for group in groups):
                raise ValueError("Each timing repeat must contain six windows")
            graph[route] = np.array([sum(group) for group in groups])
            complete[route] = np.asarray(summary[dataset]["routes"][route]["cold_repeats_s"])
        for panel, (axis, timings) in enumerate(zip(axes, (graph, complete))):
            baseline = timings["full_rebuild"]
            if not (baseline > 0).all():
                raise ValueError("Paired timing denominators must be positive")
            ratios = {route:timings[route]/baseline for route in routes}
            if any(len(v)!=3 or not np.isfinite(v).all() or (v <= 0).any() for v in ratios.values()):
                raise ValueError("Timing ratios must be finite and strictly positive")
            winner = min(routes, key=lambda route:ratios[route].mean())
            for offset, route in enumerate(routes, -2):
                samples = ratios[route]
                row_interval(axis, base_y + offset * .66, samples, route,
                             selected=route==winner)
                (left_samples if panel==0 else right_samples).extend(samples)
                for rep, value in zip(repeat_ids, samples):
                    track(name,"ab"[panel],dataset,route,rep,"ratio",value)
    for i, axis in enumerate(axes):
        axis.set_ylim(16.2, -0.2)
        axis.set_yticks(group_positions, DATASETS.values() if i==0 else [""]*3)
        axis.set_xlabel("Time / paired full rebuild")
        axis_reference(axis, 1, "x")
    axes[0].set_xscale("log")
    ticks = [v for v in (.003, .01, .03, .1, .3, 1) if v >= min(left_samples)/2.8]
    axes[0].xaxis.set_major_locator(FixedLocator(ticks))
    axes[0].xaxis.set_minor_locator(NullLocator())
    axes[0].xaxis.set_major_formatter(FuncFormatter(lambda x,_:f"{x:g}"))
    axes[0].set_xlim(min(ticks[0]*.94, min(left_samples)*.85), 1.16)
    axes[1].set_xlim(min(0.54, min(right_samples)-.025), max(1.03,max(right_samples)+.025))
    key(fig, routes)
    save(fig, name)


def trajectories(historical):
    name = "casg_long_amortization" if historical else "casg_partial_cumulative"
    source = "historical_cumulative.csv" if historical else "yelp_cumulative.csv"
    rows = csv_rows(source)
    reference = "affected_rows" if historical else "partial"
    routes = (("full_rebuild","affected_rows","view","CINM") if historical else
              ("affected_rows","partial","view","CINM"))
    repeat_ids = sorted({int(row["repeat"]) for row in rows})
    expected_repeats = 3 if historical else 4
    if len(repeat_ids) != expected_repeats:
        raise ValueError("Unexpected count of timing repeats")
    batches = np.arange(25)
    by_key = {(row["route"],int(row["repeat"]),int(row["batch"])):
              float(row["cumulative_s"]) for row in rows}
    if len(rows) != len(by_key) or len(by_key)!=len(routes)*len(repeat_ids)*len(batches):
        raise ValueError("Incomplete cumulative timing grid")
    cost = {route:np.array([[by_key[route,rep,batch] for batch in batches]
                           for rep in repeat_ids]) for route in routes}
    if any(not np.isfinite(matrix).all() or np.any(np.diff(matrix)<0) for matrix in cost.values()):
        raise ValueError("Cumulative time must be finite and nondecreasing")
    savings = {route:cost[reference]-cost[route] for route in ("view","CINM")}
    fig, (a,b,c) = panels(("Cumulative cost","Paired saving","Saving at batch 24"),
                          70, .080, .265, .847, .50)
    fastest = min(routes, key=lambda route:cost[route][:,-1].mean())
    best_saving = max(savings, key=lambda route:savings[route][:,-1].mean())
    for route, matrix in cost.items():
        _, fill, depth, shape, ls = METHODS[route]
        stroke = darken(fill, depth)
        band, opacity = BANDS[route]
        a.fill_between(batches, matrix.min(axis=0), matrix.max(axis=0),
                       color=band, alpha=opacity, lw=0)
        a.plot(batches, matrix.mean(axis=0), color=stroke, ls=ls, lw=1.28,
               marker=shape, markerfacecolor=fill, markeredgecolor=stroke,
               markevery=[0, 12, 24], ms=2.8, mew=.65)
        for rep, observed in zip(repeat_ids,matrix):
            for batch, value in zip(batches,observed):
                track(name,"a","Yelp2018",route,rep,batch,value)
    for row, (route, matrix) in enumerate(savings.items()):
        _, fill, depth, _, ls = METHODS[route]
        stroke = darken(fill, depth)
        for rep, observed in zip(repeat_ids,matrix):
            b.plot(batches, observed, color=stroke, alpha=.33, lw=.65)
            for batch, value in zip(batches,observed):
                track(name,"b","Yelp2018",route,rep,batch,value)
            track(name,"c","Yelp2018",route,rep,24,observed[-1])
        b.plot(batches, matrix.mean(axis=0), color=stroke, ls=ls, lw=1.4, zorder=5)
        final = matrix[:,-1]
        row_interval(c,row,final,route,selected=route==best_saving)
        for offset,value in zip(np.linspace(-.18,.18,len(final)), final):
            c.plot(value,row+offset,marker=".",ms=3.4,ls="none",color=stroke,alpha=.68)
    ring(a, 24, cost[fastest][:,-1].mean(), size=7.2)
    for axis in (a,b):
        axis.set(xlabel="Update batch (0 = setup)", xlim=(-.5,25))
        axis.set_xticks((0,6,12,18,24))
    a.set(ylabel="Cumulative graph time (s)", ylim=(0,None) if historical else (9,32))
    b.set_ylabel(("Affected rows" if historical else "Partial Top-K") + " minus route (s)")
    axis_reference(b,0,"y")
    c.set(xlabel="Paired net saving (s)", ylim=(1.52,-.55),
          xlim=(min(0,min(min(v[:,-1]) for v in savings.values())-.5),
                max(max(v[:,-1]) for v in savings.values())+1.2))
    c.set_yticks([0,1],["View","CINM"])
    axis_reference(c,0,"x")
    key(fig,routes,lines=True)
    save(fig,name)


def memory_cost():
    name="casg_memory"
    records = {(r["measurement"],r["dataset"],r["route"]):float(r["value"])
               for r in csv_rows("archived_memory.csv")}
    routes = ("ordered","view","CINM")
    fig, axes=panels(("Process memory","Ranking state"), 65, .155, .285, .85, .19)
    for panel, (axis, measure, scale) in enumerate(zip(axes,
            ("isolated process peak MiB", "ranked keys at common initial prefix"),(1,1e6))):
        for y,dataset in enumerate(DATASETS):
            values=np.array([records[measure,dataset,route]/scale for route in routes])
            offsets=(-.22,0,.22)
            for offset,route,value in zip(offsets,routes,values):
                row_interval(axis,y+offset,np.array([value]),route,selected=value==min(values))
                track(name,"ab"[panel],dataset,route,"",measure,value)
        axis.set(ylim=(2.55,-.55),xlim=((-0.027*axis.get_xlim()[1]),None))
        axis.set_yticks(range(3),DATASETS.values() if panel==0 else [""]*3)
    axes[0].set_xlabel("Peak working set (MiB)")
    axes[1].set_xlabel("Ranked keys (millions)")
    key(fig,routes)
    save(fig,name)


def validation_curve():
    name="casg_luxury_validation"
    rows=csv_rows("luxury_validation_curve.csv")
    epoch=np.array([int(r["epoch"]) for r in rows])
    ndcg=np.array([float(r["validation_ndcg5"]) for r in rows])
    if not np.array_equal(epoch,np.arange(1,len(epoch)+1)) or not np.isfinite(ndcg).all():
        raise ValueError("Checkpoint curve is incomplete")
    best=int(np.argmax(ndcg))
    fig, axes=panels(("",), 51, .105, .235, .91, 0)
    axis=axes[0]
    axis.axvspan(.5,8,color=PALETTE["pale_aqua"],zorder=0)
    coral_stroke = darken(PALETTE["coral"], 0.20)
    axis.plot(epoch,ndcg,marker=".",ms=3,ls="-",lw=1.22,color=coral_stroke,
              markerfacecolor=PALETTE["coral"],zorder=3)
    axis_reference(axis,8,"x")
    axis.text(9,.285,"Eight-epoch reference",va="bottom")
    axis.text(43.5,.3215,f"Selected epoch {epoch[best]} ({ndcg[best]:.4f})",
              ha="right",va="center")
    ring(axis,epoch[best],ndcg[best],size=8.0)
    axis.set(xlabel="Training epoch",ylabel="Validation NDCG@5",
             xlim=(0,49),ylim=(.28,.343))
    axis.set_xticks([0,8,16,24,32,40,48])
    axis.set_yticks([.28,.30,.32,.34])
    for e,value in zip(epoch,ndcg):
        track(name,"","Luxury_Beauty","predictor",1,e,value)
    save(fig,name)


def historical_ratios():
    name="casg_graph_and_total"
    historical=json_data("historical_ratio_summary.json")["casg"]["datasets"]
    routes=("affected_rows","CINM")
    fields=("indexed","CINM")
    fig,axes=panels(("Graph maintenance","Complete recommendation"), 59, .155, .29, .85, .19)
    for panel, axis in enumerate(axes):
        axis_reference(axis,1,"x")
        for y,dataset in enumerate(DATASETS):
            record=historical[dataset]
            def time(field):
                entry=record[field]
                return entry["sums_ms"]["graph_ms"] if panel==0 else entry["seconds"]
            baseline=time("full")
            if not np.isfinite(baseline) or baseline<=0:
                raise ValueError("Historical rebuild reference must be positive")
            ratios=[time(field)/baseline for field in fields]
            axis.hlines(y,min(ratios),max(ratios),color=PALETTE["aqua"],lw=.7,zorder=1)
            for route,ratio in zip(routes,ratios):
                row_interval(axis,y,np.array([ratio]),route,selected=ratio==min(ratios))
                track(name,"ab"[panel],dataset,route,"","ratio",ratio)
        axis.set(xlabel="Time / full rebuild",xlim=(-.015,1.08),ylim=(2.58,-.58))
        axis.set_yticks(range(3),DATASETS.values() if panel==0 else [""]*3)
    key(fig,routes)
    save(fig,name)


if __name__=="__main__":
    relative_costs()
    trajectories(False)
    memory_cost()
    validation_curve()
    historical_ratios()
    trajectories(True)
    with (FIGURES / "plotted_observations.csv").open("w",encoding="utf-8",newline="") as stream:
        writer=csv.DictWriter(stream,fieldnames=list(POINTS[0]))
        writer.writeheader()
        writer.writerows(POINTS)