"""Summarize the global-time check and the separate graph-only baseline."""

import csv
from datetime import datetime, timezone
from hashlib import file_digest
import json
from pathlib import Path
import re
from statistics import mean


ROOT=Path(__file__).resolve().parent
EVIDENCE=ROOT/"evidence"
LATEX=ROOT/"latex"
ROUTES={"recount":"Recount + full graph","counts_rebuild":"Incremental counts + full graph",
        "affected_rows":"Affected rows + local","view":"Bounded view + local","CINM":"CINM + local"}


def records(name):
    return [json.loads(s) for s in (EVIDENCE/name).read_text(encoding="utf-8-sig").splitlines() if s.startswith("{")]


def table(name,rows):
    (LATEX/name).write_text("\n".join(
        [" & ".join(map(str,row))+r" \\" for row in rows]+[r"\bottomrule"])+"\n",encoding="utf-8")


def csv_out(name,rows):
    with (EVIDENCE/name).open("w",newline="",encoding="utf-8") as handle:
        writer=csv.DictWriter(handle,fieldnames=list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def iso(stamp):
    return datetime.fromtimestamp(stamp,timezone.utc).date().isoformat()


def chronology():
    meta,fit,checkpoint,*windows,end=records("chronological.jsonl")
    assert len(windows)==end["windows"]==6 and end["query_pairs"]==6*meta["users"]
    assert meta["train_max"]<=meta["prefix_max"]<=meta["cutoff"]<meta["target_min"]
    assert meta["text_max"]<=meta["train_max"] and meta["validation_max"]<=meta["prefix_max"]
    assert meta["final_graph_max"]<=meta["cutoff"]
    weight_file=EVIDENCE/"chronological_checkpoint/sasrec_validation_selected.pt"
    if weight_file.is_file():
        with weight_file.open("rb") as handle:
            assert file_digest(handle,"sha256").hexdigest()==checkpoint["sha256"]
    epoch_lines = (EVIDENCE/"chronological.jsonl").read_text(encoding="utf-8-sig").splitlines()
    validation = [(int(m[1]),float(m[2]),float(m[3])) for line in epoch_lines if
                  (m:=re.match(r"^SASRec epoch=(\d+),loss=[\d.]+,valid_ndcg5=([\d.]+),seconds=([\d.]+)$",line))]
    assert len(validation)==meta["epochs"]
    rows=[]
    for j,w in enumerate(windows,1):
        n=w["users"]
        assert w["window"]==j and w["batch"]==meta["batches"][j-1] and n==meta["users"]
        assert 0<=w["changed_sets"]<=w["changed_lists"]<=n
        assert w["graph_max"]<=meta["cutoff"] and w["graph_structure_exact"] and w["operator_max_error"]<1e-14
        assert w["view_top20_matches"]==n and w["features_equal"]
        rows.append(dict(window=j,batch=w["batch"],users=n,graph_latest_utc=iso(w["graph_max"]),
                         list_change_pct=100*w["changed_lists"]/n,set_change_pct=100*w["changed_sets"]/n,
                         jaccard=w["jaccard_sum"]/n,shared_rank_shift=w["absolute_shared_rank_shift"]/w["shared_items"],
                         changed_normalized_pairs=w["normalized_entries"]//2,
                         **{f"{route}_{k}":v for route in ("stale","fresh") for k,v in w[route].items()},
                         **{f"delta_{k}_pp":100*(v-w["stale"][k]) for k,v in w["fresh"].items()}))
    csv_out("chronological_windows.csv",rows)
    groups=[]
    for size in (10,100,1000):
        subset=[r for r in windows if r["batch"]==size]
        n=sum(w["users"] for w in subset)
        groups.append(dict(batch=size,lists=100*sum(w["changed_lists"] for w in subset)/n,
                           sets=100*sum(w["changed_sets"] for w in subset)/n,
                           jaccard=sum(w["jaccard_sum"] for w in subset)/n,
                           shift=sum(w["absolute_shared_rank_shift"] for w in subset)/sum(w["shared_items"] for w in subset),
                           recall_pp=100*mean(w["fresh"]["recall_10"]-w["stale"]["recall_10"] for w in subset),
                           ndcg_pp=100*mean(w["fresh"]["ndcg_10"]-w["stale"]["ndcg_10"] for w in subset)))
    table("round5_chrono_rows.tex",[
        (f'{g["batch"]:,}',f'{g["lists"]:.2f}',f'{g["sets"]:.2f}',f'{g["jaccard"]:.4f}',f'{g["shift"]:.4f}',
         f'{g["recall_pp"]:+.4f}',f'{g["ndcg_pp"]:+.4f}') for g in groups
    ])
    table("round5_chrono_quality_rows.tex",[
        (w["window"],f'{w["batch"]:,}',
         *(f'{100*w[f"{route}_{m}"]:.4f}' for m in ("recall_10","ndcg_10","recall_20","ndcg_20") for route in ("stale","fresh")))
        for w in rows
    ])
    return dict(meta=meta,fit=fit,checkpoint=checkpoint,windows=windows,metrics=rows,groups=groups,
                best_validation=max(validation,key=lambda x:x[1]),
                total_training_seconds=sum(r[2] for r in validation), pairs=end["query_pairs"])


def graph_baseline():
    meta,*runs,end=records("counts_baseline.jsonl")
    setups={r["repeat"]:r["setup_ms"] for r in runs if r["kind"]=="setup"}
    windows=[r for r in runs if r["kind"]=="window"]
    assert len(setups)==3 and len(windows)==end["windows"]==18
    assert all(sorted(w["order"])==sorted(ROUTES) for w in windows)
    assert all(w["batch"]==meta["batches"][w["window"]-1] for w in windows)
    measurements=[]
    for rep in range(1,4):
        group=[w for w in windows if w["repeat"]==rep]
        assert len(group)==6
        for route in ROUTES:
            xs=[w["routes"][route] for w in group]
            assert all(x["operator_max_error"]<1e-14 for x in xs)
            counts,graph=(sum(x[key] for x in xs)/1000 for key in ("count_ms","graph_ms"))
            init=setups[rep][route]/1000
            assert abs(counts+graph-sum(x["total_ms"] for x in xs)/1000)<1e-8
            measurements.append(dict(repeat=rep,route=route,init_s=init,counts_s=counts,graph_s=graph,
                                     total_s=init+counts+graph))
    csv_out("counts_baseline_repeats.csv",measurements)
    results={}
    for route in ROUTES:
        rows=[r for r in measurements if r["route"]==route]
        totals=[r["total_s"] for r in rows]
        results[route]=dict(**{k:mean(r[k] for r in rows) for k in ("init_s","counts_s","graph_s","total_s")},
                            low=min(totals),high=max(totals))
    table("round5_baseline_rows.tex",[
        (ROUTES[route],*(f'{r[k]:.2f}' for k in ("init_s","counts_s","graph_s")),
         f'{r["total_s"]:.2f} [{r["low"]:.2f}, {r["high"]:.2f}]') for route,r in results.items()
    ])
    return dict(meta=meta,measurements=measurements,results=results)


def write_values(time,graph):
    m=time["meta"]
    g=time["groups"]
    q=time["metrics"]
    def extremes(key):
        a=[x[key] for x in q]
        return f"{min(a):+.4f} to {max(a):+.4f}"
    value=dict(
        ChronoUsers=f'{m["users"]:,}',ChronoItems=f'{m["items"]:,}',ChronoPairs=f'{time["pairs"]:,}',
        ChronoTrain=f'{m["train_events"]:,}',ChronoPrefix=f'{m["prefix"]:,}',
        ChronoCutoff=iso(m["cutoff"]),ChronoEarliest=iso(m["target_min"]),ChronoLatest=iso(m["target_max"]),
        ChronoTrainMax=iso(m["train_max"]),ChronoTextMax=iso(m["text_max"]),
        ChronoVal=f'{time["best_validation"][1]:.4f}', ChronoEpoch=time["best_validation"][0],
        ChronoLargeOrdered=f'{g[-1]["lists"]:.2f}',ChronoLargeSets=f'{g[-1]["sets"]:.2f}',
        ChronoLargeJaccard=f'{g[-1]["jaccard"]:.4f}',ChronoLargeShift=f'{g[-1]["shift"]:.4f}',
        ChronoDeltaRecall=extremes("delta_recall_10_pp"),ChronoDeltaNdcg=extremes("delta_ndcg_10_pp"),
    )
    for key, route in (("Recount","recount"),("CountRebuild","counts_rebuild"),
                       ("Affected","affected_rows"),("Bounded","view"),("CINM","CINM")):
        value[f"NewGraph{key}"]=f'{graph["results"][route]["total_s"]:.2f}'
    (LATEX/"round5_values.tex").write_text("\n".join(
        rf"\newcommand{{\{k}}}{{{v}}}" for k,v in value.items())+"\n",encoding="utf-8")


if __name__=="__main__":
    t=chronology()
    g=graph_baseline()
    write_values(t,g)
    (EVIDENCE/"round5_audit.json").write_text(json.dumps(dict(chronology=t,graph_baseline=g),indent=2)+"\n",encoding="utf-8")
