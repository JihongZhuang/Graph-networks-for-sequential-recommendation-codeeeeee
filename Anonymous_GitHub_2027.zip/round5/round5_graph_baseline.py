"""Separate, paired graph-only ablation of count reuse and local maintenance."""

from collections import Counter, defaultdict
import ctypes
from pathlib import Path
import platform

import numpy as np
from threadpoolctl import threadpool_limits

from casg_cinm import load_replay
from casg_major_revision import INDEXES, emit, maintain
from integration_casg import append_merged
from saeif_casg_pilot import append, normalized, timed


ROUTES = ("recount", "counts_rebuild", "affected_rows", "view", "CINM")


def run():
    dataset="Yelp2018_matched"
    folder=Path("work/saeif/casg")/dataset
    events,_,sizes,_,_,n=load_replay(folder,Path("outputs")/f"saceif_general_casg_{dataset}.txt")
    prefix=len(events)-sum(sizes)
    emit(kind="metadata",dataset=dataset,prefix=prefix,stop=len(events),batches=sizes,repeats=3,
         scope="paired graph-only replay; identical global reconstruction kernel with and without count reuse",
         seed=3541,threads=4)
    for repeat in range(1,4):
        counts,histories=Counter(),defaultdict(list)
        _,count_setup=timed(lambda:append(events[:prefix],counts,histories))
        states={}
        starts={"recount":0.,"counts_rebuild":count_setup}
        rng=np.random.default_rng(3541+repeat)
        for route in rng.permutation(ROUTES[2:]):
            state,index_ms=timed(lambda:INDEXES[route](counts,n))
            states[route]=state
            starts[route]=count_setup+index_ms
        emit(kind="setup",repeat=repeat,common_counts_ms=count_setup,setup_ms=starts)
        begin=prefix
        for j,size in enumerate(sizes,1):
            end=begin+size
            changed,append_ms=timed(lambda:append_merged(events[begin:end],counts,histories))
            order=rng.permutation(ROUTES).tolist()
            ops,results={},{}
            for route in order:
                if route=="recount":
                    full=Counter()
                    _,count_ms=timed(lambda:append(events[:end],full,defaultdict(list)))
                    op,graph_ms=timed(lambda:normalized(full,n))
                elif route=="counts_rebuild":
                    count_ms=append_ms
                    op,graph_ms=timed(lambda:normalized(counts,n))
                else:
                    count_ms=append_ms
                    (op,_),graph_ms=timed(lambda:maintain(states[route],counts,changed))
                ops[route]=op
                results[route]=dict(count_ms=count_ms,graph_ms=graph_ms,total_ms=count_ms+graph_ms)
            assert full==counts
            for route,op in ops.items():
                err=float(np.max(np.abs((op-ops["recount"]).data),initial=0))
                assert err<1e-14
                results[route]["operator_max_error"]=err
            emit(kind="window",repeat=repeat,window=j,batch=size,order=order,routes=results)
            begin=end
    emit(kind="complete",windows=18)


if __name__=="__main__":
    if platform.system()=="Windows":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    with threadpool_limits(limits=4):
        run()
