"""Strict global cutoff and paired scoring with the frozen graph kernels."""

import argparse
import ast
from collections import Counter, defaultdict
import ctypes
from datetime import datetime, timezone
import gzip
from hashlib import file_digest
import json
import logging
import math
from pathlib import Path
import platform
from typing import Dict, List, Tuple

import numpy as np
from numpy.polynomial import Polynomial
from scipy import sparse
from sklearn.feature_extraction.text import HashingVectorizer
from threadpoolctl import threadpool_limits
import torch
from torch import nn
import torch.nn.functional as F
from torch.utils.data import DataLoader, Dataset

from casg_major_revision import INDEXES, emit, maintain, rebuild
from casg_revision_sensitivity import ranked_state
from exact_polynomial import full_layers, polynomial
from integration_casg import append_merged, rank_checked
from saeif_casg_pilot import append, timed
from saeif_casg_sasrec import train as fit_sasrec


CUTOFF = int(datetime(2017, 1, 1, tzinfo=timezone.utc).timestamp())
BATCHES = (10, 100, 1000) * 2


def ranking_sensitivity(a, b):
    overlap = a[:, :, None] == b[:, None, :]
    common = overlap.sum(axis=(1, 2))
    distance = np.abs(np.arange(a.shape[1], dtype=np.int8)[:, None] - np.arange(b.shape[1], dtype=np.int8))
    return dict(changed_lists=int(np.any(a != b, axis=1).sum()),
                changed_sets=int((common != a.shape[1]).sum()),
                jaccard_sum=float((common/(2*a.shape[1]-common)).sum()),
                shared_items=int(common.sum()), absolute_shared_rank_shift=int((overlap*distance).sum()))


def quality(top, targets):
    hit = top == targets[:, None]
    discount = 1/np.log2(np.arange(2, top.shape[1]+2))
    return {f"{name}_{k}": float((hit[:, :k] * weight).sum(axis=1).mean())
            for k in (10, 20) for name,weight in (("recall",1),("ndcg",discount[:k]))}


def fit_filter(op, x):
    path = Path("work/saeif/CASG-main/filter/train_bernstein.py")
    names = {"scipy_csr_to_torch_sparse", "build_neighbor_lists", "precompute_bernstein_basis",
             "PositivePairDataset", "BernsteinFilter", "train_bernstein_filter"}
    nodes = [n for n in ast.parse(path.read_text(encoding="utf-8")).body if getattr(n,"name",None) in names]
    scope = dict(np=np, sparse=sparse, torch=torch, nn=nn, F=F, math=math,
                 logging=logging, DataLoader=DataLoader, Dataset=Dataset, List=List, Dict=Dict, Tuple=Tuple)
    exec(compile(ast.Module(body=nodes,type_ignores=[]),str(path),"exec"),scope)
    active = np.flatnonzero(np.diff(op.indptr))
    adjacency = op[active][:,active]
    features = torch.from_numpy(x[active]).float()
    lap = scope["scipy_csr_to_torch_sparse"](sparse.eye(len(active),format="csr")-adjacency, torch.device("cpu"))
    basis = scope["precompute_bernstein_basis"](lap,features,2)
    _, info = scope["train_bernstein_filter"](
        basis,features,scope["build_neighbor_lists"](adjacency),alpha=.001,temperature=.2,
        epochs=6,batch_size=512,lr=.01,weight_decay=0.,seed=30)
    return info["coeffs"]


def prepare(raw):
    with gzip.open(raw,"rt",encoding="utf-8") as handle:
        rows = [(int(r["unixReviewTime"]),r["reviewerID"],r["asin"],r.get("reviewText") or "")
                for line in handle if (r:=json.loads(line))]
    rows.sort(key=lambda r:r[0])
    pre = [r for r in rows if r[0]<=CUTOFF]
    initial = pre[:-4000]
    initial_counts = Counter(u for _,u,_,_ in initial)
    last = {u:j for j,(_,u,_,_) in enumerate(initial) if initial_counts[u]>=3}
    fit = [r for j,r in enumerate(initial) if last.get(r[1])!=j]
    item_id = {i:j for j,i in enumerate(sorted({r[2] for r in fit}))}
    user_id = {u:j for j,u in enumerate(sorted({r[1] for r in pre}))}
    valid = {user_id[u]:item_id[initial[j][2]] for u,j in last.items() if initial[j][2] in item_id}
    texts = defaultdict(list)
    latest_text = 0
    for t,_,i,review in fit:
        if review and len(texts[i])<3:
            texts[i].append(review)
            latest_text=max(latest_text,t)
    fit_encoded = [(user_id[u],item_id[i],t) for t,u,i,_ in fit]
    pre_encoded = [(user_id[u],item_id[i],t) for t,u,i,_ in pre if i in item_id]
    prefix = len(pre_encoded)-sum(BATCHES)
    assert initial[-1][0]<=pre_encoded[prefix-1][2]<=pre_encoded[-1][2]<=CUTOFF
    prefix_users = {u for u,_,_ in pre_encoded[:prefix]}
    seen = defaultdict(set)
    for u,i,_ in pre_encoded:
        seen[u].add(i)
    test = {}
    future_time = {}
    future_users = set()
    for t,u,i,_ in rows[len(pre):]:
        future_users.add(u)
        uid,iid = user_id.get(u),item_id.get(i)
        if uid in prefix_users and iid is not None and iid not in seen[uid] and uid not in test:
            test[uid]=iid
            future_time[uid]=t
    assert len(test)>=5000 and min(future_time.values())>CUTOFF
    x = HashingVectorizer(n_features=768,dtype=np.float32).transform(
        (" ".join(texts[i]) for i in item_id)).toarray().astype(np.float64)
    x -= x.mean(axis=0)
    with raw.open("rb") as handle:
        source_hash = file_digest(handle,"sha256").hexdigest()
    meta = dict(cutoff=CUTOFF, dataset="Luxury_Beauty_raw", raw_sha256=source_hash, raw_events=len(rows),
                legal_raw=len(pre), future_events=len(rows)-len(pre), future_users=len(future_users),
                train_events=len(fit_encoded), validation_users=len(valid), train_max=fit[-1][0],
                validation_max=max(initial[j][0] for u,j in last.items() if user_id[u] in valid),
                text_max=latest_text, prefix=prefix, prefix_max=pre_encoded[prefix-1][2],
                final_events=len(pre_encoded), final_graph_max=pre_encoded[-1][2], items=len(item_id),
                users=len(test), target_min=min(future_time.values()),target_max=max(future_time.values()),
                batches=BATCHES, features="768 hashed pre-fit review-text features; up to 3 reviews per item",
                target_rule="first future unseen in-catalog item per prefix user; unseen at cutoff")
    return fit_encoded,pre_encoded,valid,test,x,meta


def run(raw, output, epochs):
    fit, events, valid, test, x, meta = prepare(raw)
    emit(kind="metadata",epochs=epochs,seed=30,**meta)
    counts, histories = Counter(),defaultdict(list)
    append(fit,counts,histories)
    n=len(x)
    train_op,_=rebuild(fit,n)
    coeff,bernstein_ms=timed(lambda:fit_filter(train_op,x))
    p,q=Polynomial([.5,.5]),Polynomial([.5,-.5])
    poly=sum(w*math.comb(2,k)*p**k*q**(2-k) for k,w in enumerate(coeff)).coef
    def filtered(op):
        z=polynomial(full_layers(op,x,2),poly)
        isolated=np.diff(op.indptr)==0
        z[isolated]=x[isolated]
        return torch.nn.functional.normalize(torch.from_numpy(z).float())
    emit(kind="filter_fit",coefficients=coeff,fit_ms=bernstein_ms)
    output.mkdir(parents=True,exist_ok=False)
    model=fit_sasrec(filtered(train_op),histories,valid,output,epochs=epochs)
    with (output/"sasrec_validation_selected.pt").open("rb") as handle:
        emit(kind="checkpoint",sha256=file_digest(handle,"sha256").hexdigest())

    counts,histories=Counter(),defaultdict(list)
    begin=meta["prefix"]
    append(events[:begin],counts,histories)
    state=INDEXES["view"](counts,n)
    previous=state.operator
    old_z=filtered(previous)
    users=np.asarray(sorted(test))
    targets=np.array([test[u] for u in users])
    for j,size in enumerate(BATCHES,1):
        end=begin+size
        changed=append_merged(events[begin:end],counts,histories)
        (updated,_),view_ms=timed(lambda:maintain(state,counts,changed))
        (rebuilt,_),rebuild_ms=timed(lambda:rebuild(events[:end],n))
        fresh_counts=Counter()
        append(events[:end],fresh_counts,defaultdict(list))
        structure=ranked_state(fresh_counts,20)
        assert fresh_counts==counts and structure.weights==state.weights
        assert structure.chosen=={i:s for i,s in state.winners.items() if s}
        error=float(np.max(np.abs((rebuilt-updated).data),initial=0))
        assert error<1e-14 and events[end-1][2]<=CUTOFF
        z=filtered(rebuilt)
        z_view=filtered(updated)
        stale,_,_,stale_ms=rank_checked(model,old_z,histories,users,test)
        fresh,_,_,fresh_ms=rank_checked(model,z,histories,users,test)
        view,_,_,view_score_ms=rank_checked(model,z_view,histories,users,test)
        delta=rebuilt-previous
        delta.eliminate_zeros()
        emit(kind="window",window=j,batch=size,graph_max=events[end-1][2],users=len(users),
             **ranking_sensitivity(stale,fresh), normalized_entries=delta.nnz,
             stale=quality(stale,targets),fresh=quality(fresh,targets),
             graph_structure_exact=True,operator_max_error=error,features_equal=torch.equal(z,z_view),
             feature_max_error=float(torch.max(torch.abs(z-z_view))),
             view_top20_matches=int(np.all(view==fresh,axis=1).sum()),
             view_graph_ms=view_ms,rebuild_graph_ms=rebuild_ms,
             stale_score_ms=stale_ms,fresh_score_ms=fresh_ms,view_score_ms=view_score_ms)
        previous,old_z,begin=rebuilt,z,end
    emit(kind="complete",windows=len(BATCHES),query_pairs=len(BATCHES)*len(users))


if __name__ == "__main__":
    parser=argparse.ArgumentParser()
    parser.add_argument("--raw",type=Path,required=True)
    parser.add_argument("--output",type=Path,required=True)
    parser.add_argument("--epochs",type=int,default=12)
    args=parser.parse_args()
    torch.manual_seed(30)
    torch.set_num_threads(4)
    if platform.system()=="Windows":
        ctypes.windll.kernel32.SetThreadExecutionState(0x80000001)
    logging.basicConfig(level=logging.INFO)
    with threadpool_limits(limits=4):
        run(args.raw,args.output,args.epochs)
