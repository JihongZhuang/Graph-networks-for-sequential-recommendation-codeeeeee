"""Recompute reported table rows from recorded runs in a separate directory."""
from argparse import ArgumentParser
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parent
COMMANDS = (
    ("round2/round2_analysis.py",),
    ("round3/round3_analysis.py", "--prior", "round2/evidence", "--tables-only"),
    ("round4/round4_analysis.py", "--prior2", "round2/evidence", "--prior3", "round3"),
    ("round5/round5_analysis.py",),
    ("round8/analyze.py", "--round5", "round5/evidence", "--short", "round2/evidence/round1",
     "--long", "round3/evidence/long"),
    ("round9/audit.py",),
    ("round11/analyze.py",),
    ("round12/audit.py",),
)


def plain_table(path):
    return re.sub(r"\\best\{([^}]*)\}", r"\1", path.read_text(encoding="utf-8")).strip()


def main():
    parser = ArgumentParser(description=__doc__)
    parser.add_argument("output", type=Path, help="new directory for regenerated results")
    output = parser.parse_args().output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    for command in COMMANDS:
        group = Path(command[0]).parts[0]
        shutil.copytree(ROOT / group, output / group)
        (output / group / "latex").mkdir(exist_ok=True)
    for command in COMMANDS:
        subprocess.run([sys.executable, *command], cwd=output, check=True)

    matched = 0
    for original in sorted((ROOT / "latex").glob("round*.tex")):
        stem = original.stem
        if not ("_rows" in stem or stem.endswith("_pairs") or stem == "round3_cutoff_medians"):
            continue
        generated = output / stem.split("_", 1)[0] / "latex" / original.name
        if not generated.is_file():
            raise FileNotFoundError(generated)
        if plain_table(generated) != plain_table(original):
            raise ValueError(f"Table values differ from the manuscript in {original.name}")
        matched += 1
    print(f"Recomputed and matched {matched} manuscript table files.")


if __name__ == "__main__":
    main()
