# Ranked collaborative graph maintenance

We study exact updates of ranked collaborative item graphs as interactions are appended. We derive a candidate certificate that recovers each updated top-*K* neighbourhood from its previous winners and neighbours with increased co-occurrence counts. We then maintain the union-symmetrized graph, weighted degrees, and normalized Laplacian. Bounded View processes changed keys successively. Certified incremental neighbourhood maintenance (CINM) performs one selection per affected row.

We evaluated both strategies against full rebuilding, affected-row reranking, and a full ordering index with fixed filter coefficients and predictor weights. In four matched starts of the 24,000-event Yelp2018 replay, Bounded View and CINM reduced graph-maintenance time, including initialization, by 36.3% and 37.7% relative to affected-row Partial Top-K. The corresponding reductions were 7.2% and 6.7% in the six-window Musical Instruments replay. In a separate five-route, full-catalogue Yelp2018 replay, Bounded View reduced setup-inclusive end-to-end time by 27.84% relative to full rebuilding. Across all three datasets in that protocol, the five routes agreed on the ordered top 20 for 460,572 distinct user–window queries.

[Data and provenance](data/README.md)

## Reproduce the reported analysis

From the repository root, use Python 3.12 and install the analysis dependencies.

```sh
python -m pip install -r requirements.txt
python reproduce_tables.py recomputed
python figures.py
```

We regenerate 25 LaTeX table files from the archived run records and compare their contents with the manuscript. The analysis also recomputes the inline timing tables and retains the original pairing across runs. `recomputed` must be a new directory. The figure command recreates the four manuscript and two supplementary figures in `generated_figures/` and exports the plotted values as CSV. These steps use the distributed records and do not require dataset downloads or model fitting.

## Replay the benchmarks

Install a CPU build of PyTorch for your platform with the [PyTorch installer](https://pytorch.org/get-started/locally/) and install `requirements-replay.txt`. We report the recorded software versions in [`data/environment_versions.json`](data/environment_versions.json). Obtain the versioned inputs and follow the layout in the [data guide](data/README.md). The long and short graph-only drivers use the recorded four logical CPU IDs. They can be replayed on a machine where the process can use those four IDs.

Run the commands below from the repository root. Create `reruns/` before redirecting output. Add the repository's `outputs/` and `round5/` directories to `PYTHONPATH` before invoking the diagnostic scripts. In PowerShell use `$env:PYTHONPATH = "$PWD/outputs;$PWD/round5"`. In a POSIX shell use `export PYTHONPATH="$PWD/outputs:$PWD/round5"`.

```sh
python outputs/casg_major_revision.py --check
python round9/csr_audit.py
python verify_inputs.py .
python round11/partial_replay.py --root . --output reruns/yelp-long
python round12/music_replay.py --root . --output reruns/musical-short
```

The first check compares graph construction across five routes. The sparse-operator check covers additions, Top-*K* evictions, incident weight changes from degree updates, and canonical sparse structure. These two checks use small constructed examples.

To repeat the full-catalogue protocol, run each dataset with three independent initializations.

```sh
python -u outputs/casg_major_revision.py Luxury_Beauty --repeats 3 > reruns/luxury.jsonl
python -u outputs/casg_major_revision.py Musical_Instruments --repeats 3 > reruns/musical.jsonl
python -u outputs/casg_major_revision.py Yelp2018_matched --repeats 3 > reruns/yelp.jsonl
```

We compare one-window-lagged and current graph representations under both per-user leave-one-out and a strict global cutoff. The [data guide](data/README.md) identifies the inputs and commands for the chronological checks. Timing logs record graph-only and complete-recommendation measurements separately. We compute wall time on the recorded four-thread CPU protocol.

## Repository contents

| Location | Contents |
| --- | --- |
| `outputs/` | Graph construction and maintenance, baseline implementations, scoring, and input preparation |
| `round2/`–`round12/` | Protocol-specific replays, original observations, and statistical analyses |
| `results/` | Matched timing summaries, historical measurements, and provenance |
| `figure_data/`, `figures.py` | Plot data and the manuscript figure generator |
| `latex/` | LaTeX tables and vector figure assets used for comparison with archived outputs |

`SHA256SUMS.txt` records the files in this archive. Per-window results and code do not embed the source datasets or trained predictor files. The data guide identifies the required inputs and fingerprints for a full rerun.
